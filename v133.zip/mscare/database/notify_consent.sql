-- Notification trigger for informed-consent (signature) transactions.
-- Ensures signature submissions and approvals/rejections generate notifications
-- for both the patient and the admin, just like appointment transactions.

CREATE OR REPLACE FUNCTION public.notify_consent_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    pname text;
    note  text;
BEGIN
    SELECT COALESCE(NULLIF(TRIM(COALESCE(first_name,'') || ' ' || COALESCE(last_name,'')), ''), 'Patient')
      INTO pname
      FROM public.patients
     WHERE id = COALESCE(NEW.patient_id, OLD.patient_id);

    IF TG_OP = 'INSERT' THEN
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, title, message)
            VALUES (NEW.patient_id, 'Signature Submitted',
                    'Your informed consent signature has been submitted and is waiting for clinic approval.');
        END IF;
        INSERT INTO public.notifications (admin_id, title, message)
        VALUES (NULL, 'New Signature to Review',
                'Patient ' || pname || ' submitted an informed consent signature for review.');
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        IF OLD.status IS DISTINCT FROM NEW.status THEN
            CASE NEW.status
                WHEN 'approved' THEN
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Approved',
                                'Great news! Your informed consent signature has been approved. You can now book an appointment.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, title, message)
                    VALUES (NULL, 'Signature Approved',
                            'Informed consent signature for ' || pname || ' has been approved.');
                WHEN 'rejected' THEN
                    note := NULLIF(TRIM(COALESCE(NEW.rejection_note, '')), '');
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Rejected',
                                'Your informed consent signature was not approved' ||
                                COALESCE(': ' || note, '') ||
                                '. Please upload a new signature.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, title, message)
                    VALUES (NULL, 'Signature Rejected',
                            'Informed consent signature for ' || pname || ' was rejected' ||
                            COALESCE(': ' || note, '') || '.');
                WHEN 'pending' THEN
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Submitted',
                                'Your informed consent signature has been resubmitted and is waiting for clinic approval.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, title, message)
                    VALUES (NULL, 'Signature Resubmitted',
                            'Patient ' || pname || ' resubmitted an informed consent signature for review.');
                ELSE
                    NULL;
            END CASE;
        END IF;
        RETURN NEW;
    END IF;

    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_patient_consents_notify ON public.patient_consents;
CREATE TRIGGER trg_patient_consents_notify
AFTER INSERT OR UPDATE ON public.patient_consents
FOR EACH ROW EXECUTE FUNCTION public.notify_consent_change();
