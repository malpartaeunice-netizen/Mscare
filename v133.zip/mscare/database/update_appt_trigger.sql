CREATE OR REPLACE FUNCTION public.notify_appointment_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    msg text;
    tit text;
BEGIN
    -- New appointment request: notify patient AND admin
    IF TG_OP = 'INSERT' THEN
        tit := 'Appointment Request Received';
        msg := 'New appointment request from ' || COALESCE(NEW.first_name, 'Unknown') || ' ' || COALESCE(NEW.last_name, 'Patient') || ' for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || '.';
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, 'Appointment Request Received',
                'Your appointment request for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been received. The clinic will confirm your schedule shortly.');
        END IF;
        -- Notify admin (admin_id IS NULL = visible to all admins)
        INSERT INTO public.notifications (admin_id, appointment_id, title, message)
        VALUES (NULL, NEW.id, 'New Appointment Request', tit);
        RETURN NEW;
    END IF;

    -- Status change on update: notify patient AND admin
    IF TG_OP = 'UPDATE' THEN
        IF OLD.status IS DISTINCT FROM NEW.status THEN
            CASE NEW.status
                WHEN 'Confirmed' THEN
                    tit := 'Appointment Confirmed';
                    msg := 'Great news! Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been confirmed.';
                WHEN 'Cancelled' THEN
                    tit := 'Appointment Cancelled';
                    msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been cancelled. You can book another time anytime.';
                WHEN 'Completed' THEN
                    tit := 'Appointment Completed';
                    msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been marked as completed.';
                WHEN 'No-show' THEN
                    tit := 'Appointment Missed';
                    msg := 'You missed your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || '. Please contact the clinic to reschedule.';
                ELSE
                    RETURN NEW;
            END CASE;
            -- Notify patient
            IF NEW.patient_id IS NOT NULL THEN
                INSERT INTO public.notifications (patient_id, appointment_id, title, message)
                VALUES (NEW.patient_id, NEW.id, tit, msg);
            END IF;
            -- Notify admin
            INSERT INTO public.notifications (admin_id, appointment_id, title, message)
            VALUES (NULL, NEW.id, 'Appointment Status: ' || tit,
                'Appointment ' || COALESCE(NEW.ref, NEW.id::text) || ' status changed to ' || NEW.status || ' for ' || COALESCE(NEW.first_name, 'Unknown') || ' ' || COALESCE(NEW.last_name, 'Patient') || '.');
        END IF;
        RETURN NEW;
    END IF;

    RETURN NULL;
END;
$$;
