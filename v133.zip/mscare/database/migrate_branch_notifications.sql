-- Branch-scoped consent notifications: store the patient's branch on admin notifications
-- so each branch's admins only see their own patients' signature reviews.

ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS branch_id smallint;

CREATE OR REPLACE FUNCTION public.notify_consent_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    pname   text;
    note    text;
    pbranch smallint;
BEGIN
    SELECT COALESCE(NULLIF(TRIM(COALESCE(first_name,'') || ' ' || COALESCE(last_name,'')), ''), 'Patient'),
           branch_id
      INTO pname, pbranch
      FROM public.patients
     WHERE id = COALESCE(NEW.patient_id, OLD.patient_id);

    IF TG_OP = 'INSERT' THEN
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, title, message)
            VALUES (NEW.patient_id, 'Signature Submitted',
                    'Your informed consent signature has been submitted and is waiting for clinic approval.');
        END IF;
        INSERT INTO public.notifications (admin_id, branch_id, title, message)
        VALUES (NULL, pbranch, 'New Signature to Review',
                'Patient ' || pname || ' submitted an informed consent signature for review.');
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        IF OLD.status IS DISTINCT FROM NEW.status THEN
            CASE NEW.status
                WHEN 'approved' THEN
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Approved',
                                'Great news! Your informed consent signature has been approved. You can now book an appointment.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, branch_id, title, message)
                    VALUES (NULL, pbranch, 'Signature Approved',
                            'Informed consent signature for ' || pname || ' has been approved.');
                WHEN 'rejected' THEN
                    note := NULLIF(TRIM(COALESCE(NEW.rejection_note, '')), '');
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Rejected',
                                'Your informed consent signature was not approved' ||
                                COALESCE(': ' || note, '') || '. Please upload a new signature.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, branch_id, title, message)
                    VALUES (NULL, pbranch, 'Signature Rejected',
                            'Informed consent signature for ' || pname || ' was rejected' ||
                            COALESCE(': ' || note, '') || '.');
                WHEN 'pending' THEN
                    IF NEW.patient_id IS NOT NULL THEN
                        INSERT INTO public.notifications (patient_id, title, message)
                        VALUES (NEW.patient_id, 'Signature Submitted',
                                'Your informed consent signature has been resubmitted and is waiting for clinic approval.');
                    END IF;
                    INSERT INTO public.notifications (admin_id, branch_id, title, message)
                    VALUES (NULL, pbranch, 'Signature Resubmitted',
                            'Patient ' || pname || ' resubmitted an informed consent signature for review.');
                ELSE
                    NULL;
            END CASE;
        END IF;
        RETURN NEW;
    END IF;

    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_patient_consents_notify ON public.patient_consents;
CREATE TRIGGER trg_patient_consents_notify
AFTER INSERT OR UPDATE ON public.patient_consents
FOR EACH ROW EXECUTE FUNCTION public.notify_consent_change();