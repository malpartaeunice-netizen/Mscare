-- MSCare: delete ALL old chatbot / patient-admin chat messages.
-- The patient <-> admin chat was removed, so this table is no longer used.
-- Run once in pgAdmin / psql on your MSCare database:
TRUNCATE TABLE public.contact_messages RESTART IDENTITY;
-- Also clears the "admin_notif_reads" marks of old message notifications:
DELETE FROM public.admin_notif_reads WHERE notif_key LIKE 'm%';
