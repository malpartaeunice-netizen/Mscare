-- Make patient_id nullable so admin-only notifications can be stored.
ALTER TABLE public.notifications ALTER COLUMN patient_id DROP NOT NULL;
