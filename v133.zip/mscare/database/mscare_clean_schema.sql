-- =============================================================================
-- MSCare Dental Clinic - CLEAN PostgreSQL schema (fresh install)
--   1. createdb -U postgres mscare
--   2. psql -U postgres -d mscare -f mscare_clean_schema.sql
-- Contains ONLY what the PHP code uses. Admin logins: admin1 / admin2, password admin123
-- (change them in Admin > Settings > Team after first login).
-- SMTP / Gmail credentials are NOT stored here: set them in Admin > Settings.
-- =============================================================================

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 1. Clinic reference data ----------------------------------------------------
CREATE TABLE IF NOT EXISTS branches (
    id          SMALLSERIAL PRIMARY KEY,
    code        VARCHAR(10)  NOT NULL UNIQUE,              -- 'c1' Makati, 'c2' Manila
    name        VARCHAR(80)  NOT NULL,
    city        VARCHAR(40)  NOT NULL,
    address     VARCHAR(200) NOT NULL,
    open_days   TEXT[]       NOT NULL,
    phone       VARCHAR(30)  DEFAULT '0917 220 3391',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS services (
    id          SMALLSERIAL PRIMARY KEY,
    name        VARCHAR(80)   NOT NULL UNIQUE,
    category    VARCHAR(40)   NOT NULL CHECK (category IN ('Basic Dental Services', 'Specialized Services')),
    sort_order  SMALLINT      NOT NULL DEFAULT 0,
    price       NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    is_active   BOOLEAN       NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS dentists (
    id          SMALLSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    title       VARCHAR(80)  NOT NULL DEFAULT 'Chief Dental Officer',
    phone       VARCHAR(30),
    email       VARCHAR(120),
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admins (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    branch_id       SMALLINT     REFERENCES branches(id) ON DELETE SET NULL,
    display_name    VARCHAR(80)  NOT NULL,
    initials        VARCHAR(10)  NOT NULL DEFAULT 'AD',
    role            VARCHAR(20)  NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'staff', 'superadmin')),
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- 2. Patients and their records -----------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
    id                  BIGSERIAL PRIMARY KEY,
    first_name          VARCHAR(60)  NOT NULL,
    last_name           VARCHAR(60)  NOT NULL,
    middle_name         VARCHAR(60)  DEFAULT '',
    email               VARCHAR(120) NOT NULL UNIQUE,
    phone               VARCHAR(30)  NOT NULL,
    age                 SMALLINT     NOT NULL CHECK (age >= 0 AND age <= 125),
    gender              VARCHAR(20)  NOT NULL CHECK (gender IN ('Female', 'Male', 'Prefer not to say')),
    password_hash       VARCHAR(255) NOT NULL,
    branch_id           SMALLINT     REFERENCES branches(id) ON DELETE SET NULL,   -- NULL = visible to all admins
    is_demo             BOOLEAN      NOT NULL DEFAULT FALSE,
    status              VARCHAR(20)  NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Suspended')),
    email_verified      BOOLEAN      NOT NULL DEFAULT FALSE,
    email_verified_at   TIMESTAMPTZ,
    failed_attempts     SMALLINT     NOT NULL DEFAULT 0,
    locked_at           TIMESTAMPTZ,
    reactivate_token    VARCHAR(64),
    reactivate_expires  TIMESTAMPTZ,
    reactivate_sent_at  TIMESTAMPTZ,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_patients_phone  ON patients (phone);
CREATE INDEX IF NOT EXISTS ix_patients_branch ON patients (branch_id);
DROP TRIGGER IF EXISTS trg_patients_updated ON patients;
CREATE TRIGGER trg_patients_updated BEFORE UPDATE ON patients
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_otps (
    id          BIGSERIAL PRIMARY KEY,
    user_type   VARCHAR(10) NOT NULL CHECK (user_type IN ('patient', 'admin')),
    user_id     BIGINT      NOT NULL,
    otp_code    VARCHAR(10) NOT NULL,
    purpose     VARCHAR(30) NOT NULL DEFAULT 'login' CHECK (purpose IN ('login', 'register', 'password_reset')),
    expires_at  TIMESTAMPTZ NOT NULL,
    is_used     BOOLEAN     NOT NULL DEFAULT FALSE,
    attempts    SMALLINT    NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_otps_lookup       ON patient_otps (user_type, user_id, otp_code, is_used);
CREATE INDEX IF NOT EXISTS ix_otps_user_purpose ON patient_otps (user_type, user_id, purpose, created_at DESC);

CREATE TABLE IF NOT EXISTS patient_records (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    birthdate               DATE,
    sex                     VARCHAR(10),
    nickname                VARCHAR(50),
    religion                VARCHAR(50),
    nationality             VARCHAR(50),
    home_address            VARCHAR(255),
    occupation              VARCHAR(100),
    dental_insurance        VARCHAR(100),
    effective_date          DATE,
    home_no                 VARCHAR(30),
    office_no               VARCHAR(30),
    fax_no                  VARCHAR(30),
    cell_no                 VARCHAR(30),
    email                   VARCHAR(120),
    guardian_name           VARCHAR(100),
    guardian_occupation     VARCHAR(100),
    prev_dentist            VARCHAR(100),
    last_dental_visit       DATE,
    reason_for_consultation TEXT,
    is_completed            BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
DROP TRIGGER IF EXISTS trg_patient_records_updated ON patient_records;
CREATE TRIGGER trg_patient_records_updated BEFORE UPDATE ON patient_records
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_medical_histories (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    physician_name          VARCHAR(100),
    physician_specialty     VARCHAR(100),
    physician_office_no     VARCHAR(30),
    physician_office_addr   VARCHAR(255),
    in_good_health          BOOLEAN NOT NULL,
    under_treatment         BOOLEAN NOT NULL,
    treatment_details       VARCHAR(255),
    serious_illness_or_op   BOOLEAN NOT NULL,
    illness_details         VARCHAR(255),
    hospitalized            BOOLEAN NOT NULL,
    hospitalized_details    VARCHAR(255),
    taking_medication       BOOLEAN NOT NULL,
    medication_details      VARCHAR(255),
    tobacco_use             BOOLEAN NOT NULL,
    alcohol_drug_use        BOOLEAN NOT NULL,
    allergies               TEXT[]  DEFAULT ARRAY[]::TEXT[],
    allergy_other           VARCHAR(255),
    women_pregnant          BOOLEAN,
    women_nursing           BOOLEAN,
    women_birth_control     BOOLEAN,
    blood_type              VARCHAR(10),
    blood_pressure          VARCHAR(20),
    conditions              TEXT[]  DEFAULT ARRAY[]::TEXT[],
    condition_other         VARCHAR(255),
    is_completed            BOOLEAN NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
DROP TRIGGER IF EXISTS trg_patient_med_updated ON patient_medical_histories;
CREATE TRIGGER trg_patient_med_updated BEFORE UPDATE ON patient_medical_histories
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_consents (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    has_agreed              BOOLEAN     NOT NULL DEFAULT TRUE,
    signature_data          TEXT        NOT NULL,
    signature_date          DATE        NOT NULL DEFAULT CURRENT_DATE,
    sig_tries_used          SMALLINT    NOT NULL DEFAULT 1,
    status                  VARCHAR(15) NOT NULL DEFAULT 'pending' CHECK (status IN ('none', 'pending', 'approved', 'rejected')),
    rejection_note          VARCHAR(255),
    reviewed_by_admin_id    INT         REFERENCES admins(id) ON DELETE SET NULL,
    reviewed_at             TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_patient_consents_status ON patient_consents (status);
DROP TRIGGER IF EXISTS trg_patient_consents_updated ON patient_consents;
CREATE TRIGGER trg_patient_consents_updated BEFORE UPDATE ON patient_consents
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- 3. Appointments ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
    id                    BIGSERIAL PRIMARY KEY,
    ref                   VARCHAR(12)  NOT NULL UNIQUE,                     -- e.g. MSC-A1B2C3
    patient_id            BIGINT       REFERENCES patients(id) ON DELETE SET NULL,
    branch_id             SMALLINT     NOT NULL REFERENCES branches(id),
    service_id            SMALLINT     NOT NULL REFERENCES services(id),
    dentist_id            SMALLINT     REFERENCES dentists(id) ON DELETE SET NULL,
    appointment_date      DATE         NOT NULL,
    appointment_time      TIME         NOT NULL,
    first_name            VARCHAR(60)  NOT NULL,
    last_name             VARCHAR(60)  NOT NULL,
    phone                 VARCHAR(20)  NOT NULL,
    email                 VARCHAR(120) NOT NULL,
    is_current_patient    BOOLEAN      NOT NULL DEFAULT FALSE,
    comments              VARCHAR(500) NOT NULL DEFAULT '',
    status                VARCHAR(12)  NOT NULL DEFAULT 'Pending'
                          CHECK (status IN ('Pending', 'Confirmed', 'Completed', 'Cancelled', 'No-show')),
    admin_notes           TEXT         DEFAULT '',
    reviewed_by_admin_id  INT          REFERENCES admins(id) ON DELETE SET NULL,
    email_reminded_at     TIMESTAMPTZ,
    created_at            TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ  NOT NULL DEFAULT now()
);
-- One dentist works at both clinics: a date + time can only be held once (cancelled frees it)
CREATE UNIQUE INDEX IF NOT EXISTS uq_appointments_slot
    ON appointments (appointment_date, appointment_time) WHERE status <> 'Cancelled';
CREATE INDEX IF NOT EXISTS ix_appointments_date           ON appointments (appointment_date);
CREATE INDEX IF NOT EXISTS ix_appointments_status         ON appointments (status);
CREATE INDEX IF NOT EXISTS ix_appointments_branch         ON appointments (branch_id);
CREATE INDEX IF NOT EXISTS ix_appointments_branch_created ON appointments (branch_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_appointments_patient_id     ON appointments (patient_id);
CREATE INDEX IF NOT EXISTS ix_appointments_phone          ON appointments (phone);
CREATE INDEX IF NOT EXISTS ix_appointments_reminder
    ON appointments (appointment_date, appointment_time)
    WHERE email_reminded_at IS NULL AND status IN ('Pending', 'Confirmed');
DROP TRIGGER IF EXISTS trg_appointments_updated ON appointments;
CREATE TRIGGER trg_appointments_updated BEFORE UPDATE ON appointments
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Guest booking with a registered email -> link it to that patient
CREATE OR REPLACE FUNCTION auto_link_patient_to_appointment() RETURNS trigger AS $$
BEGIN
    IF NEW.patient_id IS NULL THEN
        SELECT id INTO NEW.patient_id FROM patients WHERE LOWER(email) = LOWER(NEW.email) LIMIT 1;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_appointments_autolink ON appointments;
CREATE TRIGGER trg_appointments_autolink BEFORE INSERT ON appointments
    FOR EACH ROW EXECUTE FUNCTION auto_link_patient_to_appointment();

-- 4. Charts and treatments -------------------------------------------------------
CREATE TABLE IF NOT EXISTS dental_charts (
    id                   BIGSERIAL PRIMARY KEY,
    patient_id           BIGINT      NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    tooth_number         SMALLINT    NOT NULL CHECK (tooth_number BETWEEN 11 AND 85),
    condition_code       VARCHAR(20) NOT NULL,
    notes                TEXT        DEFAULT '',
    updated_by_admin_id  INT         REFERENCES admins(id) ON DELETE SET NULL,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_patient_tooth UNIQUE (patient_id, tooth_number)
);
CREATE INDEX IF NOT EXISTS ix_dental_charts_patient ON dental_charts (patient_id);
DROP TRIGGER IF EXISTS trg_dental_charts_updated ON dental_charts;
CREATE TRIGGER trg_dental_charts_updated BEFORE UPDATE ON dental_charts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS treatments (
    id                   BIGSERIAL PRIMARY KEY,
    patient_id           BIGINT        NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    branch_id            SMALLINT      NOT NULL REFERENCES branches(id),
    appointment_id       BIGINT        REFERENCES appointments(id) ON DELETE SET NULL,
    treatment_date       DATE          NOT NULL DEFAULT CURRENT_DATE,
    procedure_name       VARCHAR(100)  NOT NULL,
    tooth                VARCHAR(30)   DEFAULT '—',
    dentist_name         VARCHAR(100)  NOT NULL DEFAULT 'Dr. Marilou S. Cariño',
    cost                 NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    notes                TEXT          DEFAULT '',
    created_by_admin_id  INT           REFERENCES admins(id) ON DELETE SET NULL,
    created_at           TIMESTAMPTZ   NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_treatments_patient ON treatments (patient_id);
CREATE INDEX IF NOT EXISTS ix_treatments_date    ON treatments (treatment_date DESC);
CREATE INDEX IF NOT EXISTS ix_treatments_branch  ON treatments (branch_id);

-- 5. Notifications and messages --------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT       REFERENCES patients(id) ON DELETE CASCADE,        -- NULL = admin-only
    admin_id        BIGINT       REFERENCES admins(id) ON DELETE SET NULL,         -- NULL = all admins
    branch_id       SMALLINT,
    appointment_id  BIGINT       REFERENCES appointments(id) ON DELETE SET NULL,
    title           VARCHAR(150) NOT NULL,
    message         TEXT         NOT NULL,
    is_read         BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_notifications_patient         ON notifications (patient_id, is_read);
CREATE INDEX IF NOT EXISTS ix_notifications_patient_created ON notifications (patient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_notifications_admin           ON notifications (admin_id, is_read);

CREATE OR REPLACE FUNCTION public.notify_appointment_change() RETURNS trigger
    LANGUAGE plpgsql AS $$
DECLARE
    msg text;
    tit text;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, 'Appointment Request Received',
                    'Your appointment request for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been received. The clinic will confirm your schedule shortly.');
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
        CASE NEW.status
            WHEN 'Confirmed' THEN
                tit := 'Appointment Confirmed';
                msg := 'Great news! Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been confirmed.';
            WHEN 'Cancelled' THEN
                tit := 'Appointment Cancelled';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been cancelled. You can book another time anytime.';
            WHEN 'Completed' THEN
                tit := 'Appointment Completed';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been marked as completed.';
            WHEN 'No-show' THEN
                tit := 'Appointment Missed';
                msg := 'You missed your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || '. Please contact the clinic to reschedule.';
            ELSE
                RETURN NEW;
        END CASE;
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, tit, msg);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_appointments_notify ON appointments;
CREATE TRIGGER trg_appointments_notify AFTER INSERT OR UPDATE ON appointments
    FOR EACH ROW EXECUTE FUNCTION public.notify_appointment_change();

CREATE TABLE IF NOT EXISTS contact_messages (
    id                   BIGSERIAL PRIMARY KEY,
    name                 VARCHAR(100) NOT NULL,
    mobile               VARCHAR(20)  NOT NULL,
    email                VARCHAR(120),
    branch_id            SMALLINT     NOT NULL REFERENCES branches(id),
    message              TEXT         NOT NULL,
    sender               VARCHAR(10)  NOT NULL DEFAULT 'patient',
    is_ai                BOOLEAN      NOT NULL DEFAULT FALSE,
    needs_human          BOOLEAN      NOT NULL DEFAULT FALSE,
    is_read              BOOLEAN      NOT NULL DEFAULT FALSE,
    replied_at           TIMESTAMPTZ,
    replied_by_admin_id  INT          REFERENCES admins(id) ON DELETE SET NULL,
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_messages_created     ON contact_messages (created_at DESC);
CREATE INDEX IF NOT EXISTS ix_messages_branch      ON contact_messages (branch_id);
CREATE INDEX IF NOT EXISTS ix_messages_email       ON contact_messages (lower(email));
CREATE INDEX IF NOT EXISTS ix_messages_needs_human ON contact_messages (branch_id) WHERE needs_human AND NOT is_read;

-- 6. Admin settings / logs -------------------------------------------------------
CREATE TABLE IF NOT EXISTS clinic_settings (
    branch_id     SMALLINT    NOT NULL,                  -- 0 = shared (SMTP etc.)
    setting_key   VARCHAR(60) NOT NULL,
    setting_value TEXT        NOT NULL DEFAULT '',
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (branch_id, setting_key)
);
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id         BIGSERIAL PRIMARY KEY,
    admin_id   INTEGER,
    branch_id  SMALLINT,
    action     VARCHAR(80) NOT NULL,
    detail     TEXT        NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_notif_reads (
    admin_id  INTEGER     NOT NULL,
    notif_key VARCHAR(40) NOT NULL,
    read_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (admin_id, notif_key)
);

-- 7. Starting data ----------------------------------------------------------------
INSERT INTO branches (code, name, city, address, open_days, phone) VALUES
    ('c1', 'Clinic 1 — Makati', 'Makati', '#7 Moonlite Street, Barangay Singkamas, Makati City', ARRAY['Mon','Wed','Fri','Sat'], '0917 220 3391'),
    ('c2', 'Clinic 2 — Manila', 'Manila', 'Burke House No 5 Building, Pedro Gil Street, Sta. Ana, Manila', ARRAY['Tue','Thu'], '0917 220 3392')
ON CONFLICT (code) DO NOTHING;

INSERT INTO services (name, category, sort_order, price) VALUES
    ('General Dentistry',    'Basic Dental Services', 1,  1000.00),
    ('Cleaning',             'Basic Dental Services', 2,  1200.00),
    ('Orthodontics',         'Specialized Services',  3, 35000.00),
    ('Esthetic Dentistry',   'Specialized Services',  4,  5000.00),
    ('Prosthodontics',       'Specialized Services',  5, 12000.00),
    ('Root Canal Treatment', 'Specialized Services',  6,  8500.00),
    ('Oral Surgery',         'Basic Dental Services', 7,  3000.00),
    ('Braces',               'Specialized Services',  8, 45000.00)
ON CONFLICT (name) DO NOTHING;

INSERT INTO dentists (name, title, phone, email) VALUES
    ('Dr. Marilou S. Cariño', 'Chief Dental Officer / Orthodontist', '0917 220 3391', 'dr.carino@mscare.com')
ON CONFLICT (name) DO NOTHING;

INSERT INTO admins (username, password_hash, branch_id, display_name, initials, role) VALUES
    ('admin1', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92', (SELECT id FROM branches WHERE code = 'c1'), 'Clinic 1 Admin', 'A1', 'admin'),
    ('admin2', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92', (SELECT id FROM branches WHERE code = 'c2'), 'Clinic 2 Admin', 'A2', 'admin')
ON CONFLICT (username) DO NOTHING;
