-- =============================================================================
-- MSCare - FIX + CLEANUP for your EXISTING database (keeps all your data)
-- Run once:   psql -U postgres -d mscare -f fix_existing_db.sql
-- Safe to run again. Everything runs in one transaction (all or nothing).
-- =============================================================================
BEGIN;

-- -----------------------------------------------------------------------------
-- A. FIX: "column p.branch_id does not exist"  (admin dashboard error)
-- -----------------------------------------------------------------------------
ALTER TABLE patients ADD COLUMN IF NOT EXISTS branch_id smallint;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'patients_branch_id_fkey') THEN
    ALTER TABLE patients ADD CONSTRAINT patients_branch_id_fkey
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS ix_patients_branch ON patients (branch_id);

-- Give existing patients the branch of their first appointment (NULL = visible to all admins)
UPDATE patients p SET branch_id = (
    SELECT a.branch_id FROM appointments a
    WHERE a.patient_id = p.id ORDER BY a.created_at, a.id LIMIT 1)
WHERE p.branch_id IS NULL;

-- Admin notifications need these (the code filters by admin_id + branch_id)
ALTER TABLE notifications ALTER COLUMN patient_id DROP NOT NULL;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS admin_id  bigint;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS branch_id smallint;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'notifications_admin_id_fkey') THEN
    ALTER TABLE notifications ADD CONSTRAINT notifications_admin_id_fkey
      FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS ix_notifications_admin           ON notifications (admin_id, is_read);
CREATE INDEX IF NOT EXISTS ix_notifications_patient_created ON notifications (patient_id, created_at DESC);

-- -----------------------------------------------------------------------------
-- B. FIX: make sure every column the PHP code uses exists (from the old patch files)
-- -----------------------------------------------------------------------------
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS email_verified     boolean     NOT NULL DEFAULT FALSE;
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS email_verified_at  timestamptz;
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS failed_attempts    smallint    NOT NULL DEFAULT 0;
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS locked_at          timestamptz;
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS reactivate_token   varchar(64);
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS reactivate_expires timestamptz;
ALTER TABLE patients      ADD COLUMN IF NOT EXISTS reactivate_sent_at timestamptz;
ALTER TABLE patient_otps  ADD COLUMN IF NOT EXISTS attempts           smallint    NOT NULL DEFAULT 0;
ALTER TABLE appointments  ADD COLUMN IF NOT EXISTS email_reminded_at  timestamptz;
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS sender      varchar(10) NOT NULL DEFAULT 'patient';
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS is_ai       boolean     NOT NULL DEFAULT FALSE;
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS needs_human boolean     NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS clinic_settings (
    branch_id     smallint     NOT NULL,
    setting_key   varchar(60)  NOT NULL,
    setting_value text         NOT NULL DEFAULT '',
    updated_at    timestamptz  NOT NULL DEFAULT now(),
    PRIMARY KEY (branch_id, setting_key)
);
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id         bigserial PRIMARY KEY,
    admin_id   integer,
    branch_id  smallint,
    action     varchar(80) NOT NULL,
    detail     text        NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_notif_reads (
    admin_id  integer     NOT NULL,
    notif_key varchar(40) NOT NULL,
    read_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (admin_id, notif_key)
);
ALTER TABLE admin_notif_reads ALTER COLUMN notif_key TYPE varchar(40);

CREATE INDEX IF NOT EXISTS ix_otps_user_purpose        ON patient_otps (user_type, user_id, purpose, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_messages_email           ON contact_messages (lower(email));
CREATE INDEX IF NOT EXISTS ix_messages_needs_human     ON contact_messages (branch_id) WHERE needs_human AND NOT is_read;
CREATE INDEX IF NOT EXISTS ix_appointments_branch_created ON appointments (branch_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_appointments_reminder
    ON appointments (appointment_date, appointment_time)
    WHERE email_reminded_at IS NULL AND status IN ('Pending', 'Confirmed');

-- -----------------------------------------------------------------------------
-- C. REMOVE what the system does not use
-- -----------------------------------------------------------------------------
-- This constraint BLOCKS cancelling: the PHP stores the reason in admin_notes,
-- never in cancel_reason, so every cancel would fail while it exists.
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS ck_appt_cancel_reason_required;
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS ck_appt_cancelled_by;

-- Notification trigger first (it references cancel_reason) -> rewrite without it
CREATE OR REPLACE FUNCTION public.notify_appointment_change() RETURNS trigger
    LANGUAGE plpgsql AS $$
DECLARE
    msg text;
    tit text;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, 'Appointment Request Received',
                    'Your appointment request for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been received. The clinic will confirm your schedule shortly.');
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
        CASE NEW.status
            WHEN 'Confirmed' THEN
                tit := 'Appointment Confirmed';
                msg := 'Great news! Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been confirmed.';
            WHEN 'Cancelled' THEN
                tit := 'Appointment Cancelled';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been cancelled. You can book another time anytime.';
            WHEN 'Completed' THEN
                tit := 'Appointment Completed';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been marked as completed.';
            WHEN 'No-show' THEN
                tit := 'Appointment Missed';
                msg := 'You missed your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || '. Please contact the clinic to reschedule.';
            ELSE
                RETURN NEW;
        END CASE;
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, tit, msg);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

-- Unused views / functions / tables (no PHP file references them)
DROP VIEW     IF EXISTS v_appointments_full;
DROP VIEW     IF EXISTS v_patient_records_overview;
DROP FUNCTION IF EXISTS can_patient_book(bigint);
DROP FUNCTION IF EXISTS cancel_appointment(integer, text, text, text);
DROP FUNCTION IF EXISTS reschedule_appointment(integer, date, time, text, text, text, integer);
DROP TABLE    IF EXISTS appointment_reschedules CASCADE;       -- also drops trg_resched_notify
DROP FUNCTION IF EXISTS notify_appointment_reschedule();
DROP TRIGGER  IF EXISTS trg_patient_consents_notify ON patient_consents;
DROP FUNCTION IF EXISTS notify_consent_change();

-- Unused columns
ALTER TABLE appointments DROP COLUMN IF EXISTS cancel_reason;
ALTER TABLE appointments DROP COLUMN IF EXISTS cancel_details;
ALTER TABLE appointments DROP COLUMN IF EXISTS cancelled_by_type;
ALTER TABLE appointments DROP COLUMN IF EXISTS cancelled_at;
ALTER TABLE appointments DROP COLUMN IF EXISTS reschedule_count;
ALTER TABLE dentists     DROP COLUMN IF EXISTS license_no;

-- Duplicate indexes (same columns as the ones created above / by the primary keys)
DROP INDEX IF EXISTS ix_patients_email;          -- email is already UNIQUE
DROP INDEX IF EXISTS ix_notifications_patient;   -- replaced by ix_notifications_patient_created

-- pgcrypto was never used (passwords are hashed in PHP)
DO $$ BEGIN
  DROP EXTENSION IF EXISTS pgcrypto;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pgcrypto left in place: %', SQLERRM;
END $$;

-- -----------------------------------------------------------------------------
-- D. Medical history: no hidden defaults (patient must answer every question)
-- -----------------------------------------------------------------------------
ALTER TABLE patient_medical_histories
    ALTER COLUMN in_good_health       DROP DEFAULT,
    ALTER COLUMN under_treatment      DROP DEFAULT,
    ALTER COLUMN serious_illness_or_op DROP DEFAULT,
    ALTER COLUMN hospitalized         DROP DEFAULT,
    ALTER COLUMN taking_medication    DROP DEFAULT,
    ALTER COLUMN tobacco_use          DROP DEFAULT,
    ALTER COLUMN alcohol_drug_use     DROP DEFAULT,
    ALTER COLUMN is_completed         SET DEFAULT FALSE;

-- -----------------------------------------------------------------------------
-- E. Make auto-number counters follow the data (prevents false "slot just booked")
-- -----------------------------------------------------------------------------
DO $$
DECLARE t text; seq text;
BEGIN
  FOREACH t IN ARRAY ARRAY['branches','services','dentists','admins','patients','patient_otps',
                           'appointments','dental_charts','treatments','notifications',
                           'contact_messages','admin_audit_logs']
  LOOP
    seq := pg_get_serial_sequence('public.' || t, 'id');
    IF seq IS NOT NULL THEN
      EXECUTE format('SELECT setval(%L, GREATEST((SELECT COALESCE(MAX(id),0) FROM public.%I), 1))', seq, t);
    END IF;
  END LOOP;
END $$;

COMMIT;

-- Quick check (should show 0 for missing columns and the branch of each patient)
SELECT 'patients.branch_id exists' AS check, EXISTS (
  SELECT 1 FROM information_schema.columns
  WHERE table_name = 'patients' AND column_name = 'branch_id') AS ok;
