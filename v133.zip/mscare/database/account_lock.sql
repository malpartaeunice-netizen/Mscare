-- MSCare: account lock after 3 wrong passwords + email reactivation link.
-- The site adds these columns by itself on first use; run this only if you prefer to do it by hand.
-- Safe to run more than once.
ALTER TABLE patients ADD COLUMN IF NOT EXISTS failed_attempts    SMALLINT NOT NULL DEFAULT 0;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS locked_at          TIMESTAMPTZ;   -- NULL = not locked
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_token   VARCHAR(64);   -- SHA-256 of the emailed link token
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_expires TIMESTAMPTZ;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_sent_at TIMESTAMPTZ;

-- Unlock someone by hand:
--   UPDATE patients SET locked_at = NULL, failed_attempts = 0, reactivate_token = NULL,
--          reactivate_expires = NULL, reactivate_sent_at = NULL WHERE email = 'patient@gmail.com';
