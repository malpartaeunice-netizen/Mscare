-- Fixes "That time slot was just booked" shown for FREE slots (id counters behind the data after an import/restore).
SELECT setval(pg_get_serial_sequence('public.branches','id'),         GREATEST((SELECT COALESCE(MAX(id),0) FROM public.branches),1));
SELECT setval(pg_get_serial_sequence('public.services','id'),         GREATEST((SELECT COALESCE(MAX(id),0) FROM public.services),1));
SELECT setval(pg_get_serial_sequence('public.dentists','id'),         GREATEST((SELECT COALESCE(MAX(id),0) FROM public.dentists),1));
SELECT setval(pg_get_serial_sequence('public.admins','id'),           GREATEST((SELECT COALESCE(MAX(id),0) FROM public.admins),1));
SELECT setval(pg_get_serial_sequence('public.patients','id'),         GREATEST((SELECT COALESCE(MAX(id),0) FROM public.patients),1));
SELECT setval(pg_get_serial_sequence('public.patient_otps','id'),     GREATEST((SELECT COALESCE(MAX(id),0) FROM public.patient_otps),1));
SELECT setval(pg_get_serial_sequence('public.appointments','id'),     GREATEST((SELECT COALESCE(MAX(id),0) FROM public.appointments),1));
SELECT setval(pg_get_serial_sequence('public.dental_charts','id'),    GREATEST((SELECT COALESCE(MAX(id),0) FROM public.dental_charts),1));
SELECT setval(pg_get_serial_sequence('public.treatments','id'),       GREATEST((SELECT COALESCE(MAX(id),0) FROM public.treatments),1));
SELECT setval(pg_get_serial_sequence('public.notifications','id'),    GREATEST((SELECT COALESCE(MAX(id),0) FROM public.notifications),1));
SELECT setval(pg_get_serial_sequence('public.contact_messages','id'), GREATEST((SELECT COALESCE(MAX(id),0) FROM public.contact_messages),1));
