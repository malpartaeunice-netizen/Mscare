-- Migrate live DB to include admin notifications support.
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS admin_id bigint;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'notifications_admin_id_fkey'
    ) THEN
        ALTER TABLE public.notifications
            ADD CONSTRAINT notifications_admin_id_fkey
            FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_notifications_admin ON public.notifications (admin_id, is_read);
