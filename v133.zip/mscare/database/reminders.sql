-- Email reminders: remembers which appointments were already emailed, so nobody gets the same reminder twice.
-- (The admin site also adds this column automatically the first time it is needed.)
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS email_reminded_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS ix_appointments_reminder
    ON appointments (appointment_date, appointment_time)
    WHERE email_reminded_at IS NULL AND status IN ('Pending', 'Confirmed');
