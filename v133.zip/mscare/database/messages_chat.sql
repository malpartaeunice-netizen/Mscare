-- MSCare: two-way chat + AI chatbot for Messages
-- The pages also add these columns by themselves the first time they run, so running this file is optional.
-- Safe to run more than once.

-- -----------------------------------------------------------------------------
-- AI chatbot (Gemini) for Messages  -  safe to run more than once
--   sender       'patient' | 'admin'   (who wrote the message)
--   is_ai        true  = the reply was written by the AI chatbot
--   needs_human  true  = the AI could not answer this patient message; admin must reply
-- -----------------------------------------------------------------------------
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS sender      varchar(10) NOT NULL DEFAULT 'patient';
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS is_ai       boolean     NOT NULL DEFAULT false;
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS needs_human boolean     NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS ix_messages_email ON contact_messages (lower(email));
CREATE INDEX IF NOT EXISTS ix_messages_needs_human ON contact_messages (branch_id) WHERE needs_human AND NOT is_read;
