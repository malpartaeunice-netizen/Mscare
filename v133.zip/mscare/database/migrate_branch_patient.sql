-- Add branch_id to patients (for branch-based admin view) and notifications.
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS branch_id smallint;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS branch_id smallint;

-- FK (optional)
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'patients_branch_id_fkey') THEN
    ALTER TABLE public.patients ADD CONSTRAINT patients_branch_id_fkey
      FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Backfill: assign patients without a branch to NULL (admin sees all if branch_id NULL).
-- (No-op default; admins with NULL branch see everything.)

-- Update v_patient_records_overview to include branch info.
CREATE OR REPLACE VIEW public.v_patient_records_overview AS
 SELECT p.id AS patient_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS full_name,
    p.email,
    p.phone,
    p.age,
    p.gender,
    p.branch_id,
    b.code AS branch_code,
    b.name AS branch_name,
    COALESCE(pr.is_completed, false) AS personal_info_done,
    COALESCE(pm.is_completed, false) AS medical_history_done,
    COALESCE(pc.status, 'none'::character varying) AS consent_status,
    pc.signature_date,
    pc.sig_tries_used,
    pc.rejection_note,
    adm.display_name AS consent_reviewed_by,
    public.can_patient_book(p.id) AS can_book_appointment,
    p.created_at AS registered_at
   FROM ((((public.patients p
     LEFT JOIN public.branches b ON b.id = p.branch_id)
     LEFT JOIN public.patient_records pr ON (pr.patient_id = p.id))
     LEFT JOIN public.patient_medical_histories pm ON (pm.patient_id = p.id))
     LEFT JOIN public.patient_consents pc ON (pc.patient_id = p.id))
     LEFT JOIN public.admins adm ON (adm.id = pc.reviewed_by_admin_id));