-- Handy statements for the clinic / admin side  (psql -U postgres -d mscare)

-- All requests, newest first
SELECT a.ref, a.appointment_date, to_char(a.appointment_time, 'HH12:MI AM') AS time,
       b.city AS branch, s.name AS service,
       a.first_name || ' ' || a.last_name AS patient, a.phone, a.email,
       CASE WHEN a.is_current_patient THEN 'Yes' ELSE 'No' END AS current_patient,
       a.status, a.created_at
FROM appointments a
JOIN branches b ON b.id = a.branch_id
JOIN services s ON s.id = a.service_id
ORDER BY a.created_at DESC;

-- Today's schedule
SELECT to_char(a.appointment_time, 'HH12:MI AM') AS time, b.city, s.name AS service,
       a.first_name || ' ' || a.last_name AS patient, a.phone, a.status
FROM appointments a
JOIN branches b ON b.id = a.branch_id
JOIN services s ON s.id = a.service_id
WHERE a.appointment_date = CURRENT_DATE AND a.status <> 'Cancelled'
ORDER BY a.appointment_time;

-- Requests waiting for confirmation
SELECT ref, appointment_date, appointment_time, first_name, last_name, phone
FROM appointments WHERE status = 'Pending' ORDER BY appointment_date, appointment_time;

-- Confirm / cancel / complete a request
UPDATE appointments SET status = 'Confirmed' WHERE ref = 'MSC-XXXXXX';
UPDATE appointments SET status = 'Cancelled' WHERE ref = 'MSC-XXXXXX';   -- frees the time slot
UPDATE appointments SET status = 'Completed' WHERE ref = 'MSC-XXXXXX';

-- Reschedule
UPDATE appointments SET appointment_date = '2026-11-05', appointment_time = '10:00' WHERE ref = 'MSC-XXXXXX';

-- Taken times on a date (what the booking page greys out)
SELECT to_char(appointment_time, 'HH12:MI AM') FROM appointments
WHERE appointment_date = '2026-11-05' AND status <> 'Cancelled';

-- Appointments per service (last 30 days)
SELECT s.name, count(*) AS total
FROM appointments a JOIN services s ON s.id = a.service_id
WHERE a.created_at >= now() - interval '30 days'
GROUP BY s.name ORDER BY total DESC;

-- Appointments per branch per month
SELECT b.city, date_trunc('month', a.appointment_date)::date AS month, count(*) AS total
FROM appointments a JOIN branches b ON b.id = a.branch_id
GROUP BY b.city, month ORDER BY month DESC, b.city;

-- Unread contact messages
SELECT m.id, m.created_at, m.name, m.mobile, m.email, b.city, m.message
FROM contact_messages m JOIN branches b ON b.id = m.branch_id
WHERE NOT m.is_read ORDER BY m.created_at DESC;
UPDATE contact_messages SET is_read = TRUE WHERE id = 1;
