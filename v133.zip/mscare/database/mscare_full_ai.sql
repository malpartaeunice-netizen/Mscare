CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- -----------------------------------------------------------------------------
-- Helper Function: Auto-update updated_at timestamps
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
-- -----------------------------------------------------------------------------
-- 1. Branches (Makati & Manila Clinics)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS branches (
    id          SMALLSERIAL PRIMARY KEY,
    code        VARCHAR(10)  NOT NULL UNIQUE,          -- 'c1' (Makati), 'c2' (Manila)
    name        VARCHAR(80)  NOT NULL,                 -- 'Clinic 1 — Makati', 'Clinic 2 — Manila'
    city        VARCHAR(40)  NOT NULL,                 -- 'Makati', 'Manila'
    address     VARCHAR(200) NOT NULL,
    open_days   TEXT[]       NOT NULL,                 -- e.g. {Mon,Wed,Fri,Sat} or {Tue,Thu}
    phone       VARCHAR(30)  DEFAULT '0917 220 3391',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS services (
    id          SMALLSERIAL PRIMARY KEY,
    name        VARCHAR(80)  NOT NULL UNIQUE,
    category    VARCHAR(40)  NOT NULL
                CHECK (category IN ('Basic Dental Services', 'Specialized Services')),
    sort_order  SMALLINT     NOT NULL DEFAULT 0,
    price       NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS dentists (
    id          SMALLSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,          -- 'Dr. Marilou S. Cariño'
    title       VARCHAR(80)  NOT NULL DEFAULT 'Chief Dental Officer',
    license_no  VARCHAR(50),
    phone       VARCHAR(30),
    email       VARCHAR(120),
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admins (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,      -- 'admin1', 'admin2'
    password_hash   VARCHAR(255) NOT NULL,
    branch_id       SMALLINT     REFERENCES branches(id) ON DELETE SET NULL,
    display_name    VARCHAR(80)  NOT NULL,             -- 'Clinic 1 Admin', 'Clinic 2 Admin'
    initials        VARCHAR(10)  NOT NULL DEFAULT 'AD',-- 'A1', 'A2'
    role            VARCHAR(20)  NOT NULL DEFAULT 'admin'
                    CHECK (role IN ('admin', 'staff', 'superadmin')),
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS patients (
    id              BIGSERIAL PRIMARY KEY,
    first_name      VARCHAR(60)  NOT NULL,
    last_name       VARCHAR(60)  NOT NULL,
    middle_name     VARCHAR(60)  DEFAULT '',
    email           VARCHAR(120) NOT NULL UNIQUE,
    phone           VARCHAR(30)  NOT NULL,
    age             SMALLINT     NOT NULL CHECK (age >= 0 AND age <= 125),
    gender          VARCHAR(20)  NOT NULL CHECK (gender IN ('Female', 'Male', 'Prefer not to say')),
    password_hash   VARCHAR(255) NOT NULL,
    is_demo         BOOLEAN      NOT NULL DEFAULT FALSE,
    status          VARCHAR(20)  NOT NULL DEFAULT 'Active'
                    CHECK (status IN ('Active', 'Inactive', 'Suspended')),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_patients_email ON patients (email);
CREATE INDEX IF NOT EXISTS ix_patients_phone ON patients (phone);
DROP TRIGGER IF EXISTS trg_patients_updated ON patients;
CREATE TRIGGER trg_patients_updated
    BEFORE UPDATE ON patients
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_otps (
    id          BIGSERIAL PRIMARY KEY,
    user_type   VARCHAR(10) NOT NULL CHECK (user_type IN ('patient', 'admin')),
    user_id     BIGINT      NOT NULL,
    otp_code    VARCHAR(10) NOT NULL,
    purpose     VARCHAR(30) NOT NULL DEFAULT 'login'
                CHECK (purpose IN ('login', 'register', 'password_reset')),
    expires_at  TIMESTAMPTZ NOT NULL,
    is_used     BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_otps_lookup ON patient_otps (user_type, user_id, otp_code, is_used);

CREATE TABLE IF NOT EXISTS patient_records (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    birthdate               DATE,
    sex                     VARCHAR(10),
    nickname                VARCHAR(50),
    religion                VARCHAR(50),
    nationality             VARCHAR(50),
    home_address            VARCHAR(255),
    occupation              VARCHAR(100),
    dental_insurance        VARCHAR(100),
    effective_date          DATE,
    home_no                 VARCHAR(30),
    office_no               VARCHAR(30),
    fax_no                  VARCHAR(30),
    cell_no                 VARCHAR(30),
    email                   VARCHAR(120),
    guardian_name           VARCHAR(100),              -- for minors
    guardian_occupation     VARCHAR(100),
    prev_dentist            VARCHAR(100),
    last_dental_visit       DATE,
    reason_for_consultation TEXT,
    is_completed            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
DROP TRIGGER IF EXISTS trg_patient_records_updated ON patient_records;
CREATE TRIGGER trg_patient_records_updated
    BEFORE UPDATE ON patient_records
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_medical_histories (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    physician_name          VARCHAR(100),
    physician_specialty     VARCHAR(100),
    physician_office_no     VARCHAR(30),
    physician_office_addr   VARCHAR(255),
    in_good_health          BOOLEAN NOT NULL DEFAULT TRUE,
    under_treatment         BOOLEAN NOT NULL DEFAULT FALSE,
    treatment_details       VARCHAR(255),
    serious_illness_or_op   BOOLEAN NOT NULL DEFAULT FALSE,
    illness_details         VARCHAR(255),
    hospitalized            BOOLEAN NOT NULL DEFAULT FALSE,
    hospitalized_details    VARCHAR(255),
    taking_medication       BOOLEAN NOT NULL DEFAULT FALSE,
    medication_details      VARCHAR(255),
    tobacco_use             BOOLEAN NOT NULL DEFAULT FALSE,
    alcohol_drug_use        BOOLEAN NOT NULL DEFAULT FALSE,
    allergies               TEXT[]  DEFAULT ARRAY[]::TEXT[],   -- e.g. {Local anesthetic, Penicillin, Latex}
    allergy_other           VARCHAR(255),
    women_pregnant          BOOLEAN,
    women_nursing           BOOLEAN,
    women_birth_control     BOOLEAN,
    blood_type              VARCHAR(10),               -- e.g. 'O+', 'A+'
    blood_pressure          VARCHAR(20),               -- e.g. '120/80'
    conditions              TEXT[]  DEFAULT ARRAY[]::TEXT[],   -- e.g. {High blood pressure, Diabetes, Asthma}
    condition_other         VARCHAR(255),
    is_completed            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

DROP TRIGGER IF EXISTS trg_patient_med_updated ON patient_medical_histories;
CREATE TRIGGER trg_patient_med_updated
    BEFORE UPDATE ON patient_medical_histories
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS patient_consents (
    patient_id              BIGINT PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
    has_agreed              BOOLEAN NOT NULL DEFAULT TRUE,
    signature_data          TEXT    NOT NULL,          -- base64 data-URL or file storage path
    signature_date          DATE    NOT NULL DEFAULT CURRENT_DATE,
    sig_tries_used          SMALLINT NOT NULL DEFAULT 1,
    status                  VARCHAR(15) NOT NULL DEFAULT 'pending'
                            CHECK (status IN ('none', 'pending', 'approved', 'rejected')),
    rejection_note          VARCHAR(255),
    reviewed_by_admin_id    INT REFERENCES admins(id) ON DELETE SET NULL,
    reviewed_at             TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_patient_consents_status ON patient_consents (status);
DROP TRIGGER IF EXISTS trg_patient_consents_updated ON patient_consents;
CREATE TRIGGER trg_patient_consents_updated
    BEFORE UPDATE ON patient_consents
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE OR REPLACE FUNCTION can_patient_book(p_id BIGINT) RETURNS BOOLEAN AS $$
DECLARE
    med_done BOOLEAN;
    con_approved BOOLEAN;
BEGIN
    SELECT COALESCE(is_completed, FALSE) INTO med_done
    FROM patient_medical_histories WHERE patient_id = p_id;
    SELECT (status = 'approved') INTO con_approved
    FROM patient_consents WHERE patient_id = p_id;
    RETURN COALESCE(med_done, FALSE) AND COALESCE(con_approved, FALSE);
END;
$$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS appointments (
    id                  BIGSERIAL PRIMARY KEY,
    ref                 VARCHAR(12)  NOT NULL UNIQUE,  -- e.g. MSC-A1B2C3
    patient_id          BIGINT       REFERENCES patients(id) ON DELETE SET NULL, -- connected registered patient
    branch_id           SMALLINT     NOT NULL REFERENCES branches(id),
    service_id          SMALLINT     NOT NULL REFERENCES services(id),
    dentist_id          SMALLINT     REFERENCES dentists(id) ON DELETE SET NULL,
    appointment_date    DATE         NOT NULL,
    appointment_time    TIME         NOT NULL,
    first_name          VARCHAR(60)  NOT NULL,
    last_name           VARCHAR(60)  NOT NULL,
    phone               VARCHAR(20)  NOT NULL,
    email               VARCHAR(120) NOT NULL,
    is_current_patient  BOOLEAN      NOT NULL DEFAULT FALSE,
    comments            VARCHAR(500) NOT NULL DEFAULT '',
    status              VARCHAR(12)  NOT NULL DEFAULT 'Pending'
                        CHECK (status IN ('Pending', 'Confirmed', 'Completed', 'Cancelled', 'No-show')),
    admin_notes         TEXT         DEFAULT '',
    reviewed_by_admin_id INT         REFERENCES admins(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_appointments_slot
    ON appointments (appointment_date, appointment_time)
    WHERE status <> 'Cancelled';
CREATE INDEX IF NOT EXISTS ix_appointments_date       ON appointments (appointment_date);
CREATE INDEX IF NOT EXISTS ix_appointments_status     ON appointments (status);
CREATE INDEX IF NOT EXISTS ix_appointments_branch     ON appointments (branch_id);
CREATE INDEX IF NOT EXISTS ix_appointments_patient_id ON appointments (patient_id);
CREATE INDEX IF NOT EXISTS ix_appointments_phone      ON appointments (phone);
DROP TRIGGER IF EXISTS trg_appointments_updated ON appointments;
CREATE TRIGGER trg_appointments_updated
    BEFORE UPDATE ON appointments
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
-- Trigger: Automatically link patient_id if guest books using registered patient email
CREATE OR REPLACE FUNCTION auto_link_patient_to_appointment() RETURNS trigger AS $$
BEGIN
    IF NEW.patient_id IS NULL THEN
        SELECT id INTO NEW.patient_id FROM patients WHERE LOWER(email) = LOWER(NEW.email) LIMIT 1;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_appointments_autolink ON appointments;
CREATE TRIGGER trg_appointments_autolink
    BEFORE INSERT ON appointments
    FOR EACH ROW EXECUTE FUNCTION auto_link_patient_to_appointment();

CREATE TABLE IF NOT EXISTS dental_charts (
    id                  BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT       NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    tooth_number        SMALLINT     NOT NULL CHECK (tooth_number BETWEEN 11 AND 85),
    condition_code      VARCHAR(20)  NOT NULL,         -- 'C', 'M', 'F', 'CR', 'X', 'RT'
    notes               TEXT         DEFAULT '',
    updated_by_admin_id INT          REFERENCES admins(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT uq_patient_tooth UNIQUE (patient_id, tooth_number)
);
CREATE INDEX IF NOT EXISTS ix_dental_charts_patient ON dental_charts (patient_id);
DROP TRIGGER IF EXISTS trg_dental_charts_updated ON dental_charts;
CREATE TRIGGER trg_dental_charts_updated
    BEFORE UPDATE ON dental_charts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS treatments (
    id                  BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT       NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    branch_id           SMALLINT     NOT NULL REFERENCES branches(id),
    appointment_id      BIGINT       REFERENCES appointments(id) ON DELETE SET NULL,
    treatment_date      DATE         NOT NULL DEFAULT CURRENT_DATE,
    procedure_name      VARCHAR(100) NOT NULL,         -- 'Root Canal Treatment', 'Cleaning', 'Crown'
    tooth               VARCHAR(30)  DEFAULT '—',      -- '#21', '#26', 'Full mouth', or '—'
    dentist_name        VARCHAR(100) NOT NULL DEFAULT 'Dr. Marilou S. Cariño',
    cost                NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    notes               TEXT         DEFAULT '',
    created_by_admin_id INT          REFERENCES admins(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_treatments_patient ON treatments (patient_id);
CREATE INDEX IF NOT EXISTS ix_treatments_date    ON treatments (treatment_date DESC);
CREATE INDEX IF NOT EXISTS ix_treatments_branch  ON treatments (branch_id);

CREATE TABLE IF NOT EXISTS notifications (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT       NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    appointment_id  BIGINT       REFERENCES appointments(id) ON DELETE SET NULL,
    title           VARCHAR(150) NOT NULL,
    message         TEXT         NOT NULL,
    is_read         BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_notifications_patient ON notifications (patient_id, is_read

CREATE TABLE IF NOT EXISTS contact_messages (
    id                   BIGSERIAL PRIMARY KEY,
    name                 VARCHAR(100) NOT NULL,
    mobile               VARCHAR(20)  NOT NULL,
    email                VARCHAR(120),
    branch_id            SMALLINT     NOT NULL REFERENCES branches(id),
    message              TEXT         NOT NULL,
    is_read              BOOLEAN      NOT NULL DEFAULT FALSE,
    replied_at           TIMESTAMPTZ,
    replied_by_admin_id  INT          REFERENCES admins(id) ON DELETE SET NULL,
    sender               VARCHAR(10)  NOT NULL DEFAULT 'patient',
    is_ai                BOOLEAN      NOT NULL DEFAULT FALSE,
    needs_human          BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_messages_created ON contact_messages (created_at DESC);
CREATE INDEX IF NOT EXISTS ix_messages_branch  ON contact_messages (branch_id);

CREATE OR REPLACE VIEW v_appointments_full AS
SELECT
    a.id,
    a.ref,
    a.patient_id,
    COALESCE(p.first_name || ' ' || p.last_name, a.first_name || ' ' || a.last_name) AS patient_name,
    COALESCE(p.email, a.email) AS email,
    COALESCE(p.phone, a.phone) AS phone,
    b.id AS branch_id,
    b.code AS branch_code,
    b.name AS branch_name,
    b.city AS branch_city,
    s.id AS service_id,
    s.name AS service_name,
    s.category AS service_category,
    COALESCE(d.name, 'Dr. Marilou S. Cariño') AS dentist_name,
    a.appointment_date,
    to_char(a.appointment_time, 'HH12:MI AM') AS appointment_time_formatted,
    a.appointment_time,
    a.status,
    a.is_current_patient,
    a.comments,
    a.admin_notes,
    adm.display_name AS reviewed_by,
    a.created_at,
    a.updated_at
FROM appointments a
JOIN branches b ON b.id = a.branch_id
JOIN services s ON s.id = a.service_id
LEFT JOIN dentists d ON d.id = a.dentist_id
LEFT JOIN patients p ON p.id = a.patient_id
LEFT JOIN admins adm ON adm.id = a.reviewed_by_admin_id;

CREATE OR REPLACE VIEW v_patient_records_overview AS
SELECT
    p.id AS patient_id,
    p.first_name || ' ' || p.last_name AS full_name,
    p.email,
    p.phone,
    p.age,
    p.gender,
    COALESCE(pr.is_completed, FALSE) AS personal_info_done,
    COALESCE(pm.is_completed, FALSE) AS medical_history_done,
    COALESCE(pc.status, 'none') AS consent_status,
    pc.signature_date,
    pc.sig_tries_used,
    pc.rejection_note,
    adm.display_name AS consent_reviewed_by,
    can_patient_book(p.id) AS can_book_appointment,
    p.created_at AS registered_at
FROM patients p
LEFT JOIN patient_records pr ON pr.patient_id = p.id
LEFT JOIN patient_medical_histories pm ON pm.patient_id = p.id
LEFT JOIN patient_consents pc ON pc.patient_id = p.id
LEFT JOIN admins adm ON adm.id = pc.reviewed_by_admin_id;

-- -----------------------------------------------------------------------------
-- AI chatbot (Gemini) for Messages  -  safe to run more than once
--   sender       'patient' | 'admin'   (who wrote the message)
--   is_ai        true  = the reply was written by the AI chatbot
--   needs_human  true  = the AI could not answer this patient message; admin must reply
-- -----------------------------------------------------------------------------
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS sender      varchar(10) NOT NULL DEFAULT 'patient';
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS is_ai       boolean     NOT NULL DEFAULT false;
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS needs_human boolean     NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS ix_messages_email ON contact_messages (lower(email));
CREATE INDEX IF NOT EXISTS ix_messages_needs_human ON contact_messages (branch_id) WHERE needs_human AND NOT is_read;
