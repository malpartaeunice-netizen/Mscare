MSCare PostgreSQL database
==========================
Connection (includes/db.php, both mscare and mscareadmin)
  host localhost | port 5432 | database mscare | user postgres | password 0519

Fresh install
  createdb -U postgres mscare
  psql -U postgres -d mscare -f mscare_clean_schema.sql

Existing database (keeps all data) - fixes "column p.branch_id does not exist"
  psql -U postgres -d mscare -f fix_existing_db.sql

Admin logins after a fresh install: admin1 / admin2, password admin123.
Gmail/SMTP settings are NOT in the SQL: enter them in Admin > Settings.
