-- Add everything the PHP code needs on top of mscare(2).sql. Safe to run many times. Only ADDS, never drops.
-- psql -U postgres -d mscare -f add_missing_to_mscare2.sql
BEGIN;

-- patients
ALTER TABLE patients ADD COLUMN IF NOT EXISTS branch_id SMALLINT REFERENCES branches(id) ON DELETE SET NULL;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified     BOOLEAN     NOT NULL DEFAULT FALSE;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified_at  TIMESTAMPTZ;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS failed_attempts    SMALLINT    NOT NULL DEFAULT 0;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS locked_at          TIMESTAMPTZ;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_token   VARCHAR(64);
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_expires TIMESTAMPTZ;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_sent_at TIMESTAMPTZ;
ALTER TABLE patient_otps ADD COLUMN IF NOT EXISTS attempts SMALLINT NOT NULL DEFAULT 0;

-- appointments / treatments
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS email_reminded_at TIMESTAMPTZ;
ALTER TABLE treatments ADD COLUMN IF NOT EXISTS payment_method VARCHAR(20) NOT NULL DEFAULT 'Cash';
ALTER TABLE treatments ADD COLUMN IF NOT EXISTS amount_paid NUMERIC(10,2);
UPDATE treatments SET amount_paid = cost WHERE amount_paid IS NULL;

-- notifications (admin notifications)
ALTER TABLE notifications ALTER COLUMN patient_id DROP NOT NULL;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS admin_id  BIGINT REFERENCES admins(id) ON DELETE SET NULL;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS branch_id SMALLINT;

-- new tables
CREATE TABLE IF NOT EXISTS clinic_settings (
    branch_id SMALLINT NOT NULL, setting_key VARCHAR(60) NOT NULL,
    setting_value TEXT NOT NULL DEFAULT '', updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (branch_id, setting_key));
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id BIGSERIAL PRIMARY KEY, admin_id INTEGER, branch_id SMALLINT,
    action VARCHAR(80) NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS admin_notif_reads (
    admin_id INTEGER NOT NULL, notif_key VARCHAR(40) NOT NULL, read_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (admin_id, notif_key));

-- indexes
CREATE INDEX IF NOT EXISTS ix_patients_branch              ON patients (branch_id);
CREATE INDEX IF NOT EXISTS ix_patients_created             ON patients (created_at);
CREATE INDEX IF NOT EXISTS ix_otps_user_purpose            ON patient_otps (user_type, user_id, purpose, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_appointments_branch_date     ON appointments (branch_id, appointment_date);
CREATE INDEX IF NOT EXISTS ix_appointments_created         ON appointments (branch_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_appointments_reminder        ON appointments (appointment_date, appointment_time)
    WHERE email_reminded_at IS NULL AND status IN ('Pending', 'Confirmed');
CREATE INDEX IF NOT EXISTS ix_treatments_branch_date       ON treatments (branch_id, treatment_date);
CREATE INDEX IF NOT EXISTS ix_treatments_branch_method     ON treatments (branch_id, payment_method);
CREATE INDEX IF NOT EXISTS ix_notifications_admin          ON notifications (admin_id, is_read);
CREATE INDEX IF NOT EXISTS ix_notifications_patient_created ON notifications (patient_id, created_at DESC);

-- trigger: patient notification on appointment create / status change
CREATE OR REPLACE FUNCTION public.notify_appointment_change() RETURNS trigger
    LANGUAGE plpgsql AS $$
DECLARE msg text; tit text;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message)
            VALUES (NEW.patient_id, NEW.id, 'Appointment Request Received',
                'Your appointment request for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been received. The clinic will confirm your schedule shortly.');
        END IF;
        RETURN NEW;
    END IF;
    IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
        CASE NEW.status
            WHEN 'Confirmed' THEN tit := 'Appointment Confirmed';
                msg := 'Great news! Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been confirmed.';
            WHEN 'Cancelled' THEN tit := 'Appointment Cancelled';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been cancelled. You can book another time anytime.';
            WHEN 'Completed' THEN tit := 'Appointment Completed';
                msg := 'Your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || ' has been marked as completed.';
            WHEN 'No-show' THEN tit := 'Appointment Missed';
                msg := 'You missed your appointment for ' || to_char(NEW.appointment_date, 'Mon DD, YYYY') || ' at ' || to_char(NEW.appointment_time, 'HH12:MI AM') || '. Please contact the clinic to reschedule.';
            ELSE RETURN NEW;
        END CASE;
        IF NEW.patient_id IS NOT NULL THEN
            INSERT INTO public.notifications (patient_id, appointment_id, title, message) VALUES (NEW.patient_id, NEW.id, tit, msg);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_appointments_notify ON appointments;
CREATE TRIGGER trg_appointments_notify AFTER INSERT OR UPDATE ON appointments
    FOR EACH ROW EXECUTE FUNCTION public.notify_appointment_change();

COMMIT;
