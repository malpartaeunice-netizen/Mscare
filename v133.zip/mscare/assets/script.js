(function () {
  var btn = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');
  if (btn && links) {
    btn.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // password show / hide
  document.querySelectorAll('[data-toggle-pass]').forEach(function (b) {
    b.addEventListener('click', function () {
      var input = document.getElementById(b.getAttribute('data-toggle-pass'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      b.classList.toggle('on', show);
    });
  });

  // names are stored in capital letters
  document.querySelectorAll('[data-uppercase]').forEach(function (el) {
    el.addEventListener('input', function () {
      var a = el.selectionStart, z = el.selectionEnd, u = el.value.toUpperCase();
      if (u !== el.value) { el.value = u; try { el.setSelectionRange(a, z); } catch (e) {} }
    });
  });

  var search = document.getElementById('svcSearch');
  var grid = document.getElementById('svcGrid');
  if (!search || !grid) return;
  var cards = grid.querySelectorAll('.svc-card');
  var chips = document.querySelectorAll('#svcChips .chip');
  var count = document.getElementById('svcCount');
  var empty = document.getElementById('svcEmpty');
  var cat = '';

  function apply() {
    var q = search.value.trim().toLowerCase();
    var shown = 0;
    cards.forEach(function (card) {
      var match = (!q || card.getAttribute('data-text').indexOf(q) > -1) &&
                  (!cat || card.getAttribute('data-cat') === cat);
      card.hidden = !match;
      if (match) shown++;
    });
    count.textContent = shown + (shown === 1 ? ' service' : ' services');
    empty.hidden = shown !== 0;
  }

  search.addEventListener('input', apply);
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('on'); });
      chip.classList.add('on');
      cat = chip.getAttribute('data-cat');
      apply();
    });
  });
})();

/* ---- live password checklist: any <input data-pw-check> ---- */
(function () {
  var rules = [
    ['upper', 'Add an uppercase letter.',   function (v) { return /[A-Z]/.test(v); }],
    ['num',   'Add a number.',              function (v) { return /[0-9]/.test(v); }],
    ['sym',   'Add a symbol like ! @ # $.', function (v) { return /[^A-Za-z0-9\s]/.test(v); }]
  ];
  document.querySelectorAll('input[data-pw-check]').forEach(function (input) {
    var ul = document.createElement('ul'); ul.className = 'pw-rules'; ul.setAttribute('aria-live', 'polite');
    var items = rules.map(function (r) { var li = document.createElement('li'); li.textContent = r[1]; ul.appendChild(li); return li; });
    var anchor = input.closest('.input-icon') || input;
    anchor.insertAdjacentElement('afterend', ul);
    function check() {
      var v = input.value;
      rules.forEach(function (r, i) { items[i].className = v === '' ? '' : (r[2](v) ? 'ok' : 'bad'); });
    }
    // keep the three rules on one row: shrink the text just enough to fit the width
    function fit() {
      ul.style.fontSize = '';
      var size = parseFloat(getComputedStyle(ul).fontSize);
      if (!ul.clientWidth) return;
      while (ul.scrollWidth > ul.clientWidth + 1 && size > 11) { size -= 0.2; ul.style.fontSize = size + 'px'; }
    }
    input.addEventListener('input', check); check();
    fit(); window.addEventListener('resize', fit);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  });
})();
