<?php
require_once __DIR__ . '/auth.php';
$page  = $page  ?? 'home';
$title = $title ?? 'Home';
$nav = ['home' => ['index.php', 'Home'], 'about' => ['about.php', 'About Us'],
        'services' => ['services.php', 'Services'], 'contact' => ['contact.php', 'Contact']];
$me = current_patient();
// Signed-in patients live in the patient portal: bounce them off the public pages.
if ($me && in_array($page, ['home', 'about', 'services', 'contact', 'book'], true)) {
    header('Location: patient-dashboard.php');
    exit;
}
$brandHref = $me ? 'patient-dashboard.php' : 'index.php';
// Notification bell (signed-in patients): messages the clinic sent from the admin site.
$notifs = []; $notifUnread = 0;
if ($me) {
    try {
        $ns = db()->prepare("SELECT id, title, message, is_read, created_at FROM notifications WHERE patient_id = :p ORDER BY created_at DESC, id DESC LIMIT 8");
        $ns->execute([':p' => $me['id']]);
        $notifs = $ns->fetchAll();
        $nc = db()->prepare("SELECT COUNT(*) FROM notifications WHERE patient_id = :p AND is_read = FALSE");
        $nc->execute([':p' => $me['id']]);
        $notifUnread = (int)$nc->fetchColumn();
    } catch (Throwable $ex) { error_log('MSCare notifications: ' . $ex->getMessage()); }
}
// Admin notifications (admin_id IS NULL means visible to all admins)
$adminNotifs = []; $adminNotifUnread = 0;
$admin = current_admin();
if ($admin) {
    try {
        $aid = (int)$admin['id'];
$ab  = (int)($admin['branch_id'] ?? 0);
        $ans = db()->prepare("SELECT id, title, message, is_read, created_at, patient_id, appointment_id FROM notifications WHERE (admin_id IS NULL OR admin_id = :aid) AND (branch_id IS NULL OR :ab = 0 OR branch_id = :ab) ORDER BY created_at DESC, id DESC LIMIT 8");
        $ans->execute([':aid' => $aid, ':ab' => $ab]);
        $adminNotifs = $ans->fetchAll();
        $anc = db()->prepare("SELECT COUNT(*) FROM notifications WHERE (admin_id IS NULL OR admin_id = :aid) AND (branch_id IS NULL OR :ab = 0 OR branch_id = :ab) AND is_read = FALSE");
        $anc->execute([':aid' => $aid, ':ab' => $ab]);
        $adminNotifUnread = (int)$anc->fetchColumn();
    } catch (Throwable $ex) { error_log('MSCare admin notifications: ' . $ex->getMessage()); }
}
function time_ago_label($ts) {
    $d = time() - strtotime($ts);
    if ($d < 60) return 'Just now';
    if ($d < 3600) return floor($d / 60) . ' min ago';
    if ($d < 86400) return floor($d / 3600) . ' hr ago';
    return date('M j, g:i A', strtotime($ts));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> | <?= e($clinic['name']) ?></title>
<meta name="description" content="MSCare Dental Clinic in Makati and Manila. General dentistry, cleaning, braces, root canal and more.">
<meta name="theme-color" content="#0B2A40">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/../assets/style.css') ?>">
<link rel="stylesheet" href="assets/portal.css?v=<?= filemtime(__DIR__ . '/../assets/portal.css') ?>">
<script src="assets/dialog.js?v=20261027"></script>
</head>
<body class="<?= $admin ? 'admin' : '' ?><?= !empty($body_class) ? ' ' . e($body_class) : '' ?>">
<a class="skip" href="#main">Skip to content</a>
<header class="nav">
  <div class="container nav-inner">
    <a class="brand" href="<?= $brandHref ?>">
      <?= icon($services[0][2], 26) ?>
      <span><?= e($clinic['short']) ?></span>
    </a>
    <button class="nav-toggle" id="navToggle" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
    <nav class="nav-links" id="navLinks">
      <?php if (!$me): ?>
        <?php foreach ($nav as $key => [$href, $label]): ?>
          <a href="<?= $href ?>"<?= $page === $key ? ' class="active" aria-current="page"' : '' ?>><?= $label ?></a>
        <?php endforeach; ?>
      <?php endif; ?>
      <?php if ($me || $admin): ?>
        <div class="p-notif" id="pNotif">
          <button type="button" class="p-bell" id="pBell" onclick="event.stopPropagation();var p=document.getElementById('pNotifPanel');if(p){p.hidden=!p.hidden;this.setAttribute('aria-expanded',p.hidden?'false':'true');}" aria-label="Notifications<?= ($notifUnread ?? 0) ? ' (' . ($notifUnread ?? 0) . ' unread)' : '' ?>" aria-haspopup="true" aria-expanded="false">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
            <span class="p-bell-dot" id="pBellDot"<?= (($notifUnread ?? 0) + ($adminNotifUnread ?? 0)) ? '' : ' hidden' ?>><?= (($notifUnread ?? 0) + ($adminNotifUnread ?? 0)) > 9 ? '9+' : (($notifUnread ?? 0) + ($adminNotifUnread ?? 0)) ?></span>
          </button>
          <div class="p-notif-panel" id="pNotifPanel" role="region" aria-label="Notifications" hidden>
            <div class="p-notif-head"><strong>Notifications</strong><button type="button" id="pMarkAll" onclick="event.stopPropagation();var act=document.body.classList.contains('admin')?'mark_admin_notifications_read':'mark_notifications_read';fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:act})}).then(function(r){return r.json();}).then(function(d){if(d.ok){document.querySelectorAll('#pNotifPanel .p-notif-item.unread').forEach(function(i){i.classList.remove('unread');});var n=document.querySelectorAll('#pNotifPanel .p-notif-item.unread').length;var dot=document.getElementById('pBellDot');if(dot){dot.hidden=n===0;dot.textContent=n>9?'9+':n;}var all=document.getElementById('pMarkAll');if(all)all.hidden=n===0;}});"<?= ((($notifUnread ?? 0) + ($adminNotifUnread ?? 0)) ? '' : ' hidden') ?>>Mark all as read</button></div>
            <?php
              $allNotifs = array_merge(
                array_map(function($n){ $n['_for']='patient'; return $n; }, $notifs ?? []),
                array_map(function($n){ $n['_for']='admin'; return $n; }, $adminNotifs ?? [])
              );
              usort($allNotifs, function($a,$b){ return strtotime($b['created_at']) - strtotime($a['created_at']); });
              $allNotifs = array_slice($allNotifs, 0, 8);
            ?>
            <?php if (!$allNotifs): ?>
              <div class="p-notif-empty">No notifications yet. Updates about appointments, signatures, and messages will appear here.</div>
            <?php else: foreach ($allNotifs as $n): ?>
              <a class="p-notif-item<?= $n['is_read'] ? '' : ' unread' ?>" href="<?= $n['_for'] === 'admin' ? 'notifications.php' : (stripos((string)($n['title'] ?? ''), 'signature') !== false ? 'patient-record.php' : 'patient-appointments.php') ?>" data-id="<?= (int)$n['id'] ?>" onclick="var a=this;var act=document.body.classList.contains('admin')?'mark_admin_notifications_read':'mark_notifications_read';fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:act,id:+a.dataset.id}),keepalive:true});">
                <strong><?= e($n['title']) ?></strong>
                <span><?= e($n['message']) ?></span>
                <small><?= e(time_ago_label($n['created_at'])) ?></small>
              </a>
            <?php endforeach; endif; ?>
            <?php if ($admin): ?>
            <a class="p-notif-viewall" href="notifications.php">View all notifications</a>
            <?php endif; ?>
          </div>
        </div>
        <a class="nav-user<?= $page === 'portal' ? ' active' : '' ?>" href="patient-dashboard.php">
          <span class="avatar-sm"><?= e($me['initials']) ?></span><span><?= e($me['first_name']) ?></span>
        </a>
        <a class="btn btn-outline btn-sm btn-pill nav-login" href="login.php?logout=1">Log out</a>
      <?php else: ?>
        <a class="btn btn-outline btn-sm btn-pill nav-login<?= $page === 'login' ? ' is-current' : '' ?>" href="login.php"><?= icon($ui['user'], 16) ?> Log in</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php if ($me || $admin): ?>
<script>
(function(){
  var bell=document.getElementById('pBell'),panel=document.getElementById('pNotifPanel'),dot=document.getElementById('pBellDot'),all=document.getElementById('pMarkAll');
  var isAdmin = document.body.classList.contains('admin');
  if(!bell||!panel)return;
  function setOpen(o){panel.hidden=!o;bell.setAttribute('aria-expanded',o?'true':'false');}
  function api(body){return fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(function(r){return r.json();});}
  function refreshDot(){var n=panel.querySelectorAll('.p-notif-item.unread').length;dot.hidden=n===0;dot.textContent=n>9?'9+':n;if(all)all.hidden=n===0;}
  // bell toggle handled inline (above) to guarantee it works even if listeners fail to attach
  panel.addEventListener('click',function(e){e.stopPropagation();});
  document.addEventListener('click',function(e){if(!panel.contains(e.target)&&!bell.contains(e.target))setOpen(false);});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')setOpen(false);});
  // mark-all handled inline (above) to guarantee it works
  // item mark-read handled inline (above) to guarantee it works
})();
</script>
<?php endif; ?>
<main id="main">
