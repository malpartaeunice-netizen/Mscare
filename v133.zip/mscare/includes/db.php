<?php
// PostgreSQL connection (PDO). Edit the values below, or set the environment
// variables MSC_DB_HOST / MSC_DB_PORT / MSC_DB_NAME / MSC_DB_USER / MSC_DB_PASS.
// Set to true while setting up: the real database error is shown on the page.
// Set back to false before going live.
if (!defined('MSC_DEBUG')) define('MSC_DEBUG', true);

function db_fail_text(PDOException $ex, $fallback) {
    return MSC_DEBUG ? $fallback . ' [DB error: ' . $ex->getMessage() . ']' : $fallback;
}

/** True only when the unique violation is the "date + time already booked" index (not some other duplicate key). */
function is_slot_conflict(PDOException $ex) {
    return $ex->getCode() === '23505' && strpos($ex->getMessage(), 'uq_appointments_slot') !== false;
}

/** True when an auto-number (id) column hit a duplicate key, i.e. its sequence is behind the data (happens after importing/restoring a database). */
function is_sequence_conflict(PDOException $ex) {
    return $ex->getCode() === '23505' && preg_match('/_pkey/', $ex->getMessage()) === 1;
}

/** Moves every id sequence past the highest existing id. Safe to run any time. */
function fix_sequences(PDO $pdo) {
    foreach (['branches','services','dentists','admins','patients','patient_otps','appointments','dental_charts','treatments','notifications','contact_messages','admin_audit_logs'] as $t) {
        try {
            $seq = $pdo->query("SELECT pg_get_serial_sequence('public.$t', 'id')")->fetchColumn();
            if ($seq) $pdo->query("SELECT setval('$seq', GREATEST((SELECT COALESCE(MAX(id), 0) FROM public.$t), 1))");
        } catch (PDOException $ex) { /* table missing - ignore */ }
    }
}

function db() {
    static $pdo = null;
    if ($pdo) return $pdo;

    $host = getenv('MSC_DB_HOST') ?: 'localhost';
    $port = getenv('MSC_DB_PORT') ?: '5432';
    $name = getenv('MSC_DB_NAME') ?: 'mscare';
    $user = getenv('MSC_DB_USER') ?: 'postgres';
    $pass = getenv('MSC_DB_PASS') ?: '0519';      // database password

    if (!extension_loaded('pdo_pgsql')) {
        throw new PDOException('PHP driver pdo_pgsql is not enabled. In php.ini remove the ; before extension=pdo_pgsql and extension=pgsql, then restart Apache.');
    }

    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$name", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo->exec("SET TIME ZONE 'Asia/Manila'");
    return $pdo;
}
