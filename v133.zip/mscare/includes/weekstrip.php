<?php
$all = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
?>
<div class="week" role="list" aria-label="Which clinic is open each day">
  <?php foreach ($all as $d):
      $open = null;
      foreach ($branches as $b) { if (in_array($d, $b['days'], true)) $open = $b; }
  ?>
    <div class="week-day <?= $open ? 'open-' . $open['tone'] : 'closed' ?>" role="listitem">
      <span class="wd"><?= $d ?></span>
      <span class="wc"><?= $open ? e($open['city']) : 'Closed' ?></span>
    </div>
  <?php endforeach; ?>
</div>
