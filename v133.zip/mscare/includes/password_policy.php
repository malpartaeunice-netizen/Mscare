<?php
// Password rules for every place a NEW password is created (register, reset, change, new admin).
// Login is not checked here, so existing accounts can still sign in; they follow the rules
// the next time they change their password.
//
//   1. Length 8-72 characters
//   2. Uppercase + lowercase + number + special character, no spaces
//   3. Not a common / leaked password (built-in list + optional Have I Been Pwned check)
//   4. No personal information: name, email, username, phone number
//   5. No obvious patterns: 1234, abcd, qwer, aaaa ...
if (!defined('MSC_PW_CHECK_BREACHED')) define('MSC_PW_CHECK_BREACHED', true);   // false = never contact the internet

if (!function_exists('password_policy_error')) {

    /** Short list of the passwords people use most (matched after removing digits/symbols from the ends). */
    function password_common_list() {
        return ['password', 'passw0rd', 'qwerty', 'qwertyuiop', 'asdfgh', 'asdfghjkl', 'zxcvbn', 'letmein', 'welcome',
                'iloveyou', 'ilovethis', 'monkey', 'dragon', 'master', 'login', 'admin', 'administrator', 'root',
                'abc123', 'football', 'baseball', 'princess', 'sunshine', 'superman', 'batman', 'trustno', 'shadow',
                'michael', 'jordan', 'hello', 'freedom', 'whatever', 'qazwsx', 'mscare', 'dental', 'clinic', 'patient',
                'philippines', 'pilipinas', 'manila', 'makati', 'mahalkita', 'iloveyou', 'angelo', 'jonathan'];
    }

    /** Pure parser for the Have I Been Pwned range answer ("SUFFIX:COUNT" lines). Returns the breach count. */
    function password_breach_count_from_range($body, $suffix) {
        foreach (preg_split('/\r?\n/', (string)$body) as $line) {
            $parts = explode(':', trim($line));
            if (count($parts) === 2 && strcasecmp($parts[0], $suffix) === 0) return (int)$parts[1];
        }
        return 0;
    }

    /**
     * Have I Been Pwned "range" lookup. Only the first 5 characters of the SHA-1 are sent (k-anonymity),
     * so the password never leaves the server. Fails open: no internet / slow answer = treated as not found.
     */
    function password_is_breached($pw) {
        if (!MSC_PW_CHECK_BREACHED) return false;
        $sha = strtoupper(sha1((string)$pw));
        $url = 'https://api.pwnedpasswords.com/range/' . substr($sha, 0, 5);
        $ctx = stream_context_create(['http' => ['timeout' => 2, 'header' => "User-Agent: MSCare-password-check\r\nAdd-Padding: true\r\n", 'ignore_errors' => true]]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false || $body === '') return false;
        return password_breach_count_from_range($body, substr($sha, 5)) > 0;
    }

    /** Returns null when the password is acceptable, otherwise a short message saying what is wrong. */
    function password_policy_error($pw, array $ctx = []) {
        $pw = (string)$pw;
        if (strlen($pw) < 8)                    return 'Password must be at least 8 characters.';
        if (strlen($pw) > 72)                   return 'Password must be 72 characters or fewer.';
        if (preg_match('/\s/', $pw))            return 'Password must not contain spaces.';
        if (!preg_match('/[A-Z]/', $pw))        return 'Password must include an uppercase letter (A-Z).';
        if (!preg_match('/[a-z]/', $pw))        return 'Password must include a lowercase letter (a-z).';
        if (!preg_match('/[0-9]/', $pw))        return 'Password must include a number (0-9).';
        if (!preg_match('/[^A-Za-z0-9]/', $pw)) return 'Password must include a special character (e.g. ! @ # $ %).';

        $low = strtolower($pw);

        // common words anywhere in the password (Password1!, Mscare@2026, Qwerty123# ...)
        foreach (password_common_list() as $bad) {
            if (strpos($low, $bad) !== false) return 'That password is too common. Please choose something less predictable.';
        }
        // obvious patterns: aaaa, 1111, 1234, abcd, 4321, qwer
        if (preg_match('/(.)\1{3,}/', $low)) return 'Password must not repeat the same character 4 or more times in a row.';
        $seq = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $rows = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
        for ($i = 0; $i + 4 <= strlen($low); $i++) {
            $chunk = substr($low, $i, 4);
            $rev = strrev($chunk);
            if (strpos($seq, $chunk) !== false || strpos($seq, $rev) !== false) return 'Password must not contain simple sequences like 1234 or abcd.';
            foreach ($rows as $r) if (strpos($r, $chunk) !== false || strpos($r, $rev) !== false) return 'Password must not contain keyboard patterns like qwer.';
        }

        // personal information: name, email, username, phone number (pass them in $ctx)
        $pwDigits = preg_replace('/\D/', '', $pw);
        foreach ($ctx as $v) {
            $v = strtolower(trim((string)$v));
            if ($v === '') continue;
            if (($at = strpos($v, '@')) !== false) {                       // email: check the whole thing and the part before @
                $local = substr($v, 0, $at);
                if (strlen($local) >= 3 && strpos($low, $local) !== false) return 'Password must not contain your name, email or username.';
            }
            if (strlen($v) >= 3 && strpos($low, $v) !== false) return 'Password must not contain your name, email or username.';
            foreach (preg_split('/[\s.\-_]+/', $v) as $word) {             // each word of a full name
                if (strlen($word) >= 4 && strpos($low, $word) !== false) return 'Password must not contain your name, email or username.';
            }
            $d = preg_replace('/\D/', '', $v);
            if (strlen($d) >= 6 && ($pwDigits !== '' && (strpos($pwDigits, $d) !== false || strpos($pwDigits, substr($d, -6)) !== false))) {
                return 'Password must not contain your phone number or other personal numbers.';
            }
        }

        // leaked / breached passwords (Have I Been Pwned, optional, fails open)
        if (password_is_breached($pw)) return 'This password has appeared in a known data breach. Please choose a different one.';
        return null;
    }
}
