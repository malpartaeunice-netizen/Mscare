<?php
// MSCare - email sending + verification-code helpers.
// The SENDER account (the mailbox the clinic sends from) is NOT written in code anymore:
// an admin sets it once in  Admin > Settings > Email Sender  and it is stored in the database.
// Verification codes can then be sent to ANY patient email address.
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/smtp.php';

/** Sender settings: database (set by admin) > environment variables > mail_config.php defaults. */
function mail_cfg() {
    static $c = null;
    if ($c !== null) return $c;
    $c = require __DIR__ . '/mail_config.php';
    try {
        $rows = db()->query("SELECT setting_key, setting_value FROM clinic_settings WHERE branch_id = 0 AND (setting_key LIKE 'smtp\\_%' OR setting_key = 'otp_minutes')")->fetchAll();
        $map = [];
        foreach ($rows as $r) $map[$r['setting_key']] = $r['setting_value'];
        $om = (int)($map['otp_minutes'] ?? 0);
        if ($om >= 1 && $om <= 60) $c['code_minutes'] = $om;     // set in Admin > Settings > Email Sender
        if (($map['smtp_username'] ?? '') !== '' && ($map['smtp_password'] ?? '') !== '') {
            $c['username'] = $map['smtp_username'];
            $c['password'] = $map['smtp_password'];
            if (($map['smtp_host'] ?? '') !== '')      $c['host'] = $map['smtp_host'];
            if ((int)($map['smtp_port'] ?? 0) > 0)     $c['port'] = (int)$map['smtp_port'];
            if (($map['smtp_from_name'] ?? '') !== '') $c['from_name'] = $map['smtp_from_name'];
            if (($map['smtp_from_email'] ?? '') !== '') $c['from_email'] = $map['smtp_from_email'];
        }
    } catch (Throwable $ex) { /* table may not exist yet - fall back to defaults */ }
    return $c;
}

function mail_is_configured() {
    $c = mail_cfg();
    $u = strtolower(trim((string)$c['username'])); $p = strtolower(str_replace(' ', '', (string)$c['password']));
    if ($u === '' || $p === '') return false;
    // sample values from the setup instructions are not real credentials
    if ($u === 'yourclinic@gmail.com' || $p === 'abcdefghijklmnop' || strpos($p, 'xxxx') !== false) return false;
    return true;
}

/** Send an email using the saved sender settings. Returns [true, ''] or [false, 'reason']. */
function smtp_send($to, $subject, $html, $text = '') {
    if (!mail_is_configured()) {
        return [false, 'Email is not set up yet. An admin must enter the REAL sender email and Gmail App Password in Admin > Settings > Email Sender.'];
    }
    return smtp_send_with(mail_cfg(), $to, $subject, $html, $text);
}

// ---------------------------------------------------------------------------
// Verification codes
// ---------------------------------------------------------------------------

/** Adds the columns/tables this feature needs, once. Works even if the .sql file was never run. */
function ensure_email_schema() {
    static $done = false; if ($done) return; $done = true;
    ensure_lock_schema();
    try {
        $pdo = db();
        $has = $pdo->query("SELECT 1 FROM information_schema.columns WHERE table_name='patients' AND column_name='email_verified'")->fetchColumn();
        if ($has) return;
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified BOOLEAN NOT NULL DEFAULT FALSE");
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMPTZ");
        $pdo->exec("UPDATE patients SET email_verified = TRUE, email_verified_at = now()");   // existing patients stay able to log in
        $pdo->exec("ALTER TABLE patient_otps ADD COLUMN IF NOT EXISTS attempts SMALLINT NOT NULL DEFAULT 0");
    } catch (PDOException $ex) { error_log('MSCare ensure_email_schema: ' . $ex->getMessage()); }
}

// ---------------------------------------------------------------------------
// Account lock after too many wrong passwords (3 tries) + reactivation link
// ---------------------------------------------------------------------------
if (!defined('MSC_MAX_LOGIN_ATTEMPTS')) define('MSC_MAX_LOGIN_ATTEMPTS', 3);
if (!defined('MSC_UNLOCK_HOURS'))       define('MSC_UNLOCK_HOURS', 24);      // how long the reactivation link works

/** Adds the lock columns once. Works even if account_lock.sql was never run. */
function ensure_lock_schema() {
    static $done = false; if ($done) return; $done = true;
    try {
        $pdo = db();
        $has = $pdo->query("SELECT 1 FROM information_schema.columns WHERE table_name='patients' AND column_name='reactivate_sent_at'")->fetchColumn();
        if ($has) return;
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS failed_attempts    SMALLINT NOT NULL DEFAULT 0");
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS locked_at          TIMESTAMPTZ");
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_token   VARCHAR(64)");
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_expires TIMESTAMPTZ");
        $pdo->exec("ALTER TABLE patients ADD COLUMN IF NOT EXISTS reactivate_sent_at TIMESTAMPTZ");
    } catch (PDOException $ex) { error_log('MSCare ensure_lock_schema: ' . $ex->getMessage()); }
}

/** Address of the patient site, used for the link inside emails. */
function site_base_url() {
    $cfg = trim((string)(mail_cfg()['base_url'] ?? ''));
    if ($cfg !== '') return rtrim($cfg, '/');
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host  = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $dir   = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https://' : 'http://') . $host . $dir;
}

/** Seconds before another reactivation email may be sent (0 = may send now). */
function unlock_wait_seconds(array $patient) {
    $cool = (int)mail_cfg()['resend_cooldown'];
    if (empty($patient['reactivate_sent_at'])) return 0;
    $s = db()->prepare("SELECT EXTRACT(EPOCH FROM (now() - reactivate_sent_at)) FROM patients WHERE id = :i");
    $s->execute([':i' => $patient['id']]);
    $age = $s->fetchColumn();
    return ($age === false || $age === null) ? 0 : max(0, (int)ceil($cool - (float)$age));
}

/** Make a fresh one-time reactivation link and email it. Returns [true,''] or [false,'reason']. */
function send_unlock_email(array $patient) {
    ensure_lock_schema();
    $token = bin2hex(random_bytes(32));
    db()->prepare("UPDATE patients SET reactivate_token = :t, reactivate_sent_at = now(),
                   reactivate_expires = now() + (:h || ' hours')::interval WHERE id = :i")
        ->execute([':t' => hash('sha256', $token), ':h' => (string)MSC_UNLOCK_HOURS, ':i' => $patient['id']]);

    $link = site_base_url() . '/reactivate.php?token=' . $token;
    $name = e(ucwords(strtolower($patient['first_name'])));
    $hrs  = (int)MSC_UNLOCK_HOURS;
    $subject = 'Reactivate your MSCare account';
    $html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:auto;border:1px solid #e3e8ea;border-radius:12px;overflow:hidden">'
          . '<div style="background:#0f6e6a;color:#fff;padding:18px 24px;font-size:20px;font-weight:bold">MSCare Dental Clinic</div>'
          . '<div style="padding:24px;color:#1f2d33;line-height:1.5"><p>Hi ' . $name . ',</p>'
          . '<p>Your account was locked after ' . (int)MSC_MAX_LOGIN_ATTEMPTS . ' wrong password attempts. Click the button below to reactivate it:</p>'
          . '<p style="text-align:center;margin:24px 0"><a href="' . e($link) . '" style="background:#1fa8a0;color:#fff;text-decoration:none;font-weight:bold;padding:13px 26px;border-radius:999px;display:inline-block">Reactivate my account</a></p>'
          . '<p style="font-size:13px;color:#6b7b82">Or paste this link into your browser:<br>' . e($link) . '</p>'
          . '<p>The link works once and expires in ' . $hrs . ' hours. If this was not you, ignore this email and use "Forgot password" to set a new password.</p></div></div>';
    $text = "Hi {$patient['first_name']},\n\nYour MSCare account was locked after " . (int)MSC_MAX_LOGIN_ATTEMPTS . " wrong password attempts.\nReactivate it here (works once, expires in $hrs hours):\n$link\n\nIf this was not you, ignore this email and use \"Forgot password\" to set a new password.\n— MSCare Dental Clinic";
    return smtp_send($patient['email'], $subject, $html, $text);
}

function mask_email($email) {
    [$u, $d] = array_pad(explode('@', $email, 2), 2, '');
    return mb_substr($u, 0, min(2, mb_strlen($u))) . str_repeat('*', max(2, mb_strlen($u) - 2)) . '@' . $d;
}

/** Seconds the person must still wait before another code may be sent (0 = may send now). */
function otp_wait_seconds($pid, $purpose) {
    $cool = (int)mail_cfg()['resend_cooldown'];
    $s = db()->prepare("SELECT EXTRACT(EPOCH FROM (now() - created_at)) FROM patient_otps
                        WHERE user_type='patient' AND user_id=:u AND purpose=:p ORDER BY id DESC LIMIT 1");
    $s->execute([':u' => $pid, ':p' => $purpose]);
    $age = $s->fetchColumn();
    return ($age === false || $age === null) ? 0 : max(0, (int)ceil($cool - (float)$age));
}

/** Seconds until the newest unused code expires (0 = none/expired). */
function otp_expires_in($pid, $purpose) {
    $s = db()->prepare("SELECT EXTRACT(EPOCH FROM (expires_at - now())) FROM patient_otps
                        WHERE user_type='patient' AND user_id=:u AND purpose=:p AND is_used=FALSE ORDER BY id DESC LIMIT 1");
    $s->execute([':u' => $pid, ':p' => $purpose]);
    $v = $s->fetchColumn();
    return ($v === false || $v === null) ? 0 : max(0, (int)floor((float)$v));
}

/** Create a fresh 6-digit code, email it. Returns [true,''] or [false,'reason']. */
function send_patient_code(array $patient, $purpose) {
    ensure_email_schema();
    $pdo = db(); $mins = (int)mail_cfg()['code_minutes'];
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $pdo->prepare("UPDATE patient_otps SET is_used = TRUE WHERE user_type='patient' AND user_id=:u AND purpose=:p AND is_used = FALSE")
        ->execute([':u' => $patient['id'], ':p' => $purpose]);
    $pdo->prepare("INSERT INTO patient_otps (user_type, user_id, otp_code, purpose, expires_at)
                   VALUES ('patient', :u, :c, :p, now() + (:m || ' minutes')::interval)")
        ->execute([':u' => $patient['id'], ':c' => $code, ':p' => $purpose, ':m' => (string)$mins]);

    $name = e(ucwords(strtolower($patient['first_name'])));
    $isReset = $purpose === 'password_reset';
    $subject = $isReset ? 'Your MSCare password reset code' : 'Verify your MSCare account';
    $lead = $isReset ? 'Use this code to reset your MSCare password:' : 'Welcome to MSCare! Use this code to verify your email address:';
    $html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:auto;border:1px solid #e3e8ea;border-radius:12px;overflow:hidden">'
          . '<div style="background:#0f6e6a;color:#fff;padding:18px 24px;font-size:20px;font-weight:bold">MSCare Dental Clinic</div>'
          . '<div style="padding:24px;color:#1f2d33;line-height:1.5"><p>Hi ' . $name . ',</p><p>' . $lead . '</p>'
          . '<p style="font-size:34px;letter-spacing:8px;font-weight:bold;text-align:center;background:#f1f7f7;border-radius:10px;padding:14px 0;margin:18px 0">' . $code . '</p>'
          . '<p>This code expires in ' . $mins . ' minute' . ($mins === 1 ? '' : 's') . '. If you did not request it, you can ignore this email — nothing will change.</p>'
          . '<p style="color:#6b7b82;font-size:13px">Never share this code with anyone.</p></div></div>';
    $text = "Hi {$patient['first_name']},\n\n$lead\n\n$code\n\nIt expires in $mins minute" . ($mins === 1 ? '' : 's') . ". If you didn't request it, ignore this email.\n— MSCare Dental Clinic";
    return smtp_send($patient['email'], $subject, $html, $text);
}

/** Check a code. Returns true on success (and consumes it), else an error string. */
function check_patient_code($pid, $purpose, $code) {
    $code = preg_replace('/\D/', '', (string)$code);
    if (strlen($code) !== 6) return 'Please enter the 6-digit code.';
    $pdo = db();
    $s = $pdo->prepare("SELECT id, otp_code, attempts, (expires_at < now()) AS expired FROM patient_otps
                        WHERE user_type='patient' AND user_id=:u AND purpose=:p AND is_used=FALSE ORDER BY id DESC LIMIT 1");
    $s->execute([':u' => $pid, ':p' => $purpose]);
    $row = $s->fetch();
    if (!$row) return 'No active code. Please request a new one.';
    if ($row['expired']) return 'That code has expired. Please request a new one.';
    if ((int)$row['attempts'] >= 5) return 'Too many wrong attempts. Please request a new code.';
    if (!hash_equals((string)$row['otp_code'], $code)) {
        $pdo->prepare("UPDATE patient_otps SET attempts = attempts + 1 WHERE id = :i")->execute([':i' => $row['id']]);
        return 'Incorrect code. Please try again.';
    }
    $pdo->prepare("UPDATE patient_otps SET is_used = TRUE WHERE id = :i")->execute([':i' => $row['id']]);
    return true;
}
