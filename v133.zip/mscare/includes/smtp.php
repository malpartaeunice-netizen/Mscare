<?php
// MSCare - tiny SMTP sender (no Composer needed). Standalone: takes the config as an array.
// Same file is used by the patient site and the admin site (for the "send test email" button).

/** Send an email over SMTP. Returns [true, ''] or [false, 'reason']. */
function smtp_send_with(array $c, $to, $subject, $html, $text = '') {
    if (trim((string)($c['username'] ?? '')) === '' || trim((string)($c['password'] ?? '')) === '') {
        return [false, 'Email is not set up yet. An admin must enter the sender email and app password in Admin > Settings > Email Sender.'];
    }
    $c += ['host' => 'smtp.gmail.com', 'port' => 587, 'from_email' => '', 'from_name' => 'MSCare Dental Clinic', 'verify_ssl' => false];
    $host = $c['host']; $port = (int)$c['port'];
    $ctx = stream_context_create(['ssl' => [
        'verify_peer' => (bool)$c['verify_ssl'], 'verify_peer_name' => (bool)$c['verify_ssl'], 'allow_self_signed' => !$c['verify_ssl'],
    ]]);
    $remote = ($port === 465 ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $fp = @stream_socket_client($remote, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return [false, "Could not connect to the mail server ($errstr). Check your internet, and that PHP's openssl extension is enabled."];
    stream_set_timeout($fp, 15);

    $read = function () use ($fp) {
        $data = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] === ' ') break;
        }
        return $data;
    };
    $cmd = function ($line, $expect) use ($fp, $read) {
        if ($line !== null) fwrite($fp, $line . "\r\n");
        $r = $read();
        return [substr($r, 0, 3) === (string)$expect, trim($r)];
    };
    $fail = function ($msg) use ($fp) { @fwrite($fp, "QUIT\r\n"); @fclose($fp); return [false, $msg]; };

    [$ok, $r] = $cmd(null, 220);              if (!$ok) return $fail("Mail server said: $r");
    $ehlo = 'localhost';
    [$ok, $r] = $cmd("EHLO $ehlo", 250);      if (!$ok) return $fail("EHLO failed: $r");
    if ($port !== 465) {
        [$ok, $r] = $cmd('STARTTLS', 220);    if (!$ok) return $fail("STARTTLS failed: $r");
        $m = STREAM_CRYPTO_METHOD_TLS_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) $m |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) $m |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
        if (!@stream_socket_enable_crypto($fp, true, $m)) return $fail('Secure connection (TLS) failed. Check that the PHP openssl extension is enabled.');
        [$ok, $r] = $cmd("EHLO $ehlo", 250);  if (!$ok) return $fail("EHLO failed: $r");
    }
    [$ok, $r] = $cmd('AUTH LOGIN', 334);                                   if (!$ok) return $fail("AUTH not accepted: $r");
    [$ok, $r] = $cmd(base64_encode($c['username']), 334);                  if (!$ok) return $fail("Login rejected: $r");
    [$ok, $r] = $cmd(base64_encode(str_replace(' ', '', $c['password'])), 235);
    if (!$ok) return $fail('Mail login failed. For Gmail you must use an App Password (not your normal password). Server: ' . $r);

    $from = $c['from_email'] !== '' ? $c['from_email'] : $c['username'];
    [$ok, $r] = $cmd("MAIL FROM:<$from>", 250);   if (!$ok) return $fail("Sender rejected: $r");
    [$ok, $r] = $cmd("RCPT TO:<$to>", 250);       if (!$ok && substr($r, 0, 3) !== '251') return $fail("Recipient rejected: $r");
    [$ok, $r] = $cmd('DATA', 354);                if (!$ok) return $fail("DATA failed: $r");

    $b = 'b' . md5(uniqid('', true));
    $enc = static fn($s) => '=?UTF-8?B?' . base64_encode($s) . '?=';
    $h  = "Date: " . date('r') . "\r\n";
    $h .= "From: " . $enc($c['from_name']) . " <$from>\r\n";
    $h .= "To: <$to>\r\n";
    $h .= "Subject: " . $enc($subject) . "\r\n";
    $h .= "Message-ID: <" . md5(uniqid('', true)) . "@mscare>\r\n";
    $h .= "MIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"$b\"\r\n\r\n";
    $body  = "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text ?: strip_tags($html))) . "\r\n";
    $body .= "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "\r\n--$b--\r\n";
    fwrite($fp, $h . $body . "\r\n.\r\n");
    [$ok, $r] = [substr(($rr = $read()), 0, 3) === '250', trim($rr)];
    if (!$ok) return $fail("Message rejected: $r");
    $cmd('QUIT', 221); @fclose($fp);
    return [true, ''];
}
