<?php
// Gemini AI chatbot settings (Messages page).
// 1) Get a free key at https://aistudio.google.com/apikey
// 2) Paste it below. Leave it as is (or empty) to turn the chatbot OFF - admins then reply manually like before.
// Do NOT upload this file to GitHub / share it publicly.
define('GEMINI_API_KEY', 'AQ.Ab8RN6J4smiui2FD-8d0ZZRmPUfFtc-817OrcWCC7wBbh-dkEg');
define('GEMINI_MODEL',   'gemini-2.5-flash');   // check https://ai.google.dev/gemini-api/docs/models for the current model name
