<?php
// Opens a patient-portal page: site header + hero + tab bar.
// Expects (set before including):  $ptitle, $psub, $pactive  (and $patient from require_patient()).
require_once __DIR__ . '/auth.php';
require_patient();
$patient = current_patient();
$page  = 'portal';
$title = $ptitle ?? 'My Portal';
$ptabs = [
    'dashboard'    => ['patient-dashboard.php',    'Dashboard',         $ui['grid']],
    'book'         => ['patient-book.php',         'Book Appointment',  $ui['calendar']],
    'appointments' => ['patient-appointments.php', 'My Appointments',   $ui['history']],
    'history'      => ['patient-history.php',      'Treatment History', $services[0][2]],
    'record'       => ['patient-record.php',       'My Dental Record',  $ui['file']],
    'profile'      => ['patient-profile.php',      'My Profile',        $ui['user']],
];
include __DIR__ . '/header.php';
?>
<section class="portal-hero">
  <div class="container">
    <h1><?= e($ptitle ?? 'My Portal') ?></h1>
    <?php if (!empty($psub)): ?><p class="lead"><?= e($psub) ?></p><?php endif; ?>
    <nav class="portal-tabs" aria-label="Patient portal">
      <?php foreach ($ptabs as $key => [$href, $label, $path]): ?>
        <a href="<?= $href ?>"<?= ($pactive ?? '') === $key ? ' class="on" aria-current="page"' : '' ?>><?= icon($path, 18) ?><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</section>
<?php
// Optional page background (set $pbg to an image path before including this file, e.g. 'images/dashboard-bg.jpg').
$pbg_file = !empty($pbg) ? dirname(__DIR__) . '/' . ltrim($pbg, '/') : '';
$pbg_on   = $pbg_file !== '' && is_file($pbg_file);
?>
<section class="portal-body<?= $pbg_on ? ' has-bg' : '' ?>"<?= $pbg_on ? ' style="background-image:linear-gradient(180deg,rgba(243,249,249,.30),rgba(243,249,249,.12)),url(\'' . e($pbg) . '?v=' . (int)filemtime($pbg_file) . '\')"' : '' ?>>
  <div class="container">
<?php
$flash = take_flash();
if ($flash): ?>
    <div class="banner <?= $flash['type'] === 'error' ? 'err' : 'ok' ?>" role="status">
      <?= icon($flash['type'] === 'error' ? $ui['lock'] : $ui['check'], 20) ?>
      <div class="b-text"><strong><?= e($flash['message']) ?></strong></div>
    </div>
<?php endif; ?>
