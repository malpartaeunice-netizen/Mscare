  </div>
</section>
<?php if (true): ?>
<div class="cb-panel" id="cbPanel" role="dialog" aria-label="MSCare chatbot" hidden>
  <div class="cb-panel-head">
    <button type="button" class="cb-close" id="cbClose" aria-label="Close chatbot">&times;</button>
  </div>
  <iframe title="MSCare chatbot" data-src="patient-chatbot.php" loading="lazy"></iframe>
</div>
<button type="button" class="cb-fab" id="cbFab" aria-expanded="false" aria-controls="cbPanel">
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="4"/><path d="M12 8V4M9 3h6"/><circle cx="9" cy="14" r="1" fill="currentColor"/><circle cx="15" cy="14" r="1" fill="currentColor"/></svg>
  <span>Chatbot</span>
</button>
<script>
(function () {
  var fab = document.getElementById('cbFab'), panel = document.getElementById('cbPanel'), close = document.getElementById('cbClose');
  if (!fab || !panel) return;
  var frame = panel.querySelector('iframe');
  function toggle(open) {
    if (open && !frame.getAttribute('src')) frame.setAttribute('src', frame.dataset.src);
    panel.hidden = !open; fab.setAttribute('aria-expanded', open ? 'true' : 'false');
    fab.classList.toggle('is-open', open);
  }
  fab.addEventListener('click', function () { toggle(panel.hidden); });
  close.addEventListener('click', function () { toggle(false); fab.focus(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) toggle(false); });
})();
</script>
<?php endif; ?>
<?php include __DIR__ . '/footer.php'; ?>
