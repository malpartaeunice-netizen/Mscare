</main>
<?php if (empty($no_footer)): ?>
<footer class="footer">
  <div class="container footer-grid">
    <div>
      <a class="brand brand-light" href="<?= current_patient() ? 'patient-dashboard.php' : 'index.php' ?>"><?= icon($services[0][2], 24) ?><span><?= e($clinic['short']) ?></span></a>
    </div>
    <div>
      <?php if (current_patient()): ?>
        <h4>My Portal</h4>
        <a href="patient-dashboard.php">Dashboard</a>
        <a href="patient-book.php">Book Appointment</a>
        <a href="patient-appointments.php">My Appointments</a>
        <a href="patient-profile.php">My Profile</a>
      <?php else: ?>
        <h4>Pages</h4>
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Patient Log in</a>
      <?php endif; ?>
    </div>
    <div>
      <h4>Clinics</h4>
      <?php foreach ($branches as $b): ?>
        <p><strong><?= e($b['name']) ?></strong><br><?= e($b['address']) ?><br>Open <?= e($b['days_short']) ?></p>
      <?php endforeach; ?>
    </div>
    <div>
      <h4>Reach us</h4>
      <p><a href="tel:<?= e($clinic['phone_tel']) ?>"><?= e($clinic['phone']) ?></a></p>
      <p>Facebook: <?= e($clinic['facebook']) ?></p>
    </div>
  </div>
  <div class="container footer-bottom">&copy; <?= (int)$clinic['year'] ?> <?= e($clinic['name']) ?>. All rights reserved.</div>
</footer>
<?php endif; ?>
<script src="assets/script.js?v=<?= filemtime(__DIR__ . '/../assets/script.js') ?>"></script>
</body>
</html>
