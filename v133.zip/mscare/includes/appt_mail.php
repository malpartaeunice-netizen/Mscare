<?php
// MSCare - emails for appointment events (used by BOTH the patient site and the admin site;
// the two copies of this file are identical). Sender = Admin > Settings > Email Sender.
// Nothing here ever throws: a mail problem must never block a booking or a status change.
require_once __DIR__ . '/smtp.php';

/** Notification switch / setting for a clinic (branch). Defaults to $default when unset. */
function am_setting(PDO $pdo, $branch_id, $key, $default = '1') {
    try {
        $st = $pdo->prepare("SELECT setting_value FROM clinic_settings WHERE branch_id = :b AND setting_key = :k");
        $st->execute([':b' => $branch_id, ':k' => $key]);
        $v = $st->fetchColumn();
        return $v === false ? $default : (string)$v;
    } catch (Throwable $ex) { return $default; }
}

/** SMTP sender from clinic_settings (branch 0). Returns null when no real sender is saved yet. */
function am_cfg(PDO $pdo) {
    try {
        $map = [];
        foreach ($pdo->query("SELECT setting_key, setting_value FROM clinic_settings WHERE branch_id = 0 AND setting_key LIKE 'smtp\\_%'")->fetchAll() as $r) $map[$r['setting_key']] = $r['setting_value'];
    } catch (Throwable $ex) { return null; }
    $u = trim((string)($map['smtp_username'] ?? '')); $p = str_replace(' ', '', (string)($map['smtp_password'] ?? ''));
    if ($u === '' || $p === '' || strtolower($u) === 'yourclinic@gmail.com' || strtolower($p) === 'abcdefghijklmnop') return null;
    return [
        'host' => ($map['smtp_host'] ?? '') !== '' ? $map['smtp_host'] : 'smtp.gmail.com',
        'port' => (int)($map['smtp_port'] ?? 0) > 0 ? (int)$map['smtp_port'] : 587,
        'username' => $u, 'password' => $p,
        'from_name' => ($map['smtp_from_name'] ?? '') !== '' ? $map['smtp_from_name'] : 'MSCare Dental Clinic',
        'from_email' => $map['smtp_from_email'] ?? '',
    ];
}

/**
 * Send the email for an appointment event. Events:
 *   received      -> patient: "we got your request"          (+ clinic alert if "New booking alerts" is on)
 *   confirmed     -> patient: appointment confirmed
 *   cancelled     -> patient: cancelled by the clinic
 *   rescheduled   -> patient: moved to a new date/time
 *   patient_cancelled -> clinic alert (if "Cancellation alerts" is on)
 *   patient_rescheduled     -> clinic alert (if "New booking alerts" is on): patient moved their own appointment
 *   patient_rescheduled_ack -> patient: "you changed your appointment, the clinic will confirm"
 * Returns [true,''] | [false,'reason'].  Patient emails obey "Notify patients" (n_patient_confirm).
 */
function appt_email(PDO $pdo, $appt_id, $event) {
    try {
        $st = $pdo->prepare("
            SELECT a.id, a.ref, a.branch_id, a.email, a.first_name, a.last_name, a.phone, a.appointment_date, a.appointment_time, a.comments,
                   s.name AS service_name, b.name AS branch_name, b.address AS branch_address, b.phone AS branch_phone
              FROM appointments a JOIN services s ON s.id = a.service_id JOIN branches b ON b.id = a.branch_id
             WHERE a.id = :id");
        $st->execute([':id' => $appt_id]);
        $a = $st->fetch();
        if (!$a) return [false, 'Appointment not found.'];
        $cfg = am_cfg($pdo);
        if (!$cfg) return [false, 'Email sender is not set up (Admin > Settings > Email Sender).'];

        $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
        $name = trim($a['first_name'] . ' ' . $a['last_name']);
        $date = date('l, F j, Y', strtotime($a['appointment_date']));
        $time = date('g:i A', strtotime($a['appointment_time']));
        $short = date('M j', strtotime($a['appointment_date'])) . ' at ' . $time;
        $clinic = $a['branch_phone'] ?: '0917 220 3391';
        $table = '<table style="border-collapse:collapse;width:100%;margin:12px 0">'
            . '<tr><td style="padding:6px 0;color:#6b7280">Service</td><td><b>' . $e($a['service_name']) . '</b></td></tr>'
            . '<tr><td style="padding:6px 0;color:#6b7280">Date</td><td><b>' . $e($date) . '</b></td></tr>'
            . '<tr><td style="padding:6px 0;color:#6b7280">Time</td><td><b>' . $e($time) . '</b></td></tr>'
            . '<tr><td style="padding:6px 0;color:#6b7280">Clinic</td><td>' . $e($a['branch_name']) . '<br><span style="color:#6b7280">' . $e($a['branch_address']) . '</span></td></tr>'
            . '<tr><td style="padding:6px 0;color:#6b7280">Reference</td><td>' . $e($a['ref']) . '</td></tr></table>';
        $wrap = fn($title, $body) => '<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;color:#1f2937"><h2 style="color:#0f766e;margin:0 0 12px">' . $e($title) . '</h2>' . $body . '<p style="color:#6b7280;font-size:13px">- MSCare Dental Clinic</p></div>';

        $to = ''; $subject = ''; $html = ''; $text = '';
        switch ($event) {
            case 'received':
            case 'confirmed':
            case 'cancelled':
            case 'rescheduled':
            case 'patient_rescheduled_ack':
                if (am_setting($pdo, $a['branch_id'], 'n_patient_confirm', '1') !== '1') return [true, 'skipped'];
                $to = trim((string)$a['email']);
                $map = [
                    'received'    => ['Request received', 'We received your appointment request. The clinic will confirm your schedule shortly.', 'Appointment request received'],
                    'confirmed'   => ['Appointment confirmed', 'Great news! Your appointment is confirmed. Please arrive 10 minutes early.', 'Appointment confirmed'],
                    'cancelled'   => ['Appointment cancelled', 'Your appointment was cancelled by the clinic. You can book another time anytime, or call us to reschedule.', 'Appointment cancelled'],
                    'rescheduled' => ['Appointment rescheduled', 'Your appointment was moved to the new schedule below. If this does not work for you, please call us.', 'Appointment rescheduled'],
                    'patient_rescheduled_ack' => ['Reschedule request received', 'You changed your appointment to the new schedule below. The clinic will confirm it shortly.', 'Reschedule request received'],
                ][$event];
                $subject = $map[2] . ': ' . $short . ' - MSCare Dental Clinic';
                $html = $wrap($map[0], '<p>Hi ' . $e($name) . ',</p><p>' . $e($map[1]) . '</p>' . $table . '<p>Questions? Call or text ' . $e($clinic) . '.</p>');
                $text = "Hi $name,\n\n{$map[1]}\n\n{$a['service_name']} - $date at $time\n{$a['branch_name']}, {$a['branch_address']}\nRef: {$a['ref']}\n\nCall/text $clinic.\n- MSCare Dental Clinic";
                break;
            case 'new_booking_alert':
            case 'patient_cancelled':
            case 'patient_rescheduled':
                $key = $event === 'patient_cancelled' ? 'n_cancel_alert' : 'n_booking_alert';
                if (am_setting($pdo, $a['branch_id'], $key, '1') !== '1') return [true, 'skipped'];
                $to = trim(am_setting($pdo, $a['branch_id'], 'alert_email', ''));
                if ($to === '') return [true, 'skipped'];
                $what = ['new_booking_alert' => 'New appointment request', 'patient_cancelled' => 'Appointment cancelled by patient', 'patient_rescheduled' => 'Appointment rescheduled by patient'][$event];
                $subject = $what . ': ' . $name . ', ' . $short;
                $html = $wrap($what, '<p><b>' . $e($name) . '</b> (' . $e($a['phone']) . ', ' . $e($a['email']) . ')</p>' . $table
                    . ($a['comments'] !== '' ? '<p>Notes: ' . $e($a['comments']) . '</p>' : ''));
                $text = "$what\n$name ({$a['phone']}, {$a['email']})\n{$a['service_name']} - $date at $time\n{$a['branch_name']}\nRef: {$a['ref']}";
                break;
            default:
                return [false, 'Unknown email event.'];
        }
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return [false, 'No valid recipient email.'];
        return smtp_send_with($cfg, $to, $subject, $html, $text);
    } catch (Throwable $ex) {
        error_log('MSCare appt_email: ' . $ex->getMessage());
        return [false, 'Email error.'];
    }
}
