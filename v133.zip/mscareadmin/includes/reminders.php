<?php
// MSCare Admin - appointment reminders by EMAIL (in addition to the patient portal bell).
// Used by api.php (the "Send reminder" / "Contact all" buttons) and by send_reminders.php (automatic).
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/smtp.php';

/** Adds appointments.email_reminded_at once (so this works even if reminders.sql was never run). */
function ensure_reminder_schema(PDO $pdo) {
    static $done = false; if ($done) return; $done = true;
    try {
        $has = $pdo->query("SELECT 1 FROM information_schema.columns WHERE table_name='appointments' AND column_name='email_reminded_at'")->fetchColumn();
        if (!$has) $pdo->exec("ALTER TABLE appointments ADD COLUMN IF NOT EXISTS email_reminded_at TIMESTAMPTZ");
    } catch (PDOException $ex) { error_log('MSCare ensure_reminder_schema: ' . $ex->getMessage()); }
}

/** Sender settings saved in Admin > Settings > Email Sender (clinic_settings, branch 0). */
function reminder_smtp_cfg(PDO $pdo) {
    $map = [];
    foreach ($pdo->query("SELECT setting_key, setting_value FROM clinic_settings WHERE branch_id = 0 AND setting_key LIKE 'smtp\\_%'")->fetchAll() as $r) {
        $map[$r['setting_key']] = $r['setting_value'];
    }
    return [
        'host'      => ($map['smtp_host'] ?? '') !== '' ? $map['smtp_host'] : 'smtp.gmail.com',
        'port'      => (int)($map['smtp_port'] ?? 0) > 0 ? (int)$map['smtp_port'] : 587,
        'username'  => $map['smtp_username'] ?? '',
        'password'  => str_replace(' ', '', (string)($map['smtp_password'] ?? '')),
        'from_name' => ($map['smtp_from_name'] ?? '') !== '' ? $map['smtp_from_name'] : 'MSCare Dental Clinic',
        'from_email'=> $map['smtp_from_email'] ?? '',
    ];
}

/**
 * Emails a reminder for one appointment (works for guests too - uses appointments.email).
 * Returns [true, ''] or [false, 'reason']. Stamps appointments.email_reminded_at on success.
 */
function send_reminder_email(PDO $pdo, $appt_id) {
    ensure_reminder_schema($pdo);
    $st = $pdo->prepare("
        SELECT a.id, a.ref, a.email, a.first_name, a.last_name, a.appointment_date, a.appointment_time,
               s.name AS service_name, b.name AS branch_name, b.address AS branch_address, b.phone AS branch_phone,
               COALESCE(d.name, 'Dr. Marilou S. Cariño') AS dentist_name
          FROM appointments a
          JOIN services s ON s.id = a.service_id
          JOIN branches b ON b.id = a.branch_id
          LEFT JOIN dentists d ON d.id = a.dentist_id
         WHERE a.id = :id");
    $st->execute([':id' => $appt_id]);
    $a = $st->fetch();
    if (!$a) return [false, 'Appointment not found.'];
    $to = trim((string)$a['email']);
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) return [false, 'This booking has no valid email address.'];

    $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $date = date('l, F j, Y', strtotime($a['appointment_date']));
    $time = date('g:i A', strtotime($a['appointment_time']));
    $name = trim($a['first_name'] . ' ' . $a['last_name']);
    $phone = $a['branch_phone'] ?: '0917 220 3391';

    $subject = 'Appointment reminder: ' . date('M j', strtotime($a['appointment_date'])) . ' at ' . $time . ' - MSCare Dental Clinic';
    $html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;color:#1f2937">'
          . '<h2 style="color:#0f766e;margin:0 0 12px">Appointment reminder</h2>'
          . '<p>Hi ' . $e($name) . ',</p>'
          . '<p>This is a friendly reminder of your upcoming appointment at MSCare Dental Clinic.</p>'
          . '<table style="border-collapse:collapse;width:100%;margin:12px 0">'
          . '<tr><td style="padding:6px 0;color:#6b7280">Service</td><td style="padding:6px 0"><b>' . $e($a['service_name']) . '</b></td></tr>'
          . '<tr><td style="padding:6px 0;color:#6b7280">Date</td><td style="padding:6px 0"><b>' . $e($date) . '</b></td></tr>'
          . '<tr><td style="padding:6px 0;color:#6b7280">Time</td><td style="padding:6px 0"><b>' . $e($time) . '</b></td></tr>'
          . '<tr><td style="padding:6px 0;color:#6b7280">Dentist</td><td style="padding:6px 0">' . $e($a['dentist_name']) . '</td></tr>'
          . '<tr><td style="padding:6px 0;color:#6b7280">Clinic</td><td style="padding:6px 0">' . $e($a['branch_name']) . '<br><span style="color:#6b7280">' . $e($a['branch_address']) . '</span></td></tr>'
          . '<tr><td style="padding:6px 0;color:#6b7280">Reference</td><td style="padding:6px 0">' . $e($a['ref']) . '</td></tr>'
          . '</table>'
          . '<p>Please arrive 10 minutes early. Need to reschedule? Call or text us at ' . $e($phone) . '.</p>'
          . '<p style="color:#6b7280;font-size:13px">- MSCare Dental Clinic</p></div>';
    $text = "Hi $name,\n\nReminder: {$a['service_name']} on $date at $time\n{$a['branch_name']} - {$a['branch_address']}\nRef: {$a['ref']}\n\nPlease arrive 10 minutes early. To reschedule, call $phone.\n\n- MSCare Dental Clinic";

    [$ok, $err] = smtp_send_with(reminder_smtp_cfg($pdo), $to, $subject, $html, $text);
    if ($ok) {
        $pdo->prepare("UPDATE appointments SET email_reminded_at = now() WHERE id = :id")->execute([':id' => $appt_id]);
        return [true, ''];
    }
    return [false, $err];
}
