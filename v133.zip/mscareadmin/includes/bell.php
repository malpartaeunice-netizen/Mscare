<?php
// MSCare Admin - notification bell shown in every page's top bar.
// Shows what needs the clinic's attention for the signed-in admin's branch:
//   * booking requests still waiting for approval (status = Pending)
//   * appointments a patient cancelled from the portal in the last 3 days
// The badge number is the count of those items, so it goes down as requests are handled.

function admin_bell_ensure_table($pdo) {
    if (!empty($_SESSION['bell_tbl_ok2'])) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_notif_reads (
        admin_id integer NOT NULL,
        notif_key varchar(24) NOT NULL,
        read_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (admin_id, notif_key))");
    $_SESSION['bell_tbl_ok2'] = 1;
}

/** SQL that merges every notification (booking requests, patient cancellations, signatures) into one
 *  list - read or unread, handled or not, old or new - so past notifications never disappear. */
function admin_notif_union_sql() {
    return "SELECT 'p' AS kind, a.id, trim(a.first_name || ' ' || a.last_name) AS person, s.name AS service_name,
                   a.appointment_date, a.appointment_time, a.status, NULL::text AS message,
                   CASE WHEN a.admin_notes LIKE 'Rescheduled by patient%' THEN a.updated_at ELSE a.created_at END AS ev_at,
                   (a.status <> 'Pending' OR r.notif_key IS NOT NULL) AS is_read, NULL::bigint AS ts,
                   (a.admin_notes LIKE 'Rescheduled by patient%') AS is_resched
              FROM appointments a
              JOIN services s ON s.id = a.service_id
              LEFT JOIN admin_notif_reads r ON r.admin_id = :a1 AND r.notif_key = 'p' || a.id
             WHERE a.branch_id = :b1
            UNION ALL
            SELECT 'c', a.id, trim(a.first_name || ' ' || a.last_name), s.name,
                   a.appointment_date, a.appointment_time, a.status, NULL::text, a.updated_at,
                   (r.notif_key IS NOT NULL), NULL::bigint, FALSE
              FROM appointments a
              JOIN services s ON s.id = a.service_id
              LEFT JOIN admin_notif_reads r ON r.admin_id = :a2 AND r.notif_key = 'c' || a.id
             WHERE a.branch_id = :b2 AND a.status = 'Cancelled' AND a.admin_notes LIKE 'Cancelled by patient%'
            UNION ALL
            SELECT 's', pc.patient_id, trim(p.first_name || ' ' || p.last_name), NULL, NULL::date, NULL::time,
                   pc.status, NULL::text,
                   CASE WHEN pc.status = 'pending' THEN pc.updated_at ELSE COALESCE(pc.reviewed_at, pc.updated_at) END,
                   (pc.status <> 'pending' OR r.notif_key IS NOT NULL),
                   extract(epoch FROM pc.updated_at)::bigint, FALSE
              FROM patient_consents pc
              JOIN patients p ON p.id = pc.patient_id
              LEFT JOIN admin_notif_reads r ON r.admin_id = :a3
                   AND r.notif_key = 's' || pc.patient_id || 't' || extract(epoch FROM pc.updated_at)::bigint
             WHERE (p.branch_id IS NULL OR p.branch_id = :b4 OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b4))";
}

/** Notifications for a branch, newest first. $filter: all | unread | booking | cancelled | message */
function admin_notif_list($branch_id, $limit = 8, $offset = 0, $filter = 'all', $search = '') {
    $pdo = db();
    admin_bell_ensure_table($pdo);
    $where = ['all' => 'TRUE', 'unread' => 'NOT is_read', 'booking' => "kind = 'p'",
              'cancelled' => "kind = 'c'", 'signature' => "kind = 's'"][$filter] ?? 'TRUE';
    $params = [':a1' => admin_id(), ':b1' => $branch_id, ':a2' => admin_id(), ':b2' => $branch_id, ':a3' => admin_id(), ':b4' => $branch_id];
    $base = admin_notif_union_sql();
    $search = trim((string)$search);
    if ($search !== '') {
        $where = '(' . $where . ") AND (person ILIKE :q1 OR service_name ILIKE :q2 OR message ILIKE :q3 OR to_char(appointment_date, 'Mon DD YYYY') ILIKE :q4)";
        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
        $params += [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like];
    }
    $cnt = $pdo->prepare("SELECT COUNT(*) FROM ($base) n WHERE $where");
    $cnt->execute($params);
    $total = (int)$cnt->fetchColumn();
    $st = $pdo->prepare("SELECT * FROM ($base) n WHERE $where ORDER BY ev_at DESC, id DESC LIMIT " . (int)$limit . ' OFFSET ' . (int)$offset);
    $st->execute($params);
    return [$st->fetchAll(), $total];
}

function admin_bell_data($branch_id) {
    $out = ['items' => [], 'count' => 0];
    try {
        $pdo = db();
        admin_bell_ensure_table($pdo);
        $aid = admin_id();

        // Latest notifications, including ones already read or already handled
        [$out['items']] = admin_notif_list($branch_id, 8, 0, 'all');

        // Unread total (not limited to the ones shown)
        $st = $pdo->prepare("SELECT
              (SELECT COUNT(*) FROM appointments a
                WHERE a.branch_id = :b1 AND a.status = 'Pending'
                  AND NOT EXISTS (SELECT 1 FROM admin_notif_reads r WHERE r.admin_id = :a1 AND r.notif_key = 'p' || a.id))
            + (SELECT COUNT(*) FROM appointments a
                WHERE a.branch_id = :b2 AND a.status = 'Cancelled' AND a.admin_notes LIKE 'Cancelled by patient%'
                   AND NOT EXISTS (SELECT 1 FROM admin_notif_reads r WHERE r.admin_id = :a2 AND r.notif_key = 'c' || a.id))
             + (SELECT COUNT(*) FROM patient_consents pc WHERE pc.status = 'pending'
                  AND EXISTS (SELECT 1 FROM patients p WHERE p.id = pc.patient_id AND (p.branch_id IS NULL OR p.branch_id = :b4 OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b4)))
                  AND NOT EXISTS (SELECT 1 FROM admin_notif_reads r WHERE r.admin_id = :a3
                                   AND r.notif_key = 's' || pc.patient_id || 't' || extract(epoch FROM pc.updated_at)::bigint));");
        $st->execute([':a1' => $aid, ':b1' => $branch_id, ':a2' => $aid, ':b2' => $branch_id, ':a3' => $aid, ':b4' => $branch_id]);
        $out['count'] = (int)$st->fetchColumn();
    } catch (Throwable $ex) {
        error_log('MSCare admin bell: ' . $ex->getMessage());
    }
    return $out;
}

/** One notification row (works for booking requests, patient cancellations and signatures). */
function admin_bell_item($n, $showReceived = false) {
    $kind = $n['kind'];
    $read = !empty($n['is_read']) && $n['is_read'] !== 'f';
    $svg  = function ($path) { return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>'; };
    if ($kind === 's') {
        $titles = ['pending' => 'New signature to review', 'approved' => 'Signature approved', 'rejected' => 'Signature rejected'];
        $title  = e($titles[$n['status']] ?? 'Signature update') . ' &mdash; ' . e($n['person']);
        $sub    = 'Informed consent · ' . e(date('M j, g:i A', strtotime($n['ev_at'])));
        $href   = 'patient-record.php?patient=' . (int)$n['id'];
        $icon   = '<span class="notif-icon" style="background:var(--violet-tint);color:var(--violet);">' . $svg('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>') . '</span>';
    } else {
        $when  = date('M j', strtotime($n['appointment_date'])) . ' · ' . date('g:i A', strtotime($n['appointment_time']));
        $title = ($kind === 'p' ? (!empty($n['is_resched']) && $n['is_resched'] !== 'f' ? 'Rescheduled by patient' : 'New booking request') : 'Cancelled by patient') . ' &mdash; ' . e($n['person']);
        $sub   = e($n['service_name']) . ' · ' . e($when);
        if ($kind === 'p' && $n['status'] !== 'Pending') $sub .= ' · ' . e($n['status']);
        if ($showReceived) $sub .= '<br>Received ' . e(date('M j, Y · g:i A', strtotime($n['ev_at'])));
        $href  = 'appointments.php?focus=' . (int)$n['id'];
        $icon  = $kind === 'p'
            ? '<span class="notif-icon">' . $svg('<path d="M8 3v3M16 3v3M4 8h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/>') . '</span>'
            : '<span class="notif-icon" style="background:var(--coral-tint);color:var(--coral);">' . $svg('<path d="M18 6 6 18M6 6l12 12"/>') . '</span>';
    }
    return '<a class="notif-item' . ($read ? '' : ' unread') . '" href="' . $href . '" data-key="' . $kind . (int)$n['id'] . ($kind === 's' ? 't' . (int)$n['ts'] : '') . '">'
         . $icon . '<span><div class="notif-title">' . $title . '</div><div class="notif-sub">' . $sub . '</div></span></a>';
}

/** Returns the bell button + dropdown panel (+ its tiny script, once per page). */
function admin_bell_html() {
    static $printed = false;
    $d = admin_bell_data(admin_clinic_id());
    $n = $d['count'];
    $has = !empty($d['items']);
    $h  = '<div class="notif-wrap">';
    $h .= '<button type="button" class="icon-btn" id="bellBtn" style="width:36px;height:36px;cursor:pointer;" aria-label="Notifications' . ($n ? ' (' . $n . ' unread)' : '') . '" aria-haspopup="true" aria-expanded="false">'
        . '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>'
        . '<span class="notif-dot" id="bellDot"' . ($n ? '' : ' hidden') . '>' . ($n > 9 ? '9+' : $n) . '</span>'
        . '</button>';
    $h .= '<div class="notif-panel" id="notifPanel" role="region" aria-label="Notifications">';
    $h .= '<div class="notif-head"><span id="bellHeadText">Notifications' . ($n ? ' (' . $n . ')' : '') . '</span>'
        . '<button type="button" id="bellMarkAll" class="notif-markall"' . ($n ? '' : ' hidden') . '>Mark all as read</button></div>';
    $h .= '<div class="notif-list">';
    if (!$has) {
        $h .= '<div class="notif-empty">You\'re all caught up. New booking requests, cancellations and signatures will show up here.</div>';
    } else {
        foreach ($d['items'] as $it) $h .= admin_bell_item($it);
    }
    $h .= '</div>';
    $h .= '<a class="notif-item notif-all" href="notifications.php">View all notifications</a>';
    $h .= '</div></div>';
    if (!$printed) {
        $printed = true;
        $h .= <<<'JS'
<script>
(function () {
  var b = document.getElementById('bellBtn'), p = document.getElementById('notifPanel');
  if (!b || !p || window.__bellInit) return;
  window.__bellInit = 1;
  var dot = document.getElementById('bellDot'), head = document.getElementById('bellHeadText'), all = document.getElementById('bellMarkAll');
  function set(o) { p.classList.toggle('open', o); b.setAttribute('aria-expanded', o ? 'true' : 'false'); }
  function post(body) {
    return fetch('api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: true })
      .then(function (r) { return r.json(); });
  }
  function refresh() {
    var n = p.querySelectorAll('.notif-item.unread').length;
    dot.hidden = n === 0; dot.textContent = n > 9 ? '9+' : n;
    head.textContent = 'Notifications' + (n ? ' (' + n + ')' : '');
    all.hidden = n === 0;
    b.setAttribute('aria-label', 'Notifications' + (n ? ' (' + n + ' unread)' : ''));
  }
  b.addEventListener('click', function (e) { e.stopPropagation(); set(!p.classList.contains('open')); });
  p.addEventListener('click', function (e) { e.stopPropagation(); });
  document.addEventListener('click', function () { set(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
  p.querySelectorAll('.notif-item[data-key]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var go = function () { location.href = a.getAttribute('href'); };
      if (!a.classList.contains('unread')) return go();
      a.classList.remove('unread'); refresh();
      post({ action: 'mark_notif_read', key: a.dataset.key }).then(go, go);
    });
  });
  all.addEventListener('click', function () {
    post({ action: 'mark_notif_read', all: true }).then(function (d) {
      if (d.ok) { p.querySelectorAll('.notif-item.unread').forEach(function (i) { i.classList.remove('unread'); }); refresh(); }
    });
  });
})();
</script>
JS;
    }
    return $h;
}
