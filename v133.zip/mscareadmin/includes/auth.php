<?php
// MSCare Admin - authentication & session helpers.
// No fallback admin: protected pages redirect to login.php until a real admin
// account has signed in.
if (session_status() === PHP_SESSION_NONE) {
    // Keep sessions inside the project so the app also works when PHP's
    // default temp folder is not writable by the web server user.
    $session_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'sessions';
    if (!is_dir($session_dir)) {
        @mkdir($session_dir, 0775, true);
    }
    if (is_dir($session_dir)) {
        session_save_path($session_dir);
    }
    // Separate cookie names so a patient login and an admin login can coexist
    // in the same browser without overwriting each other's session.
    session_name('MSCAREADMIN');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/db.php';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function admin_clinic_info($branch_id) {
    if ((int)$branch_id === 2) {
        return [
            'id'       => 2,
            'name'     => 'Clinic 2 — Manila',
            'label'    => 'Clinic 2 · Manila',
            'place'    => 'Manila branch',
            'initials' => 'A2',
            'days'     => 'Tue & Thu',
        ];
    }
    return [
        'id'       => 1,
        'name'     => 'Clinic 1 — Makati',
        'label'    => 'Clinic 1 · Makati',
        'place'    => 'Makati branch',
        'initials' => 'A1',
        'days'     => 'Mon, Wed, Fri & Sat',
    ];
}

function login_admin_session(array $admin) {
    $cinfo = admin_clinic_info($admin['branch_id'] ?? 1);
    $_SESSION['mscare_admin'] = [
        'id'           => (int)$admin['id'],
        'username'     => (string)$admin['username'],
        'branch_id'    => (int)($admin['branch_id'] ?? 1),
        'display_name' => (string)$admin['display_name'],
        'initials'     => (string)$admin['initials'],
        'role'         => (string)$admin['role'],
        'place'        => $cinfo['place'],
        'clinic_name'  => $cinfo['label'],
    ];
}

function current_admin() {
    return (isset($_SESSION['mscare_admin']) && is_array($_SESSION['mscare_admin']))
        ? $_SESSION['mscare_admin']
        : null;
}

function admin_id() {
    $a = current_admin();
    return $a ? (int)$a['id'] : 0;
}

function admin_clinic_id() {
    $a = current_admin();
    return $a ? (int)$a['branch_id'] : 0;
}

function require_admin() {
    if (!current_admin()) {
        $next = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
        header('Location: login.php?next=' . rawurlencode($next));
        exit;
    }
    // A deactivated admin is signed out on their next click.
    try {
        $st = db()->prepare("SELECT is_active FROM admins WHERE id = :id");
        $st->execute([':id' => admin_id()]);
        $active = $st->fetchColumn();
        if ($active === false || !$active) {
            unset($_SESSION['mscare_admin']);
            header('Location: login.php?inactive=1');
            exit;
        }
    } catch (PDOException $ex) { /* DB hiccup: do not lock the admin out */ }
}

function flash($message, $type = 'success') {
    $_SESSION['mscare_admin_flash'] = ['message' => $message, 'type' => $type];
}

function take_flash() {
    if (empty($_SESSION['mscare_admin_flash'])) return null;
    $f = $_SESSION['mscare_admin_flash'];
    unset($_SESSION['mscare_admin_flash']);
    return $f;
}

function redirect_to($url) {
    header('Location: ' . $url);
    exit;
}

/**
 * Make sure the two default admin accounts exist (admin1 / admin123, admin2 / admin123).
 * Safe to call repeatedly: does nothing when admins are already present, and never
 * overwrites an existing admin's password.
 */
function ensure_default_admins() {
    try {
        $pdo = db();
        $n = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
        if ($n > 0) return;
        $branches = $pdo->query("SELECT code, id FROM branches")->fetchAll(PDO::FETCH_KEY_PAIR);
        if (empty($branches['c1']) || empty($branches['c2'])) return;
        $hash = '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92';
        $st = $pdo->prepare("INSERT INTO admins (username, password_hash, branch_id, display_name, initials, role, is_active)
            VALUES (:u, :h, :b, :d, :i, 'admin', TRUE)
            ON CONFLICT (username) DO NOTHING");
        $st->execute([':u' => 'admin1', ':h' => $hash, ':b' => (int)$branches['c1'], ':d' => 'Clinic 1 Admin', ':i' => 'A1']);
        $st->execute([':u' => 'admin2', ':h' => $hash, ':b' => (int)$branches['c2'], ':d' => 'Clinic 2 Admin', ':i' => 'A2']);
    } catch (Throwable $e) {
        error_log('MSCare ensure_default_admins: ' . $e->getMessage());
    }
}

