<?php
// MSCare Admin - revenue helpers shared by the dashboard and the Revenue & reports page.
// "Revenue" = the cost recorded on treatment records (treatments.cost) for the signed-in admin's clinic.

/**
 * Revenue grouped by week / month / year, with empty periods filled in as 0.
 * Returns ['labels' => [...], 'values' => [...]] oldest first.
 */
function rev_series(PDO $pdo, $branch_id, $mode) {
    $cfg = [
        'weekly'  => ['unit' => 'week',  'count' => 8, 'fmt' => 'M j'],
        'monthly' => ['unit' => 'month', 'count' => 6, 'fmt' => 'M'],
        'yearly'  => ['unit' => 'year',  'count' => 5, 'fmt' => 'Y'],
    ];
    $c = $cfg[$mode] ?? $cfg['monthly'];
    $unit = $c['unit'];

    // Build the list of period start dates (oldest first).
    $starts = [];
    for ($i = $c['count'] - 1; $i >= 0; $i--) {
        if ($unit === 'week')       $ts = strtotime('monday this week') - $i * 7 * 86400;
        elseif ($unit === 'month')  $ts = strtotime(date('Y-m-01') . " -$i months");
        else                        $ts = strtotime(date('Y-01-01') . " -$i years");
        $starts[] = date('Y-m-d', $ts);
    }

    $st = $pdo->prepare("SELECT to_char(date_trunc('$unit', treatment_date), 'YYYY-MM-DD') AS k, COALESCE(sum(cost), 0) AS total
                           FROM treatments
                          WHERE branch_id = :b AND treatment_date >= :from
                          GROUP BY 1");
    $st->execute([':b' => $branch_id, ':from' => $starts[0]]);
    $got = [];
    foreach ($st->fetchAll() as $r) $got[$r['k']] = (float)$r['total'];

    $labels = []; $values = [];
    foreach ($starts as $s) {
        $labels[] = date($c['fmt'], strtotime($s));
        $values[] = round($got[$s] ?? 0, 2);
    }
    return ['labels' => $labels, 'values' => $values];
}

/** Money formatting used on both pages. */
function peso($n) { return '₱' . number_format((float)$n, 2); }

/* =====================================================================
 *  Revenue & Reports page (yearly view)
 * ===================================================================== */

const REV_METHODS = ['Cash', 'Card', 'GCash', 'Bank Transfer'];

/** Normalises a payment method to one of REV_METHODS (anything unknown counts as Cash). */
function rev_method($m) {
    $m = trim((string)$m);
    foreach (REV_METHODS as $ok) if (strcasecmp($ok, $m) === 0) return $ok;
    return 'Cash';
}

/** Adds treatments.payment_method / amount_paid on databases created before this feature. Cheap and idempotent. */
function rev_ensure_columns(PDO $pdo) {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $pdo->exec("ALTER TABLE treatments ADD COLUMN IF NOT EXISTS payment_method VARCHAR(20) NOT NULL DEFAULT 'Cash'");
        $pdo->exec("ALTER TABLE treatments ADD COLUMN IF NOT EXISTS amount_paid NUMERIC(10,2)");
        $pdo->exec("UPDATE treatments SET amount_paid = cost WHERE amount_paid IS NULL");
    } catch (PDOException $ex) { error_log('MSCare rev_ensure_columns: ' . $ex->getMessage()); }
}

/** Calendar years that have any treatment or appointment data (newest first); always includes this year and last year. */
function rev_years(PDO $pdo, $branch_id) {
    $now = (int)date('Y');
    $years = [$now, $now - 1];
    foreach (['SELECT min(treatment_date) FROM treatments WHERE branch_id = :b', 'SELECT min(appointment_date) FROM appointments WHERE branch_id = :b'] as $sql) {
        try {
            $st = $pdo->prepare($sql); $st->execute([':b' => $branch_id]);
            $min = $st->fetchColumn();
            if ($min) for ($y = (int)substr((string)$min, 0, 4); $y <= $now; $y++) $years[] = $y;
        } catch (PDOException $ex) { /* ignore */ }
    }
    $years = array_values(array_unique($years));
    rsort($years);
    return $years;
}

/** Everything the Revenue & Reports page needs for one calendar year. Months are 1..12. */
function rev_year_report(PDO $pdo, $branch_id, $year) {
    $year = (int)$year;
    $zero12 = function () { return array_fill(1, 12, 0); };
    $R = [
        'year' => $year,
        'rev' => $zero12(), 'paid' => $zero12(), 'appts' => $zero12(), 'done' => $zero12(),
        'prev_rev' => $zero12(), 'prev_paid' => $zero12(), 'prev_appts' => $zero12(), 'prev_done' => $zero12(),
        'status' => [],                                   // month => [status => n]
        'methods' => array_fill_keys(REV_METHODS, 0.0),   // revenue by payment method
        'treatments' => [],                               // procedure => ['n' => , 'rev' => ]
        'patients' => [], 'visits' => $zero12(), 'new_patients' => $zero12(),
        'records' => [],
    ];
    for ($m = 1; $m <= 12; $m++) $R['status'][$m] = [];

    rev_ensure_columns($pdo);
    $b = [':b' => $branch_id];
    $rows = function ($sql, $extra) use ($pdo, $b) { $st = $pdo->prepare($sql); $st->execute($b + $extra); return $st->fetchAll(PDO::FETCH_ASSOC); };

    $tx = $rows("SELECT t.treatment_date, t.procedure_name, t.tooth, t.dentist_name, t.patient_id, t.cost, COALESCE(t.amount_paid, t.cost) AS paid, t.payment_method,
                        concat_ws(' ', p.first_name, p.last_name) AS patient
                   FROM treatments t LEFT JOIN patients p ON p.id = t.patient_id
                  WHERE t.branch_id = :b AND t.treatment_date BETWEEN :f AND :t ORDER BY t.treatment_date, t.id",
                [':f' => ($year - 1) . '-01-01', ':t' => $year . '-12-31']);
    $seen = [];
    foreach ($tx as $r) {
        $d = (string)$r['treatment_date']; $y = (int)substr($d, 0, 4); $m = (int)substr($d, 5, 2);
        $cost = (float)$r['cost']; $paid = (float)$r['paid'];
        if ($y === $year - 1) { $R['prev_rev'][$m] += $cost; $R['prev_paid'][$m] += $paid; continue; }
        $R['rev'][$m] += $cost; $R['paid'][$m] += $paid;
        $R['methods'][rev_method($r['payment_method'])] += $cost;
        $name = trim((string)$r['procedure_name']) ?: 'Other';
        $R['treatments'][$name] = ($R['treatments'][$name] ?? ['n' => 0, 'rev' => 0.0]);
        $R['treatments'][$name]['n']++; $R['treatments'][$name]['rev'] += $cost;
        $vk = $r['patient_id'] . '|' . $d;
        if (!isset($seen[$vk])) { $seen[$vk] = 1; $R['visits'][$m]++; }
        $R['patients'][$m][$r['patient_id']] = 1;
        $R['records'][] = ['date' => $d, 'patient' => $r['patient'], 'procedure' => $r['procedure_name'], 'tooth' => $r['tooth'],
                           'dentist' => $r['dentist_name'], 'method' => rev_method($r['payment_method']), 'cost' => $cost, 'paid' => $paid];
    }
    uasort($R['treatments'], function ($a, $b) { return $b['rev'] <=> $a['rev']; });

    // first-ever treatment per patient at this clinic -> "new patients" per month
    foreach ($rows("SELECT patient_id, min(treatment_date) AS first FROM treatments WHERE branch_id = :b GROUP BY patient_id", []) as $r) {
        if ((int)substr((string)$r['first'], 0, 4) === $year) $R['new_patients'][(int)substr((string)$r['first'], 5, 2)]++;
    }

    foreach ($rows("SELECT appointment_date, status FROM appointments WHERE branch_id = :b AND appointment_date BETWEEN :f AND :t",
                   [':f' => ($year - 1) . '-01-01', ':t' => $year . '-12-31']) as $r) {
        $d = (string)$r['appointment_date']; $y = (int)substr($d, 0, 4); $m = (int)substr($d, 5, 2);
        if ($y === $year - 1) { $R['prev_appts'][$m]++; if ($r['status'] === 'Completed') $R['prev_done'][$m]++; continue; }
        $R['appts'][$m]++;
        if ($r['status'] === 'Completed') $R['done'][$m]++;
        $R['status'][$m][$r['status']] = ($R['status'][$m][$r['status']] ?? 0) + 1;
    }
    return $R;
}

/** Months (1..12) that have started, for the given year: all 12 for a past year, up to this month for the current one. */
function rev_elapsed_months($year) {
    $now = (int)date('Y');
    return $year < $now ? 12 : ($year > $now ? 0 : (int)date('n'));
}

/** "₱1.2M" / "₱320k" / "₱950" for chart labels. */
function peso_short($n) {
    $n = (float)$n;
    if ($n >= 1000000) return '₱' . rtrim(rtrim(number_format($n / 1000000, 2), '0'), '.') . 'M';
    if ($n >= 1000)    return '₱' . rtrim(rtrim(number_format($n / 1000, 1), '0'), '.') . 'k';
    return '₱' . number_format($n);
}

/**
 * Sends an Excel workbook. $sheets = ['Sheet name' => [ [cell, cell, ...], ... ]]; a row whose first cell is
 * ['h' => 'text'] is styled as a header. Numeric cells stay numeric. Falls back to CSV (first sheet) without ZipArchive.
 */
function rev_send_xlsx($filename, array $sheets) {
    $esc = function ($s) { return htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); };
    $col = function ($i) { $s = ''; for ($i++; $i > 0; $i = intdiv($i - 1, 26)) $s = chr(65 + ($i - 1) % 26) . $s; return $s; };

    if (!class_exists('ZipArchive')) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . preg_replace('/\.xlsx$/', '.csv', $filename) . '"');
        $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
        foreach (reset($sheets) as $row) fputcsv($out, array_map(function ($c) { return is_array($c) ? ($c['h'] ?? '') : $c; }, $row));
        fclose($out); exit;
    }

    $xml = [];
    $names = array_keys($sheets);
    foreach ($names as $si => $name) {
        $x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols><col min="1" max="8" width="22" customWidth="1"/></cols><sheetData>';
        foreach ($sheets[$name] as $ri => $row) {
            $x .= '<row r="' . ($ri + 1) . '">';
            foreach (array_values($row) as $ci => $cell) {
                $ref = $col($ci) . ($ri + 1); $style = 0;
                if (is_array($cell)) { $style = 1; $cell = $cell['h'] ?? ''; }
                if (is_int($cell) || is_float($cell)) $x .= '<c r="' . $ref . '"' . ($style ? ' s="1"' : '') . '><v>' . $cell . '</v></c>';
                elseif ($cell === null || $cell === '') $x .= '<c r="' . $ref . '"/>';
                else $x .= '<c r="' . $ref . '" t="inlineStr"' . ($style ? ' s="1"' : '') . '><is><t xml:space="preserve">' . $esc($cell) . '</t></is></c>';
            }
            $x .= '</row>';
        }
        $xml[$si] = $x . '</sheetData></worksheet>';
    }
    $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
    $wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    foreach ($names as $i => $name) {
        $n = $i + 1;
        $ct .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        $wb .= '<sheet name="' . $esc(substr(preg_replace('/[\\\\\/?*\[\]:]/', '-', $name), 0, 31)) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
        $rels .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
    }
    $rels .= '<Relationship Id="rId' . (count($names) + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
    $ct .= '</Types>'; $wb .= '</sheets></workbook>';
    $styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF139C93"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf xfId="0"/><xf xfId="0" fontId="1" fillId="2" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';

    $tmp = tempnam(sys_get_temp_dir(), 'msx');
    $zip = new ZipArchive();
    $zip->open($tmp, ZipArchive::OVERWRITE);
    $zip->addFromString('[Content_Types].xml', $ct);
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml', $wb);
    $zip->addFromString('xl/_rels/workbook.xml.rels', $rels);
    $zip->addFromString('xl/styles.xml', $styles);
    foreach ($xml as $i => $x) $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', $x);
    $zip->close();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp); unlink($tmp); exit;
}

/** Builds the sheets for one downloadable report of a year report ($R) - or all of them for 'all'. */
function rev_report_sheets(array $R, $which, $clinic) {
    $y = $R['year']; $mn = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    $H = function (array $c) { return array_map(function ($x) { return ['h' => $x]; }, $c); };
    $n = rev_elapsed_months($y);
    $sheets = [];

    $monthly = [[$clinic . ' - Monthly revenue ' . $y], $H(['Month', 'Appointments', 'Completed', 'Revenue (PHP)', 'Collected (PHP)', 'Growth vs prev. month (%)'])];
    for ($m = 1; $m <= $n; $m++) {
        $prev = $m > 1 ? $R['rev'][$m - 1] : $R['prev_rev'][12];
        $monthly[] = [$mn[$m - 1] . ' ' . $y, $R['appts'][$m], $R['done'][$m], round($R['rev'][$m], 2), round($R['paid'][$m], 2), $prev > 0 ? round(($R['rev'][$m] - $prev) / $prev * 100, 1) : '-'];
    }
    $monthly[] = ['Total', array_sum($R['appts']), array_sum($R['done']), round(array_sum($R['rev']), 2), round(array_sum($R['paid']), 2), ''];

    $tot = array_sum($R['rev']);
    $trt = [[$clinic . ' - Treatments by revenue ' . $y], $H(['Treatment', 'Times performed', 'Revenue (PHP)', 'Share of revenue (%)', 'Average (PHP)'])];
    foreach ($R['treatments'] as $name => $t) $trt[] = [$name, $t['n'], round($t['rev'], 2), $tot > 0 ? round($t['rev'] / $tot * 100, 1) : 0, round($t['rev'] / max(1, $t['n']), 2)];

    $pat = [[$clinic . ' - Patient statistics ' . $y], $H(['Month', 'New patients', 'Patients treated', 'Visits'])];
    for ($m = 1; $m <= $n; $m++) $pat[] = [$mn[$m - 1] . ' ' . $y, $R['new_patients'][$m], count($R['patients'][$m] ?? []), $R['visits'][$m]];

    $sts = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'No-show'];
    $apt = [[$clinic . ' - Appointments ' . $y], $H(array_merge(['Month', 'Total'], $sts))];
    for ($m = 1; $m <= $n; $m++) $apt[] = array_merge([$mn[$m - 1] . ' ' . $y, $R['appts'][$m]], array_map(function ($s) use ($R, $m) { return $R['status'][$m][$s] ?? 0; }, $sts));

    $pay = [[$clinic . ' - Revenue by payment method ' . $y], $H(['Payment method', 'Revenue (PHP)', 'Share (%)'])];
    foreach ($R['methods'] as $k => $v) $pay[] = [$k, round($v, 2), $tot > 0 ? round($v / $tot * 100, 1) : 0];

    $rec = [[$clinic . ' - Treatment records ' . $y], $H(['Date', 'Patient', 'Procedure', 'Tooth', 'Dentist', 'Payment', 'Cost (PHP)', 'Paid (PHP)'])];
    foreach ($R['records'] as $r) $rec[] = [$r['date'], $r['patient'], $r['procedure'], $r['tooth'], $r['dentist'], $r['method'], round($r['cost'], 2), round($r['paid'], 2)];

    switch ($which) {
        case 'monthly':      return ['Monthly revenue' => $monthly, 'By payment method' => $pay];
        case 'patients':     return ['Patient statistics' => $pat];
        case 'appointments': return ['Appointments' => $apt];
        case 'treatments':   return ['Treatments' => $trt];
        default:             return ['Monthly revenue' => $monthly, 'Treatments' => $trt, 'By payment method' => $pay, 'Patients' => $pat, 'Appointments' => $apt, 'Records' => $rec];
    }
}
