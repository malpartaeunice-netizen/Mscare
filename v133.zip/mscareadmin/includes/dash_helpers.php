<?php
// MSCare Admin - small helpers shared by the dashboard and the Revenue & Reports page.
require_once __DIR__ . '/auth.php';

function dash_delta($cur, $prev) {
    if ($prev === null || (float)$prev == 0.0) return null;
    $p = ((float)$cur - (float)$prev) / abs((float)$prev) * 100;
    return ['dir' => $p > 0.05 ? 'up' : ($p < -0.05 ? 'down' : 'flat'), 'txt' => number_format(abs($p), 1) . '%'];
}
function dash_delta_html($d, $title, $invert = false) {
    if (!$d) return '<span class="kpi-delta flat" title="' . e($title) . '">–</span>';
    $cls = $d['dir']; if ($invert && $cls !== 'flat') $cls = ($cls === 'up') ? 'down' : 'up';   // e.g. cancellations: going up is bad
    $arrow = $d['dir'] === 'up' ? '↑' : ($d['dir'] === 'down' ? '↓' : '→');
    return '<span class="kpi-delta ' . $cls . '" title="' . e($title) . '">' . $arrow . ' ' . $d['txt'] . '</span>';
}
function dash_spark(array $vals, $color, $id) {
    $n = count($vals);
    if ($n < 2) $vals = [0, 0];
    $n = count($vals); $w = 140; $h = 44; $max = max(max($vals), 0.0001);
    $pts = [];
    foreach ($vals as $i => $v) $pts[] = [round($i * $w / ($n - 1), 1), round($h - 4 - ($v / $max) * ($h - 12), 1)];
    $line = 'M' . $pts[0][0] . ' ' . $pts[0][1];
    for ($i = 1; $i < $n; $i++) {
        $mx = round(($pts[$i - 1][0] + $pts[$i][0]) / 2, 1);
        $line .= ' C' . $mx . ' ' . $pts[$i - 1][1] . ' ' . $mx . ' ' . $pts[$i][1] . ' ' . $pts[$i][0] . ' ' . $pts[$i][1];
    }
    $area = $line . " L$w $h L0 $h Z";
    return '<svg class="kpi-spark" viewBox="0 0 ' . $w . ' ' . $h . '" preserveAspectRatio="none" aria-hidden="true">'
         . '<defs><linearGradient id="sp' . $id . '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' . $color . '" stop-opacity=".28"/><stop offset="1" stop-color="' . $color . '" stop-opacity="0"/></linearGradient></defs>'
         . '<path d="' . $area . '" fill="url(#sp' . $id . ')"/><path d="' . $line . '" fill="none" stroke="' . $color . '" stroke-width="2" stroke-linecap="round"/></svg>';
}
function dash_ago($ts) {
    $d = time() - (int)$ts;
    if ($d < 60) return 'just now';
    if ($d < 3600) return floor($d / 60) . 'm ago';
    if ($d < 86400) return floor($d / 3600) . 'h ago';
    if ($d < 86400 * 7) return floor($d / 86400) . 'd ago';
    return date('M j', (int)$ts);
}
