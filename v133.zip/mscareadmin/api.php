<?php
// MSCare Admin - JSON API used by the admin pages.
// Every action requires a signed-in admin session; actions are limited to the
// admin's own clinic branch.
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/bell.php';
require_once __DIR__ . '/includes/reminders.php';
require_once __DIR__ . '/includes/appt_mail.php';
require_once __DIR__ . '/includes/revenue.php';

header('Content-Type: application/json; charset=utf-8');

function respond($payload, $status = 200) {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}


/** Is a clinic notification switch on? (Settings > Notifications). Defaults to on. */
function notify_enabled($pdo, $branch_id, $key) {
    try {
        $st = $pdo->prepare("SELECT setting_value FROM clinic_settings WHERE branch_id = :b AND setting_key = :k");
        $st->execute([':b' => $branch_id, ':k' => $key]);
        $v = $st->fetchColumn();
        return $v === false ? true : $v === '1';
    } catch (PDOException $ex) {
        return true; // settings table not created yet -> default on
    }
}

/** Put a message in the patient's notification bell (portal). Never blocks the main action. */
function notify_patient($pdo, $appt_id, $branch_id, $title, $message) {
    try {
        $st = $pdo->prepare("SELECT patient_id FROM appointments WHERE id = :id AND branch_id = :b");
        $st->execute([':id' => $appt_id, ':b' => $branch_id]);
        $pid = $st->fetchColumn();
        if (!$pid) return false;
        // The database trigger on appointments already writes a patient notification when the status
        // changes. If that one was just created, update it instead of adding a second copy.
        $upd = $pdo->prepare("UPDATE notifications SET title = :t, message = :m
                               WHERE id = (SELECT id FROM notifications
                                            WHERE patient_id = :p AND appointment_id = :a AND lower(title) = lower(:t2)
                                              AND created_at > now() - interval '1 minute'
                                            ORDER BY id DESC LIMIT 1)");
        $upd->execute([':t' => $title, ':m' => $message, ':p' => $pid, ':a' => $appt_id, ':t2' => $title]);
        if ($upd->rowCount() === 0) {
            $ins = $pdo->prepare("INSERT INTO notifications (patient_id, appointment_id, title, message) VALUES (:p, :a, :t, :m)");
            $ins->execute([':p' => $pid, ':a' => $appt_id, ':t' => $title, ':m' => $message]);
        }
        return true;
    } catch (PDOException $ex) {
        error_log('MSCare notify_patient: ' . $ex->getMessage());
        return false;
    }
}

/** "Cleaning on Oct 30, 2026 at 8:00 AM" */
function appt_summary($pdo, $appt_id) {
    $st = $pdo->prepare("SELECT s.name, a.appointment_date, a.appointment_time FROM appointments a JOIN services s ON s.id = a.service_id WHERE a.id = :id");
    $st->execute([':id' => $appt_id]);
    $r = $st->fetch();
    if (!$r) return 'your appointment';
    return $r['name'] . ' on ' . date('M j, Y', strtotime($r['appointment_date'])) . ' at ' . date('g:i A', strtotime($r['appointment_time']));
}

if (!current_admin()) {
    respond(['ok' => false, 'error' => 'Your admin session has expired. Please log in again.'], 401);
}

$admin = current_admin();
$admin_id = admin_id();
$branch_id = admin_clinic_id();
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;
$action = (string)($data['action'] ?? $_GET['action'] ?? '');

try {
    $pdo = db();

    switch ($action) {
        case 'confirm_appointment':
        case 'complete_appointment':
        case 'cancel_appointment':
            $id = (int)($data['id'] ?? 0);
            if ($id <= 0) respond(['ok' => false, 'error' => 'Invalid appointment.']);

            $status = [
                'confirm_appointment'  => 'Confirmed',
                'complete_appointment' => 'Completed',
                'cancel_appointment'   => 'Cancelled',
            ][$action];

            $sql = "UPDATE appointments SET status = :status, reviewed_by_admin_id = :adm, updated_at = now()";
            $params = [':status' => $status, ':adm' => $admin_id, ':id' => $id, ':bid' => $branch_id];
            if ($action === 'cancel_appointment') {
                $sql .= ", admin_notes = :note";
                $cancel_reason = trim((string)($data['reason'] ?? ''));
                $cancel_details = trim((string)($data['details'] ?? ''));
                if ($cancel_reason === '') respond(['ok' => false, 'error' => 'Please choose a reason for cancellation.']);
                $cancel_reason = function_exists('mb_substr') ? mb_substr($cancel_reason, 0, 80) : substr($cancel_reason, 0, 80);
                $cancel_details = function_exists('mb_substr') ? mb_substr($cancel_details, 0, 200) : substr($cancel_details, 0, 200);
                // Starts with "Cancelled by clinic" so it is never mistaken for a patient cancellation (those start "Cancelled by patient").
                $params[':note'] = 'Cancelled by clinic: ' . $cancel_reason . ($cancel_details !== '' ? ' - ' . $cancel_details : '');
            }
            $sql .= " WHERE id = :id AND branch_id = :bid";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            if ($stmt->rowCount() === 0) {
                respond(['ok' => false, 'error' => 'That appointment was not found for your clinic.']);
            }
            if ($action !== 'complete_appointment' && notify_enabled($pdo, $branch_id, 'n_patient_confirm')) {
                $what = appt_summary($pdo, $id);
                if ($action === 'confirm_appointment') {
                    notify_patient($pdo, $id, $branch_id, 'Appointment confirmed', 'Your ' . $what . ' is confirmed. See you at the clinic!');
                } else {
                    notify_patient($pdo, $id, $branch_id, 'Appointment cancelled', 'Your ' . $what . ' was cancelled by the clinic (' . $cancel_reason . '). Please book another time.');
                }
            }
            if ($action === 'confirm_appointment') appt_email($pdo, $id, 'confirmed');
            elseif ($action === 'cancel_appointment') appt_email($pdo, $id, 'cancelled');
            respond(['ok' => true]);

        case 'reschedule_appointment':
            $id = (int)($data['id'] ?? 0);
            $date = trim((string)($data['date'] ?? ''));
            $time = trim((string)($data['time'] ?? ''));
            $resched_reason = trim((string)($data['reason'] ?? ''));
            $resched_reason = function_exists('mb_substr') ? mb_substr($resched_reason, 0, 200) : substr($resched_reason, 0, 200);
            if ($id <= 0 || $date === '' || $time === '') {
                respond(['ok' => false, 'error' => 'Please provide both date and time.']);
            }
            $dt = DateTime::createFromFormat('Y-m-d', $date);
            if (!$dt || $dt->format('Y-m-d') !== $date) respond(['ok' => false, 'error' => 'Please choose a valid date.']);
            if ($date < date('Y-m-d')) respond(['ok' => false, 'error' => 'You cannot reschedule to a past date.']);
            $ts = strtotime($time);
            if ($ts === false) respond(['ok' => false, 'error' => 'Please choose a valid time.']);
            $time_sql = date('H:i', $ts);
            if ($date === date('Y-m-d') && $time_sql <= date('H:i')) {
                respond(['ok' => false, 'error' => 'That time has already passed today. Please choose a later time.']);
            }

            $cur = $pdo->prepare("SELECT status, appointment_date, appointment_time FROM appointments WHERE id = :id AND branch_id = :bid");
            $cur->execute([':id' => $id, ':bid' => $branch_id]);
            $old = $cur->fetch();
            if (!$old) respond(['ok' => false, 'error' => 'Appointment not found.']);
            if (!in_array($old['status'], ['Pending', 'Confirmed'], true)) {
                respond(['ok' => false, 'error' => 'Only pending or confirmed appointments can be rescheduled.']);
            }
            $od = $pdo->prepare("SELECT open_days FROM branches WHERE id = :b");
            $od->execute([':b' => $branch_id]);
            $od_raw = $od->fetchColumn();
            $od_days = is_array($od_raw) ? $od_raw : (trim((string)$od_raw, '{}') === '' ? [] : array_map('trim', explode(',', trim((string)$od_raw, '{}'))));
            if ($od_days && !in_array($dt->format('D'), $od_days, true)) {
                respond(['ok' => false, 'error' => 'This clinic is only open on ' . implode(', ', $od_days) . '. Please pick one of those days.']);
            }
            if ($old['appointment_date'] === $date && date('H:i', strtotime($old['appointment_time'])) === $time_sql) {
                respond(['ok' => false, 'error' => 'That is the same schedule. Please pick a different date or time.']);
            }
            $old_text = date('M j, Y', strtotime($old['appointment_date'])) . ' ' . date('g:i A', strtotime($old['appointment_time']));
            $new_text = date('M j, Y', strtotime($date)) . ' ' . date('g:i A', $ts);
            $note = 'Rescheduled by clinic from ' . $old_text . ' to ' . $new_text . ($resched_reason !== '' ? ': ' . $resched_reason : '');

            try {
                $stmt = $pdo->prepare("UPDATE appointments
                                          SET appointment_date = :d, appointment_time = :t, reviewed_by_admin_id = :adm,
                                              admin_notes = :note, updated_at = now()
                                        WHERE id = :id AND branch_id = :bid");
                $stmt->execute([':d' => $date, ':t' => $time_sql, ':adm' => $admin_id, ':note' => $note, ':id' => $id, ':bid' => $branch_id]);
            } catch (PDOException $ex) {
                if (is_slot_conflict($ex)) respond(['ok' => false, 'error' => 'That time slot is already booked. Please choose another time.']);
                throw $ex;
            }
            if ($stmt->rowCount() === 0) respond(['ok' => false, 'error' => 'Appointment not found.']);
            if (notify_enabled($pdo, $branch_id, 'n_patient_confirm')) {
                notify_patient($pdo, $id, $branch_id, 'Appointment rescheduled',
                    'Your appointment was moved: ' . appt_summary($pdo, $id) . '.' . ($resched_reason !== '' ? ' Reason: ' . $resched_reason . '.' : ''));
            }
            appt_email($pdo, $id, 'rescheduled');
            respond(['ok' => true]);

        case 'create_appointment':
            $patient_id = (int)($data['patient_id'] ?? 0);
            $service = trim((string)($data['service'] ?? ''));
            $date = trim((string)($data['date'] ?? ''));
            $time = trim((string)($data['time'] ?? ''));

            if ($patient_id <= 0 || $date === '' || $time === '') {
                respond(['ok' => false, 'error' => 'Patient, date and time are required.']);
            }

            $p_stmt = $pdo->prepare("SELECT * FROM patients WHERE id = :pid AND status = 'Active'");
            $p_stmt->execute([':pid' => $patient_id]);
            $p = $p_stmt->fetch();
            if (!$p) respond(['ok' => false, 'error' => 'Patient not found.']);

            $s_stmt = $pdo->prepare("SELECT id FROM services WHERE name = :s AND is_active = TRUE");
            $s_stmt->execute([':s' => $service]);
            $service_id = $s_stmt->fetchColumn();
            if (!$service_id) respond(['ok' => false, 'error' => 'Please choose a valid service.']);

            $ref = 'MSC-' . strtoupper(bin2hex(random_bytes(3)));
            $time_sql = date('H:i', strtotime($time));
            $dentist_id = $pdo->query("SELECT id FROM dentists WHERE is_active = TRUE ORDER BY id LIMIT 1")->fetchColumn();

            $ins = $pdo->prepare("
                INSERT INTO appointments
                    (ref, patient_id, branch_id, service_id, dentist_id, appointment_date, appointment_time,
                     first_name, last_name, phone, email, is_current_patient, status, reviewed_by_admin_id)
                VALUES
                    (:ref, :pid, :bid, :sid, :did, :d, :t, :fn, :ln, :ph, :em, TRUE, 'Confirmed', :adm)
            ");
            $ins->execute([
                ':ref' => $ref, ':pid' => $p['id'], ':bid' => $branch_id,
                ':sid' => (int)$service_id, ':did' => $dentist_id ?: null,
                ':d' => $date, ':t' => $time_sql,
                ':fn' => $p['first_name'], ':ln' => $p['last_name'],
                ':ph' => $p['phone'], ':em' => $p['email'], ':adm' => $admin_id,
            ]);
            $new_id = (int)$pdo->query("SELECT id FROM appointments WHERE ref = " . $pdo->quote($ref))->fetchColumn();
            if ($new_id) appt_email($pdo, $new_id, 'confirmed');
            respond(['ok' => true, 'ref' => $ref]);

        case 'approve_consent':
        case 'reject_consent':
            $patient_id = (int)($data['patient_id'] ?? 0);
            if ($patient_id <= 0) respond(['ok' => false, 'error' => 'Invalid patient.']);

            $status = $action === 'approve_consent' ? 'approved' : 'rejected';
            $note = $action === 'reject_consent'
                ? trim((string)($data['note'] ?? 'Signature not approved. Please upload again.'))
                : null;

            // Only the patient's own branch can review their consent.
            $stmt = $pdo->prepare("UPDATE patient_consents
                                      SET status = :st, rejection_note = :note,
                                          reviewed_by_admin_id = :adm, reviewed_at = now()
                                    WHERE patient_id = :pid
                                      AND patient_id IN (SELECT p.id FROM patients p WHERE (p.branch_id IS NULL OR p.branch_id = :b OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b)))");
            $stmt->execute([':st' => $status, ':note' => $note, ':adm' => $admin_id, ':pid' => $patient_id, ':b' => $branch_id]);
            if ($stmt->rowCount() === 0) respond(['ok' => false, 'error' => 'No consent form from a patient of this branch was found.']);

            // Notify the patient (skipped if the DB trigger already created it just now)
            try {
                $ntitle = $status === 'approved' ? 'Signature Approved' : 'Signature Rejected';
                $nmsg = $status === 'approved'
                    ? 'Great news! Your informed consent signature has been approved. You can now book an appointment.'
                    : 'Your informed consent signature was not approved' . ($note ? ': ' . $note : '') . '. Please upload a new signature.';
                $dup = $pdo->prepare("SELECT 1 FROM notifications WHERE patient_id = :pid AND title = :t AND created_at > now() - interval '15 seconds' LIMIT 1");
                $dup->execute([':pid' => $patient_id, ':t' => $ntitle]);
                if (!$dup->fetchColumn()) {
                    $pdo->prepare("INSERT INTO notifications (patient_id, title, message) VALUES (:pid, :t, :m)")
                        ->execute([':pid' => $patient_id, ':t' => $ntitle, ':m' => $nmsg]);
                }
            } catch (Throwable $ex) { error_log('MSCare consent notify: ' . $ex->getMessage()); }
            respond(['ok' => true]);

        case 'reset_sig_tries':
            $patient_id = (int)($data['patient_id'] ?? 0);
            $stmt = $pdo->prepare("UPDATE patient_consents SET sig_tries_used = 0 WHERE patient_id = :pid
                                      AND patient_id IN (SELECT p.id FROM patients p WHERE (p.branch_id IS NULL OR p.branch_id = :b OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b)))");
            $stmt->execute([':pid' => $patient_id, ':b' => $branch_id]);
            respond(['ok' => true]);

        case 'log_treatment':
            $patient_id = (int)($data['patient_id'] ?? 0);
            $date = trim((string)($data['date'] ?? date('Y-m-d')));
            $proc = trim((string)($data['procedure'] ?? ''));
            $tooth = trim((string)($data['tooth'] ?? '—'));
            $cost = (float)($data['cost'] ?? 0);
            $notes = trim((string)($data['notes'] ?? ''));
            $dentist = trim((string)($data['dentist'] ?? 'Dr. Marilou S. Cariño'));
            $method = rev_method($data['payment_method'] ?? 'Cash');
            $paid = isset($data['amount_paid']) && $data['amount_paid'] !== '' ? max(0.0, (float)$data['amount_paid']) : $cost;

            if ($patient_id <= 0 || $proc === '') {
                respond(['ok' => false, 'error' => 'Patient and Procedure are required.']);
            }

            rev_ensure_columns($pdo);
            $stmt = $pdo->prepare("
                INSERT INTO treatments
                    (patient_id, branch_id, treatment_date, procedure_name, tooth, dentist_name,
                     cost, payment_method, amount_paid, notes, created_by_admin_id)
                VALUES (:pid, :bid, :d, :pr, :th, :dt, :c, :pm, :ap, :nt, :adm)
            ");
            $stmt->execute([
                ':pid' => $patient_id, ':bid' => $branch_id, ':d' => $date,
                ':pr' => $proc, ':th' => $tooth, ':dt' => $dentist,
                ':c' => $cost, ':pm' => $method, ':ap' => $paid, ':nt' => $notes, ':adm' => $admin_id,
            ]);
            respond(['ok' => true]);

        case 'save_tooth':
            $patient_id = (int)($data['patient_id'] ?? 0);
            $tooth_num = (int)($data['tooth_number'] ?? 0);
            $code = trim((string)($data['condition_code'] ?? ''));
            $notes = trim((string)($data['notes'] ?? ''));

            if ($patient_id <= 0 || $tooth_num < 11 || $tooth_num > 85) {
                respond(['ok' => false, 'error' => 'Invalid patient or tooth number.']);
            }

            if ($code === '' || strtolower($code) === 'none') {
                $stmt = $pdo->prepare("DELETE FROM dental_charts WHERE patient_id = :pid AND tooth_number = :tn");
                $stmt->execute([':pid' => $patient_id, ':tn' => $tooth_num]);
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO dental_charts (patient_id, tooth_number, condition_code, notes, updated_by_admin_id)
                    VALUES (:pid, :tn, :c, :nt, :adm)
                    ON CONFLICT (patient_id, tooth_number) DO UPDATE SET
                        condition_code = EXCLUDED.condition_code,
                        notes = EXCLUDED.notes,
                        updated_by_admin_id = EXCLUDED.updated_by_admin_id
                ");
                $stmt->execute([':pid' => $patient_id, ':tn' => $tooth_num, ':c' => $code, ':nt' => $notes, ':adm' => $admin_id]);
            }
            respond(['ok' => true]);

        case 'mark_notif_read':
            // Admin bell: remember which notifications this admin has opened.
            admin_bell_ensure_table($pdo);
            if (!empty($data['all'])) {
                $pdo->prepare("INSERT INTO admin_notif_reads (admin_id, notif_key)
                               SELECT :a, 'p' || id FROM appointments WHERE branch_id = :b AND status = 'Pending'
                               ON CONFLICT DO NOTHING")->execute([':a' => $admin_id, ':b' => $branch_id]);
                $pdo->prepare("INSERT INTO admin_notif_reads (admin_id, notif_key)
                               SELECT :a, 'c' || id FROM appointments
                                WHERE branch_id = :b AND status = 'Cancelled' AND admin_notes LIKE 'Cancelled by patient%'
                               ON CONFLICT DO NOTHING")->execute([':a' => $admin_id, ':b' => $branch_id]);
                $pdo->prepare("INSERT INTO admin_notif_reads (admin_id, notif_key)
                               SELECT :a, 's' || patient_id || 't' || extract(epoch FROM updated_at)::bigint
                                 FROM patient_consents WHERE status = 'pending'
                                  AND patient_id IN (SELECT p.id FROM patients p WHERE (p.branch_id IS NULL OR p.branch_id = :b OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b)))
                               ON CONFLICT DO NOTHING")->execute([':a' => $admin_id, ':b' => $branch_id]);
                respond(['ok' => true]);
            }
            $key = (string)($data['key'] ?? '');
            if (preg_match('/^s(\d{1,18})t(\d{1,12})$/', $key, $sm)) {
                $own = $pdo->prepare("SELECT 1 FROM patient_consents pc JOIN patients p ON p.id = pc.patient_id WHERE pc.patient_id = :id AND (p.branch_id IS NULL OR p.branch_id = :b OR EXISTS (SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.branch_id = :b))");
                $own->execute([':id' => (int)$sm[1], ':b' => $branch_id]);
                if (!$own->fetchColumn()) respond(['ok' => false, 'error' => 'Notification not found.']);
                $pdo->prepare("INSERT INTO admin_notif_reads (admin_id, notif_key) VALUES (:a, :k) ON CONFLICT DO NOTHING")
                    ->execute([':a' => $admin_id, ':k' => $key]);
                respond(['ok' => true]);
            }
            if (!preg_match('/^[pc]\d{1,18}$/', $key)) respond(['ok' => false, 'error' => 'Invalid notification.']);
            $own = $pdo->prepare("SELECT 1 FROM appointments WHERE id = :id AND branch_id = :b");
            $own->execute([':id' => (int)substr($key, 1), ':b' => $branch_id]);
            if (!$own->fetchColumn()) respond(['ok' => false, 'error' => 'Notification not found.']);
            $pdo->prepare("INSERT INTO admin_notif_reads (admin_id, notif_key) VALUES (:a, :k) ON CONFLICT DO NOTHING")
                ->execute([':a' => $admin_id, ':k' => $key]);
            respond(['ok' => true]);

        case 'send_reminder':
            // Sends a reminder for one upcoming appointment: portal bell (if the patient has an account) AND email.
            $appt_id = (int)($data['appointment_id'] ?? $data['id'] ?? 0);
            if ($appt_id <= 0) respond(['ok' => false, 'error' => 'Invalid appointment.']);

            $chk = $pdo->prepare("SELECT patient_id, status, email FROM appointments WHERE id = :id AND branch_id = :b");
            $chk->execute([':id' => $appt_id, ':b' => $branch_id]);
            $row = $chk->fetch();
            if (!$row) respond(['ok' => false, 'error' => 'That appointment was not found for your clinic.']);
            if (!in_array($row['status'], ['Pending', 'Confirmed'], true)) respond(['ok' => false, 'error' => 'Reminders can only be sent for pending or confirmed appointments.']);

            $bell = false; $mail = false; $mail_err = '';
            if ($row['patient_id']) {
                $bell = notify_patient($pdo, $appt_id, $branch_id, 'Appointment reminder',
                    'Reminder: ' . appt_summary($pdo, $appt_id) . '. Please arrive 10 minutes early.');
            }
            [$mail, $mail_err] = send_reminder_email($pdo, $appt_id);

            if (!$bell && !$mail) {
                respond(['ok' => false, 'error' => $mail_err !== '' ? 'Could not send the reminder: ' . $mail_err : 'Could not send the reminder.'], 500);
            }
            $where = $bell && $mail ? 'portal and email' : ($mail ? 'email' : 'portal');
            $msg = 'Reminder sent to the patient (' . $where . ').';
            if (!$mail && $mail_err !== '') $msg .= ' Email not sent: ' . $mail_err;
            respond(['ok' => true, 'bell' => $bell, 'email' => $mail, 'message' => $msg]);

        default:
            respond(['ok' => false, 'error' => 'Unknown action.'], 400);
    }
} catch (PDOException $ex) {
    if (is_slot_conflict($ex)) {
        respond(['ok' => false, 'error' => 'That time slot is already booked. Please choose another time.']);
    }
    respond(['ok' => false, 'error' => 'Database error: ' . $ex->getMessage()], 500);
}
