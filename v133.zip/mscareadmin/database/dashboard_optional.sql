-- MSCare admin dashboard redesign -- PostgreSQL
-- WALANG REQUIRED na bagong table/column: lahat ng laman ng dashboard ay galing sa
-- existing tables (appointments, treatments, patients, contact_messages).
-- Ang mga ito ay optional lang (bilis ng queries kapag lumaki na ang data) at safety.

-- 1) Mas mabilis na yearly/monthly counts per branch
CREATE INDEX IF NOT EXISTS ix_appointments_branch_date ON appointments (branch_id, appointment_date);
CREATE INDEX IF NOT EXISTS ix_treatments_branch_date   ON treatments   (branch_id, treatment_date);
CREATE INDEX IF NOT EXISTS ix_patients_created         ON patients     (created_at);
CREATE INDEX IF NOT EXISTS ix_appointments_created     ON appointments (branch_id, created_at DESC);

-- 2) Safety: ginagamit na ng dashboard (pending approvals / recent activity) ang mga columns na ito.
--    Wala sila sa schema na pinost mo, kaya idagdag kung wala pa (safe i-run kahit meron na).
ALTER TABLE patients ADD COLUMN IF NOT EXISTS branch_id SMALLINT REFERENCES branches(id) ON DELETE SET NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS email_reminded_at TIMESTAMPTZ;
ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS sender VARCHAR(10) NOT NULL DEFAULT 'patient';
