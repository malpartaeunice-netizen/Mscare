-- MSCare Admin - payment info on treatment records (used by Revenue & Reports).
-- Safe to run more than once. The admin site also runs this automatically.
ALTER TABLE public.treatments ADD COLUMN IF NOT EXISTS payment_method character varying(20) DEFAULT 'Cash' NOT NULL;
ALTER TABLE public.treatments ADD COLUMN IF NOT EXISTS amount_paid numeric(10,2);
UPDATE public.treatments SET amount_paid = cost WHERE amount_paid IS NULL;
