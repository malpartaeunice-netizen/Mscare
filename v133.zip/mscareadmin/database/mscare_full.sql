-- =============================================================================
-- MSCare Dental Clinic - complete PostgreSQL schema + safe seed
-- Fresh install:  createdb mscare  then  psql -d mscare -f mscare_full.sql
-- Existing database: run only db/seed.sql (it never overwrites patients).
-- =============================================================================

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: auto_link_patient_to_appointment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auto_link_patient_to_appointment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.patient_id IS NULL THEN
        SELECT id INTO NEW.patient_id FROM patients WHERE LOWER(email) = LOWER(NEW.email) LIMIT 1;
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: can_patient_book(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.can_patient_book(p_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    med_done BOOLEAN;
    con_approved BOOLEAN;
BEGIN
    SELECT COALESCE(is_completed, FALSE) INTO med_done
    FROM patient_medical_histories WHERE patient_id = p_id;
    SELECT (status = 'approved') INTO con_approved
    FROM patient_consents WHERE patient_id = p_id;
    RETURN COALESCE(med_done, FALSE) AND COALESCE(con_approved, FALSE);
END;
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    branch_id smallint,
    display_name character varying(80) NOT NULL,
    initials character varying(10) DEFAULT 'AD'::character varying NOT NULL,
    role character varying(20) DEFAULT 'admin'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT admins_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'staff'::character varying, 'superadmin'::character varying])::text[])))
);


--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id bigint NOT NULL,
    ref character varying(12) NOT NULL,
    patient_id bigint,
    branch_id smallint NOT NULL,
    service_id smallint NOT NULL,
    dentist_id smallint,
    appointment_date date NOT NULL,
    appointment_time time without time zone NOT NULL,
    first_name character varying(60) NOT NULL,
    last_name character varying(60) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(120) NOT NULL,
    is_current_patient boolean DEFAULT false NOT NULL,
    comments character varying(500) DEFAULT ''::character varying NOT NULL,
    status character varying(12) DEFAULT 'Pending'::character varying NOT NULL,
    admin_notes text DEFAULT ''::text,
    reviewed_by_admin_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT appointments_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Confirmed'::character varying, 'Completed'::character varying, 'Cancelled'::character varying, 'No-show'::character varying])::text[])))
);


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id smallint NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(80) NOT NULL,
    city character varying(40) NOT NULL,
    address character varying(200) NOT NULL,
    open_days text[] NOT NULL,
    phone character varying(30) DEFAULT '0917 220 3391'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    mobile character varying(20) NOT NULL,
    email character varying(120),
    branch_id smallint NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    replied_at timestamp with time zone,
    replied_by_admin_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contact_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_messages_id_seq OWNED BY public.contact_messages.id;


--
-- Name: dental_charts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dental_charts (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    tooth_number smallint NOT NULL,
    condition_code character varying(20) NOT NULL,
    notes text DEFAULT ''::text,
    updated_by_admin_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dental_charts_tooth_number_check CHECK (((tooth_number >= 11) AND (tooth_number <= 85)))
);


--
-- Name: dental_charts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dental_charts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dental_charts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dental_charts_id_seq OWNED BY public.dental_charts.id;


--
-- Name: dentists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dentists (
    id smallint NOT NULL,
    name character varying(100) NOT NULL,
    title character varying(80) DEFAULT 'Chief Dental Officer'::character varying NOT NULL,
    license_no character varying(50),
    phone character varying(30),
    email character varying(120),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dentists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dentists_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dentists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dentists_id_seq OWNED BY public.dentists.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    appointment_id bigint,
    title character varying(150) NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: patient_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_consents (
    patient_id bigint NOT NULL,
    has_agreed boolean DEFAULT true NOT NULL,
    signature_data text NOT NULL,
    signature_date date DEFAULT CURRENT_DATE NOT NULL,
    sig_tries_used smallint DEFAULT 1 NOT NULL,
    status character varying(15) DEFAULT 'pending'::character varying NOT NULL,
    rejection_note character varying(255),
    reviewed_by_admin_id integer,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patient_consents_status_check CHECK (((status)::text = ANY ((ARRAY['none'::character varying, 'pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: patient_medical_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_medical_histories (
    patient_id bigint NOT NULL,
    physician_name character varying(100),
    physician_specialty character varying(100),
    physician_office_no character varying(30),
    physician_office_addr character varying(255),
    in_good_health boolean DEFAULT true NOT NULL,
    under_treatment boolean DEFAULT false NOT NULL,
    treatment_details character varying(255),
    serious_illness_or_op boolean DEFAULT false NOT NULL,
    illness_details character varying(255),
    hospitalized boolean DEFAULT false NOT NULL,
    hospitalized_details character varying(255),
    taking_medication boolean DEFAULT false NOT NULL,
    medication_details character varying(255),
    tobacco_use boolean DEFAULT false NOT NULL,
    alcohol_drug_use boolean DEFAULT false NOT NULL,
    allergies text[] DEFAULT ARRAY[]::text[],
    allergy_other character varying(255),
    women_pregnant boolean,
    women_nursing boolean,
    women_birth_control boolean,
    blood_type character varying(10),
    blood_pressure character varying(20),
    conditions text[] DEFAULT ARRAY[]::text[],
    condition_other character varying(255),
    is_completed boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: patient_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_otps (
    id bigint NOT NULL,
    user_type character varying(10) NOT NULL,
    user_id bigint NOT NULL,
    otp_code character varying(10) NOT NULL,
    purpose character varying(30) DEFAULT 'login'::character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patient_otps_purpose_check CHECK (((purpose)::text = ANY ((ARRAY['login'::character varying, 'register'::character varying, 'password_reset'::character varying])::text[]))),
    CONSTRAINT patient_otps_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['patient'::character varying, 'admin'::character varying])::text[])))
);


--
-- Name: patient_otps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patient_otps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patient_otps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patient_otps_id_seq OWNED BY public.patient_otps.id;


--
-- Name: patient_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_records (
    patient_id bigint NOT NULL,
    birthdate date,
    sex character varying(10),
    nickname character varying(50),
    religion character varying(50),
    nationality character varying(50),
    home_address character varying(255),
    occupation character varying(100),
    dental_insurance character varying(100),
    effective_date date,
    home_no character varying(30),
    office_no character varying(30),
    fax_no character varying(30),
    cell_no character varying(30),
    email character varying(120),
    guardian_name character varying(100),
    guardian_occupation character varying(100),
    prev_dentist character varying(100),
    last_dental_visit date,
    reason_for_consultation text,
    is_completed boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id bigint NOT NULL,
    first_name character varying(60) NOT NULL,
    last_name character varying(60) NOT NULL,
    middle_name character varying(60) DEFAULT ''::character varying,
    email character varying(120) NOT NULL,
    phone character varying(30) NOT NULL,
    age smallint NOT NULL,
    gender character varying(20) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_demo boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patients_age_check CHECK (((age >= 0) AND (age <= 125))),
    CONSTRAINT patients_gender_check CHECK (((gender)::text = ANY ((ARRAY['Female'::character varying, 'Male'::character varying, 'Prefer not to say'::character varying])::text[]))),
    CONSTRAINT patients_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Inactive'::character varying, 'Suspended'::character varying])::text[])))
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id smallint NOT NULL,
    name character varying(80) NOT NULL,
    category character varying(40) NOT NULL,
    sort_order smallint DEFAULT 0 NOT NULL,
    price numeric(10,2) DEFAULT 0.00 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT services_category_check CHECK (((category)::text = ANY ((ARRAY['Basic Dental Services'::character varying, 'Specialized Services'::character varying])::text[])))
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: treatments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treatments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    branch_id smallint NOT NULL,
    appointment_id bigint,
    treatment_date date DEFAULT CURRENT_DATE NOT NULL,
    procedure_name character varying(100) NOT NULL,
    tooth character varying(30) DEFAULT '—'::character varying,
    dentist_name character varying(100) DEFAULT 'Dr. Marilou S. Cariño'::character varying NOT NULL,
    cost numeric(10,2) DEFAULT 0.00 NOT NULL,
    notes text DEFAULT ''::text,
    created_by_admin_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_method character varying(20) DEFAULT 'Cash'::character varying NOT NULL,
    amount_paid numeric(10,2)
);


--
-- Name: treatments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.treatments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: treatments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.treatments_id_seq OWNED BY public.treatments.id;


--
-- Name: v_appointments_full; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_appointments_full AS
 SELECT a.id,
    a.ref,
    a.patient_id,
    COALESCE((((p.first_name)::text || ' '::text) || (p.last_name)::text), (((a.first_name)::text || ' '::text) || (a.last_name)::text)) AS patient_name,
    COALESCE(p.email, a.email) AS email,
    COALESCE(p.phone, a.phone) AS phone,
    b.id AS branch_id,
    b.code AS branch_code,
    b.name AS branch_name,
    b.city AS branch_city,
    s.id AS service_id,
    s.name AS service_name,
    s.category AS service_category,
    COALESCE(d.name, 'Dr. Marilou S. Cariño'::character varying) AS dentist_name,
    a.appointment_date,
    to_char((a.appointment_time)::interval, 'HH12:MI AM'::text) AS appointment_time_formatted,
    a.appointment_time,
    a.status,
    a.is_current_patient,
    a.comments,
    a.admin_notes,
    adm.display_name AS reviewed_by,
    a.created_at,
    a.updated_at
   FROM (((((public.appointments a
     JOIN public.branches b ON ((b.id = a.branch_id)))
     JOIN public.services s ON ((s.id = a.service_id)))
     LEFT JOIN public.dentists d ON ((d.id = a.dentist_id)))
     LEFT JOIN public.patients p ON ((p.id = a.patient_id)))
     LEFT JOIN public.admins adm ON ((adm.id = a.reviewed_by_admin_id)));


--
-- Name: v_patient_records_overview; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_patient_records_overview AS
 SELECT p.id AS patient_id,
    (((p.first_name)::text || ' '::text) || (p.last_name)::text) AS full_name,
    p.email,
    p.phone,
    p.age,
    p.gender,
    COALESCE(pr.is_completed, false) AS personal_info_done,
    COALESCE(pm.is_completed, false) AS medical_history_done,
    COALESCE(pc.status, 'none'::character varying) AS consent_status,
    pc.signature_date,
    pc.sig_tries_used,
    pc.rejection_note,
    adm.display_name AS consent_reviewed_by,
    public.can_patient_book(p.id) AS can_book_appointment,
    p.created_at AS registered_at
   FROM ((((public.patients p
     LEFT JOIN public.patient_records pr ON ((pr.patient_id = p.id)))
     LEFT JOIN public.patient_medical_histories pm ON ((pm.patient_id = p.id)))
     LEFT JOIN public.patient_consents pc ON ((pc.patient_id = p.id)))
     LEFT JOIN public.admins adm ON ((adm.id = pc.reviewed_by_admin_id)));


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: contact_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages ALTER COLUMN id SET DEFAULT nextval('public.contact_messages_id_seq'::regclass);


--
-- Name: dental_charts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dental_charts ALTER COLUMN id SET DEFAULT nextval('public.dental_charts_id_seq'::regclass);


--
-- Name: dentists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dentists ALTER COLUMN id SET DEFAULT nextval('public.dentists_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: patient_otps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_otps ALTER COLUMN id SET DEFAULT nextval('public.patient_otps_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: treatments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments ALTER COLUMN id SET DEFAULT nextval('public.treatments_id_seq'::regclass);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_ref_key UNIQUE (ref);


--
-- Name: branches branches_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_code_key UNIQUE (code);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: dental_charts dental_charts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dental_charts
    ADD CONSTRAINT dental_charts_pkey PRIMARY KEY (id);


--
-- Name: dentists dentists_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dentists
    ADD CONSTRAINT dentists_name_key UNIQUE (name);


--
-- Name: dentists dentists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dentists
    ADD CONSTRAINT dentists_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: patient_consents patient_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_consents
    ADD CONSTRAINT patient_consents_pkey PRIMARY KEY (patient_id);


--
-- Name: patient_medical_histories patient_medical_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medical_histories
    ADD CONSTRAINT patient_medical_histories_pkey PRIMARY KEY (patient_id);


--
-- Name: patient_otps patient_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_otps
    ADD CONSTRAINT patient_otps_pkey PRIMARY KEY (id);


--
-- Name: patient_records patient_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_records
    ADD CONSTRAINT patient_records_pkey PRIMARY KEY (patient_id);


--
-- Name: patients patients_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_email_key UNIQUE (email);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: services services_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_name_key UNIQUE (name);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: treatments treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_pkey PRIMARY KEY (id);


--
-- Name: dental_charts uq_patient_tooth; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dental_charts
    ADD CONSTRAINT uq_patient_tooth UNIQUE (patient_id, tooth_number);


--
-- Name: ix_appointments_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_branch ON public.appointments USING btree (branch_id);


--
-- Name: ix_appointments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_date ON public.appointments USING btree (appointment_date);


--
-- Name: ix_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- Name: ix_appointments_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_phone ON public.appointments USING btree (phone);


--
-- Name: ix_appointments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_appointments_status ON public.appointments USING btree (status);


--
-- Name: ix_dental_charts_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dental_charts_patient ON public.dental_charts USING btree (patient_id);


--
-- Name: ix_messages_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_branch ON public.contact_messages USING btree (branch_id);


--
-- Name: ix_messages_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_created ON public.contact_messages USING btree (created_at DESC);


--
-- Name: ix_notifications_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_patient ON public.notifications USING btree (patient_id, is_read);


--
-- Name: ix_otps_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_otps_lookup ON public.patient_otps USING btree (user_type, user_id, otp_code, is_used);


--
-- Name: ix_patient_consents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_patient_consents_status ON public.patient_consents USING btree (status);


--
-- Name: ix_patients_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_patients_email ON public.patients USING btree (email);


--
-- Name: ix_patients_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_patients_phone ON public.patients USING btree (phone);


--
-- Name: ix_treatments_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treatments_branch ON public.treatments USING btree (branch_id);


--
-- Name: ix_treatments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treatments_date ON public.treatments USING btree (treatment_date DESC);


--
-- Name: ix_treatments_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_treatments_patient ON public.treatments USING btree (patient_id);


--
-- Name: uq_appointments_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_appointments_slot ON public.appointments USING btree (appointment_date, appointment_time) WHERE ((status)::text <> 'Cancelled'::text);


--
-- Name: appointments trg_appointments_autolink; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_appointments_autolink BEFORE INSERT ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.auto_link_patient_to_appointment();


--
-- Name: appointments trg_appointments_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_appointments_updated BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: dental_charts trg_dental_charts_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_dental_charts_updated BEFORE UPDATE ON public.dental_charts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: patient_consents trg_patient_consents_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_patient_consents_updated BEFORE UPDATE ON public.patient_consents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: patient_medical_histories trg_patient_med_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_patient_med_updated BEFORE UPDATE ON public.patient_medical_histories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: patient_records trg_patient_records_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_patient_records_updated BEFORE UPDATE ON public.patient_records FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: patients trg_patients_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_patients_updated BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: admins admins_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: appointments appointments_dentist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_dentist_id_fkey FOREIGN KEY (dentist_id) REFERENCES public.dentists(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_reviewed_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_reviewed_by_admin_id_fkey FOREIGN KEY (reviewed_by_admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: contact_messages contact_messages_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: contact_messages contact_messages_replied_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_replied_by_admin_id_fkey FOREIGN KEY (replied_by_admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: dental_charts dental_charts_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dental_charts
    ADD CONSTRAINT dental_charts_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: dental_charts dental_charts_updated_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dental_charts
    ADD CONSTRAINT dental_charts_updated_by_admin_id_fkey FOREIGN KEY (updated_by_admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: patient_consents patient_consents_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_consents
    ADD CONSTRAINT patient_consents_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: patient_consents patient_consents_reviewed_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_consents
    ADD CONSTRAINT patient_consents_reviewed_by_admin_id_fkey FOREIGN KEY (reviewed_by_admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: patient_medical_histories patient_medical_histories_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medical_histories
    ADD CONSTRAINT patient_medical_histories_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: patient_records patient_records_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_records
    ADD CONSTRAINT patient_records_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: treatments treatments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: treatments treatments_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: treatments treatments_created_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_created_by_admin_id_fkey FOREIGN KEY (created_by_admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: treatments treatments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treatments
    ADD CONSTRAINT treatments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



SET search_path = public;

-- ===== SEED DATA =====
-- =============================================================================
-- MSCare Dental Clinic - PostgreSQL seed data (safe to run more than once)
-- This seeds the clinic reference data (branches, services, dentists, admins)
-- and one demo patient. Existing patient accounts are NEVER overwritten.
-- =============================================================================

-- 1. Branches ---------------------------------------------------------------
INSERT INTO branches (code, name, city, address, open_days, phone) VALUES
    ('c1', 'Clinic 1 — Makati', 'Makati',
     '#7 Moonlite Street, Barangay Singkamas, Makati City',
     ARRAY['Mon','Wed','Fri','Sat'], '0917 220 3391'),
    ('c2', 'Clinic 2 — Manila', 'Manila',
     'Burke House No 5 Building, Pedro Gil Street, Sta. Ana, Manila',
     ARRAY['Tue','Thu'], '0917 220 3392')
ON CONFLICT (code) DO UPDATE SET
    name      = EXCLUDED.name,
    city      = EXCLUDED.city,
    address   = EXCLUDED.address,
    open_days = EXCLUDED.open_days,
    phone     = EXCLUDED.phone;

-- 2. Services --------------------------------------------------------------
INSERT INTO services (name, category, sort_order, price, is_active) VALUES
    ('General Dentistry',    'Basic Dental Services', 1,  1000.00, TRUE),
    ('Cleaning',             'Basic Dental Services', 2,  1200.00, TRUE),
    ('Orthodontics',         'Specialized Services',  3, 35000.00, TRUE),
    ('Esthetic Dentistry',   'Specialized Services',  4,  5000.00, TRUE),
    ('Prosthodontics',       'Specialized Services',  5, 12000.00, TRUE),
    ('Root Canal Treatment', 'Specialized Services',  6,  8500.00, TRUE),
    ('Oral Surgery',         'Basic Dental Services', 7,  3000.00, TRUE),
    ('Braces',               'Specialized Services',  8, 45000.00, TRUE)
ON CONFLICT (name) DO UPDATE SET
    category   = EXCLUDED.category,
    sort_order = EXCLUDED.sort_order,
    price      = EXCLUDED.price,
    is_active  = EXCLUDED.is_active;

-- 3. Dentist ---------------------------------------------------------------
INSERT INTO dentists (name, title, license_no, phone, email, is_active) VALUES
    ('Dr. Marilou S. Cariño', 'Chief Dental Officer / Orthodontist',
     'DNT-PH-048291', '0917 220 3391', 'dr.carino@mscare.com', TRUE)
ON CONFLICT (name) DO NOTHING;

-- 4. Admin accounts (admin1 / admin123 and admin2 / admin123) ---------------
INSERT INTO admins (username, password_hash, branch_id, display_name, initials, role, is_active)
VALUES
    ('admin1', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92',
     (SELECT id FROM branches WHERE code = 'c1'), 'Clinic 1 Admin', 'A1', 'admin', TRUE),
    ('admin2', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92',
     (SELECT id FROM branches WHERE code = 'c2'), 'Clinic 2 Admin', 'A2', 'admin', TRUE)
ON CONFLICT (username) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    branch_id     = EXCLUDED.branch_id,
    display_name  = EXCLUDED.display_name,
    initials      = EXCLUDED.initials,
    role          = EXCLUDED.role,
    is_active     = EXCLUDED.is_active;

-- 6. Verification output ----------------------------------------------------
SELECT 'branches' AS item, count(*)::text AS total FROM branches
UNION ALL SELECT 'services', count(*)::text FROM services
UNION ALL SELECT 'dentists', count(*)::text FROM dentists
UNION ALL SELECT 'admins', count(*)::text FROM admins
UNION ALL SELECT 'patients', count(*)::text FROM patients;

-- -----------------------------------------------------------------------------
-- AI chatbot (Gemini) for Messages  -  safe to run more than once
--   sender       'patient' | 'admin'   (who wrote the message)
--   is_ai        true  = the reply was written by the AI chatbot
--   needs_human  true  = the AI could not answer this patient message; admin must reply
-- -----------------------------------------------------------------------------
ALTER TABLE public.contact_messages ADD COLUMN IF NOT EXISTS sender      varchar(10) NOT NULL DEFAULT 'patient';
ALTER TABLE public.contact_messages ADD COLUMN IF NOT EXISTS is_ai       boolean     NOT NULL DEFAULT false;
ALTER TABLE public.contact_messages ADD COLUMN IF NOT EXISTS needs_human boolean     NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS ix_messages_email ON public.contact_messages (lower(email));
CREATE INDEX IF NOT EXISTS ix_messages_needs_human ON public.contact_messages (branch_id) WHERE needs_human AND NOT is_read;
