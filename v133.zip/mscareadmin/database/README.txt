MSCare PostgreSQL Database
===========================

The admin site uses the same database and settings as the patient site:
  host     localhost
  port     5432
  database mscare
  user     postgres
  password 0519

Setup
  mscare_full.sql  Complete schema + seed (fresh install)
  seed.sql         Safe seed (existing database, never overwrites patients)

